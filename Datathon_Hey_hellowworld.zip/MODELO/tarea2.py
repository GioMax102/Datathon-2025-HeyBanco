import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
import warnings
warnings.filterwarnings('ignore')

class BankFeatureEngineer:
    """
    Feature Engineering completo para datos bancarios del datathon
    Genera características temporales y estáticas para modelo CNN híbrido
    """
    
    def __init__(self):
        self.label_encoders = {}
        self.onehot_encoders = {}
        self.age_bins = None
        
    def load_processed_data(self, clientes_path, transacciones_path):
        """Cargar datos ya preprocesados"""
        print("📂 Cargando datos preprocesados...")
        self.df_clientes = pd.read_csv(clientes_path)
        self.df_transacciones = pd.read_csv(transacciones_path)

        # ✅ Corregir: convertir siempre la columna 'fecha' a datetime
        try:
            self.df_transacciones['fecha'] = pd.to_datetime(
                self.df_transacciones['fecha'], errors='coerce'
            )
        except Exception as e:
            print(f"❌ Error al convertir fechas: {e}")

        # ⚠️ Advertir si hay fechas no válidas
        if self.df_transacciones['fecha'].isnull().any():
            print("⚠️ Atención: hay valores en 'fecha' que no pudieron convertirse a datetime (NaT).")

        print(f"✅ Clientes: {len(self.df_clientes)} registros")
        print(f"✅ Transacciones: {len(self.df_transacciones)} registros")

        
    def create_temporal_features_transactions(self):
        """C1: Features Temporales para Transacciones"""
        print("\n=== C1: FEATURES TEMPORALES (TRANSACCIONES) ===")
        
        # Ordenar por cliente y fecha
        self.df_transacciones = self.df_transacciones.sort_values(['id', 'fecha'])
        
        # 1. Extraer componentes temporales de fecha
        print("🗓️ Extrayendo componentes temporales...")
        self.df_transacciones['dia_semana'] = self.df_transacciones['fecha'].dt.dayofweek  # 0=Lunes
        self.df_transacciones['mes'] = self.df_transacciones['fecha'].dt.month
        self.df_transacciones['trimestre'] = self.df_transacciones['fecha'].dt.quarter
        self.df_transacciones['dia_mes'] = self.df_transacciones['fecha'].dt.day
        self.df_transacciones['es_fin_semana'] = (self.df_transacciones['dia_semana'] >= 5).astype(int)
        
        # 2. Calcular días entre transacciones consecutivas por cliente
        print("📅 Calculando días entre transacciones...")
        self.df_transacciones['dias_entre_transacciones'] = (
            self.df_transacciones.groupby('id')['fecha']
            .diff()
            .dt.days
            .fillna(0)  # Primera transacción = 0 días
        )
        
        # 3. Ventana móvil: promedio de gasto últimos 30 días
        print("📊 Calculando ventanas móviles (30 días)...")
        ventana_movil_list = []
        
        for cliente_id in self.df_transacciones['id'].unique():
            cliente_data = self.df_transacciones[self.df_transacciones['id'] == cliente_id].copy()
            cliente_data = cliente_data.sort_values('fecha')
            
            ventana_cliente = []
            for i, row in cliente_data.iterrows():
                fecha_actual = row['fecha']
                fecha_limite = fecha_actual - timedelta(days=30)
                
                # Transacciones en últimos 30 días (excluyendo la actual)
                mask_ventana = (
                    (cliente_data['fecha'] >= fecha_limite) & 
                    (cliente_data['fecha'] < fecha_actual)
                )
                
                if mask_ventana.any():
                    promedio_30d = cliente_data.loc[mask_ventana, 'monto'].mean()
                else:
                    promedio_30d = 0
                
                ventana_cliente.append(promedio_30d)
            
            ventana_movil_list.extend(ventana_cliente)
        
        self.df_transacciones['ventana_movil_30d'] = ventana_movil_list
        
        # 4. Features adicionales útiles para CNN
        print("🔧 Generando features adicionales...")
        
        # Posición de la transacción para cada cliente (secuencial)
        self.df_transacciones['posicion_transaccion'] = (
            self.df_transacciones.groupby('id').cumcount() + 1
        )
        
        # Gasto acumulado por cliente
        self.df_transacciones['gasto_acumulado'] = (
            self.df_transacciones.groupby('id')['monto'].cumsum()
        )
        
        # Ratio de gasto vs promedio histórico del cliente
        promedio_historico = (
            self.df_transacciones.groupby('id')['monto']
            .expanding()
            .mean()
            .reset_index(level=0, drop=True)
        )
        self.df_transacciones['ratio_vs_promedio'] = (
            self.df_transacciones['monto'] / promedio_historico
        ).fillna(1)
        
        print("✅ Features temporales creadas:")
        temporal_features = [
            'dia_semana', 'mes', 'trimestre', 'dia_mes', 'es_fin_semana',
            'dias_entre_transacciones', 'ventana_movil_30d', 'posicion_transaccion',
            'gasto_acumulado', 'ratio_vs_promedio'
        ]
        print(f"   {temporal_features}")
        
    def create_static_features_clients(self):
        """C2: Features Estáticas para Clientes"""
        print("\n=== C2: FEATURES ESTÁTICAS (CLIENTES) ===")
        
        # 1. One-Hot Encoding para variables categóricas
        print("🎯 Aplicando One-Hot Encoding...")
        
        categorical_cols = ['genero', 'tipo_persona']
        
        for col in categorical_cols:
            if col in self.df_clientes.columns:
                # One-Hot Encoding
                dummies = pd.get_dummies(self.df_clientes[col], prefix=col, dummy_na=False)
                self.df_clientes = pd.concat([self.df_clientes, dummies], axis=1)
                print(f"   ✅ {col}: {len(dummies.columns)} categorías")
        
        # 2. Binning para edad
        print("📊 Creando bins para edad...")
        
        if 'edad' in self.df_clientes.columns:
            # Definir bins de edad
            age_bins = [0, 25, 35, 45, 55, 65, 100]
            age_labels = ['18-25', '26-35', '36-45', '46-55', '56-65', '65+']
            
            self.df_clientes['edad_grupo'] = pd.cut(
                self.df_clientes['edad'], 
                bins=age_bins, 
                labels=age_labels, 
                include_lowest=True
            )
            
            # One-Hot para los grupos de edad
            edad_dummies = pd.get_dummies(self.df_clientes['edad_grupo'], prefix='edad')
            self.df_clientes = pd.concat([self.df_clientes, edad_dummies], axis=1)
            
            self.age_bins = age_bins
            print(f"   ✅ Edad: {len(age_labels)} grupos creados")
        
        # 3. Features adicionales de actividad empresarial
        print("🏢 Procesando actividad empresarial...")
        
        if 'actividad_empresarial' in self.df_clientes.columns:
            # Label encoding para actividad empresarial (muchas categorías)
            le_actividad = LabelEncoder()
            self.df_clientes['actividad_empresarial_encoded'] = le_actividad.fit_transform(
                self.df_clientes['actividad_empresarial'].fillna('Desconocido')
            )
            self.label_encoders['actividad_empresarial'] = le_actividad
            
            # Crear flag de actividad empresarial común
            actividades_comunes = (
                self.df_clientes['actividad_empresarial']
                .value_counts()
                .head(10)
                .index.tolist()
            )
            self.df_clientes['actividad_comun'] = (
                self.df_clientes['actividad_empresarial']
                .isin(actividades_comunes)
                .astype(int)
            )
            
            print(f"   ✅ Actividad empresarial: encoded + flag actividad común")
        
        # 4. Features geográficas
        print("🗺️ Procesando features geográficas...")

        if 'id_estado' in self.df_clientes.columns:
            # Crear feature de concentración por estado
            estado_counts = self.df_clientes['id_estado'].value_counts()
            self.df_clientes['concentracion_estado'] = (
                self.df_clientes['id_estado'].map(estado_counts)
            )
            
            # Binning para estados (pocos clientes vs muchos clientes)
            estado_percentiles = 4  # cuartiles
            try:
                estado_bins = pd.qcut(
                    self.df_clientes['concentracion_estado'],
                    q=estado_percentiles,
                    duplicates='drop'
                )

                # Verificar cuántos bins únicos se generaron realmente
                num_bins = estado_bins.cat.categories.size

                # Generar etiquetas según número de bins válidos
                etiquetas = {
                    4: ['Baja', 'Media-Baja', 'Media-Alta', 'Alta'],
                    3: ['Baja', 'Media', 'Alta'],
                    2: ['Baja', 'Alta'],
                    1: ['Única']
                }.get(num_bins, [f'Grupo{i+1}' for i in range(num_bins)])

                self.df_clientes['estado_densidad'] = pd.qcut(
                    self.df_clientes['concentracion_estado'],
                    q=num_bins,
                    labels=etiquetas,
                    duplicates='drop'
                )

                # One-Hot para densidad de estado
                densidad_dummies = pd.get_dummies(self.df_clientes['estado_densidad'], prefix='densidad_estado')
                self.df_clientes = pd.concat([self.df_clientes, densidad_dummies], axis=1)

                print("   ✅ Features geográficas: concentración + densidad por estado")

            except ValueError as e:
                print(f"❌ Error al aplicar qcut en concentración por estado: {e}")
                self.df_clientes['estado_densidad'] = 'Desconocido'

        
        print("✅ Features estáticas completadas")
        
    def create_sequence_features(self):
        """Crear features específicas para secuencias (CNN)"""
        print("\n=== FEATURES PARA SECUENCIAS CNN ===")
        
        # Crear secuencias de transacciones por cliente
        print("🔄 Generando secuencias por cliente...")
        
        sequences_data = []
        
        for cliente_id in self.df_transacciones['id'].unique():
            cliente_trans = self.df_transacciones[
                self.df_transacciones['id'] == cliente_id
            ].sort_values('fecha')
            
            if len(cliente_trans) >= 2:  # Mínimo 2 transacciones para secuencia
                # Features de secuencia
                sequence_features = {
                    'id': cliente_id,
                    'num_transacciones': len(cliente_trans),
                    'rango_fechas_dias': (cliente_trans['fecha'].max() - cliente_trans['fecha'].min()).days,
                    'transacciones_por_mes': len(cliente_trans) / max(1, (cliente_trans['fecha'].max() - cliente_trans['fecha'].min()).days / 30),
                    'variabilidad_dias_entre_trans': cliente_trans['dias_entre_transacciones'].std(),
                    'patron_fin_semana': cliente_trans['es_fin_semana'].mean(),
                    'estacionalidad_trimestre': cliente_trans['trimestre'].mode().iloc[0] if not cliente_trans['trimestre'].mode().empty else 1,
                    'comercio_favorito_freq': cliente_trans['comercio'].value_counts().iloc[0] / len(cliente_trans),
                    'crecimiento_gasto': (cliente_trans['monto'].iloc[-1] - cliente_trans['monto'].iloc[0]) / max(cliente_trans['monto'].iloc[0], 1)
                }
                
                sequences_data.append(sequence_features)
        
        self.df_sequences = pd.DataFrame(sequences_data)
        
        print(f"✅ Secuencias creadas para {len(self.df_sequences)} clientes")
        print("Features de secuencia:", list(self.df_sequences.columns[1:]))  # Exclude 'id'
        
    def merge_all_features(self):
        """Combinar todas las features en datasets finales"""
        print("\n=== COMBINANDO TODAS LAS FEATURES ===")
        
        # Merge clientes con features de secuencia
        self.df_clientes_final = self.df_clientes.merge(
            self.df_sequences, on='id', how='left'
        )
        
        # Rellenar NaN para clientes sin transacciones suficientes
        sequence_cols = [col for col in self.df_sequences.columns if col != 'id']
        for col in sequence_cols:
            self.df_clientes_final[col] = self.df_clientes_final[col].fillna(0)
        
        print(f"✅ Dataset final de clientes: {len(self.df_clientes_final)} registros")
        print(f"✅ Dataset final de transacciones: {len(self.df_transacciones)} registros")
        
    def get_feature_summary(self):
        """Resumen de features creadas"""
        print("\n" + "="*60)
        print("📊 RESUMEN DE FEATURE ENGINEERING")
        print("="*60)
        
        print(f"\n🎯 CLIENTES FINALES: {len(self.df_clientes_final)} registros")
        print(f"   📈 Total de features: {len(self.df_clientes_final.columns)}")
        
        # Categorizar features
        temporal_features = [col for col in self.df_clientes_final.columns if any(x in col.lower() for x in ['dia', 'mes', 'trimestre', 'fecha', 'tiempo'])]
        onehot_features = [col for col in self.df_clientes_final.columns if any(x in col for x in ['genero_', 'tipo_persona_', 'edad_', 'densidad_estado_'])]
        sequence_features = [col for col in self.df_clientes_final.columns if col in ['num_transacciones', 'transacciones_por_mes', 'variabilidad_dias_entre_trans', 'patron_fin_semana']]
        
        print(f"   🗓️ Features temporales: {len(temporal_features)}")
        print(f"   🎯 Features One-Hot: {len(onehot_features)}")
        print(f"   🔄 Features de secuencia: {len(sequence_features)}")
        
        print(f"\n💳 TRANSACCIONES FINALES: {len(self.df_transacciones)} registros")
        trans_features = [col for col in self.df_transacciones.columns if col not in ['id', 'fecha', 'comercio']]
        print(f"   📈 Features por transacción: {len(trans_features)}")
        
        print(f"\n📋 LISTO PARA CNN:")
        print("   ✅ Secuencias temporales por cliente")
        print("   ✅ Features estáticas por cliente") 
        print("   ✅ Features dinámicas por transacción")
        
    def run_feature_engineering(self, clientes_path, transacciones_path):
        """Ejecutar todo el pipeline de feature engineering"""
        print("🚀 INICIANDO FEATURE ENGINEERING")
        print("="*50)
        
        # Cargar datos preprocesados
        self.load_processed_data(clientes_path, transacciones_path)
        
        # Crear features temporales
        self.create_temporal_features_transactions()
        
        # Crear features estáticas
        self.create_static_features_clients()
        
        # Crear features de secuencia
        self.create_sequence_features()
        
        # Combinar todo
        self.merge_all_features()
        
        # Resumen
        self.get_feature_summary()
        
        print("\n✅ FEATURE ENGINEERING COMPLETADO")
        
        return self.df_clientes_final, self.df_transacciones

# EJEMPLO DE USO
if __name__ == "__main__":
    # Inicializar feature engineer
    feature_engineer = BankFeatureEngineer()
    
    # Ejecutar feature engineering completo
    clientes_con_features, transacciones_con_features = feature_engineer.run_feature_engineering(
        clientes_path='clientes_procesados.csv',
        transacciones_path='transacciones_procesadas.csv'
    )
    
    # Guardar datos con features
    clientes_con_features.to_csv('clientes_features.csv', index=False)
    transacciones_con_features.to_csv('transacciones_features.csv', index=False)
    
    print("\n💾 Datos con features guardados:")
    print("- clientes_features.csv")
    print("- transacciones_features.csv")
    
    # Mostrar sample de features creadas
    print("\n🔍 SAMPLE DE FEATURES CREADAS:")
    print("\nCLIENTES (columnas):")
    print(list(clientes_con_features.columns))
    
    print("\nTRANSACCIONES (nuevas features):")
    new_features = [col for col in transacciones_con_features.columns 
                   if col not in ['id', 'fecha', 'comercio', 'giro_comercio', 'tipo_venta', 'monto']]
    print(new_features)