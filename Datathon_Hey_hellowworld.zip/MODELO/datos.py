import pandas as pd
import numpy as np
from datetime import datetime, date
from sklearn.preprocessing import RobustScaler
from category_encoders import TargetEncoder
import warnings
warnings.filterwarnings('ignore')

class BankDataPreprocessor:
    """
    Preprocesador completo para datos bancarios del datathon
    """
    
    def __init__(self):
        self.robust_scaler = RobustScaler()
        self.target_encoder = TargetEncoder()
        self.frequency_encoder = {}
        
    def load_data(self, clientes_path, transacciones_path):
        """Cargar los CSVs"""
        print("Cargando datos...")
        self.df_clientes = pd.read_csv(clientes_path)
        self.df_transacciones = pd.read_csv(transacciones_path)
        
        print(f"Clientes: {len(self.df_clientes)} registros")
        print(f"Transacciones: {len(self.df_transacciones)} registros")
        
    def clean_clients_data(self):
        """B1: Limpieza de datos de clientes"""
        print("\n=== LIMPIEZA CLIENTES ===")
        
        # Eliminar duplicados
        inicial = len(self.df_clientes)
        self.df_clientes = self.df_clientes.drop_duplicates(subset=['id'])
        print(f"Duplicados eliminados: {inicial - len(self.df_clientes)}")
        
        # Tratar missings con "Desconocido" para categóricas
        categorical_cols = ['tipo_persona', 'genero', 'actividad_empresarial']
        for col in categorical_cols:
            if col in self.df_clientes.columns:
                self.df_clientes[col] = self.df_clientes[col].fillna('Desconocido')
                print(f"Missings en {col}: rellenados con 'Desconocido'")
        
        # Rellenar missings numéricos
        numeric_cols = ['id_municipio', 'id_estado']
        for col in numeric_cols:
            if col in self.df_clientes.columns:
                self.df_clientes[col] = self.df_clientes[col].fillna(0)
        
        print(f"Clientes después de limpieza: {len(self.df_clientes)}")
        
    def clean_transactions_data(self):
        """B1: Limpieza de datos de transacciones"""
        print("\n=== LIMPIEZA TRANSACCIONES ===")
        
        # Eliminar duplicados
        inicial = len(self.df_transacciones)
        self.df_transacciones = self.df_transacciones.drop_duplicates()
        print(f"Duplicados eliminados: {inicial - len(self.df_transacciones)}")
        
        # Filtrar outliers (monto > percentil 99)
        p99 = self.df_transacciones['monto'].quantile(0.99)
        inicial = len(self.df_transacciones)
        self.df_transacciones = self.df_transacciones[self.df_transacciones['monto'] <= p99]
        print(f"Outliers eliminados (monto > {p99:.2f}): {inicial - len(self.df_transacciones)}")
        
        # Tratar missings en monto con mediana
        if self.df_transacciones['monto'].isnull().sum() > 0:
            mediana_monto = self.df_transacciones['monto'].median()
            self.df_transacciones['monto'] = self.df_transacciones['monto'].fillna(mediana_monto)
            print(f"Missings en monto: rellenados con mediana {mediana_monto:.2f}")
        
        # Tratar missings en categóricas
        categorical_cols = ['comercio', 'giro_comercio', 'tipo_venta']
        for col in categorical_cols:
            if col in self.df_transacciones.columns:
                self.df_transacciones[col] = self.df_transacciones[col].fillna('Desconocido')
        
        print(f"Transacciones después de limpieza: {len(self.df_transacciones)}")
        
    def normalize_clients_data(self):
        """B2: Normalización de datos de clientes"""
        print("\n=== NORMALIZACIÓN CLIENTES ===")
        
        # Convertir fechas
        self.df_clientes['fecha_nacimiento'] = pd.to_datetime(self.df_clientes['fecha_nacimiento'], 
                                                            format='%d/%m/%Y', errors='coerce')
        self.df_clientes['fecha_alta'] = pd.to_datetime(self.df_clientes['fecha_alta'], 
                                                      format='%d/%m/%Y', errors='coerce')
        
        # Calcular edad
        fecha_actual = datetime.now()
        self.df_clientes['edad'] = (fecha_actual - self.df_clientes['fecha_nacimiento']).dt.days // 365
        self.df_clientes['edad'] = self.df_clientes['edad'].fillna(self.df_clientes['edad'].median())
        
        # Calcular antigüedad (días desde fecha_alta)
        self.df_clientes['antiguedad_dias'] = (fecha_actual - self.df_clientes['fecha_alta']).dt.days
        self.df_clientes['antiguedad_dias'] = self.df_clientes['antiguedad_dias'].fillna(0)
        
        # FrequencyEncoder para id_estado
        freq_counts = self.df_clientes['id_estado'].value_counts().to_dict()
        self.df_clientes['id_estado_freq'] = self.df_clientes['id_estado'].map(freq_counts)
        self.frequency_encoder['id_estado'] = freq_counts
        
        print("Características calculadas: edad, antigüedad_dias, id_estado_freq")
        
    def normalize_transactions_data(self):
        """B2: Normalización de datos de transacciones"""
        print("\n=== NORMALIZACIÓN TRANSACCIONES ===")
        
        # Convertir fecha
        self.df_transacciones['fecha'] = pd.to_datetime(self.df_transacciones['fecha'], 
                                                       format='%d/%m/%Y', errors='coerce')
        
        # Escalar monto con RobustScaler
        monto_original = self.df_transacciones['monto'].values.reshape(-1, 1)
        monto_scaled = self.robust_scaler.fit_transform(monto_original)
        self.df_transacciones['monto_scaled'] = monto_scaled.flatten()
        
        # TargetEncoder para giro_comercio (usando monto como target)
        self.df_transacciones['giro_comercio_encoded'] = self.target_encoder.fit_transform(
            self.df_transacciones['giro_comercio'], 
            self.df_transacciones['monto']
        )
        
        print("Transformaciones aplicadas: monto_scaled, giro_comercio_encoded")
        
    def calculate_client_metrics(self):
        """Calcular métricas agregadas por cliente"""
        print("\n=== CALCULANDO MÉTRICAS POR CLIENTE ===")
        
        # Agregar año-mes para cálculos mensuales
        self.df_transacciones['year_month'] = self.df_transacciones['fecha'].dt.to_period('M')
        
        # Métricas por cliente
        client_metrics = self.df_transacciones.groupby('id').agg({
            'monto': ['mean', 'sum', 'count', 'max', 'std'],
            'comercio': 'nunique',
            'year_month': 'nunique'
        }).round(2)
        
        # Aplanar columnas multinivel
        client_metrics.columns = ['_'.join(col).strip() for col in client_metrics.columns]
        
        # Renombrar columnas para mayor claridad
        client_metrics = client_metrics.rename(columns={
            'monto_mean': 'promedio_gasto_total',
            'monto_sum': 'gasto_total',
            'monto_count': 'frecuencia_transacciones',
            'monto_max': 'maximo_gasto_transaccion',
            'monto_std': 'variabilidad_gasto',
            'comercio_nunique': 'comercios_unicos',
            'year_month_nunique': 'meses_activos'
        })
        
        # Calcular promedio de gasto mensual
        client_metrics['promedio_gasto_mensual'] = (
            client_metrics['gasto_total'] / client_metrics['meses_activos']
        ).fillna(client_metrics['gasto_total'])
        
        # Máximo gasto en un solo comercio
        max_por_comercio = self.df_transacciones.groupby(['id', 'comercio'])['monto'].sum().groupby('id').max()
        client_metrics['maximo_gasto_comercio'] = max_por_comercio
        
        # Reset index para merge
        client_metrics = client_metrics.reset_index()
        
        # Merge con datos de clientes
        self.df_clientes_final = self.df_clientes.merge(client_metrics, on='id', how='left')
        
        # Rellenar NaN para clientes sin transacciones
        metrics_cols = [col for col in client_metrics.columns if col != 'id']
        for col in metrics_cols:
            self.df_clientes_final[col] = self.df_clientes_final[col].fillna(0)
        
        print(f"Métricas calculadas para {len(client_metrics)} clientes únicos")
        print("Métricas agregadas:", list(client_metrics.columns))
        
    def get_summary(self):
        """Resumen del preprocesamiento"""
        print("\n" + "="*50)
        print("RESUMEN DEL PREPROCESAMIENTO")
        print("="*50)
        
        print(f"\n📊 CLIENTES FINALES: {len(self.df_clientes_final)}")
        print("Columnas:", list(self.df_clientes_final.columns))
        
        print(f"\n💳 TRANSACCIONES FINALES: {len(self.df_transacciones)}")
        print("Columnas:", list(self.df_transacciones.columns))
        
        print(f"\n📈 ESTADÍSTICAS CLAVE:")
        print(f"- Promedio gasto mensual: ${self.df_clientes_final['promedio_gasto_mensual'].mean():.2f}")
        print(f"- Frecuencia transacciones promedio: {self.df_clientes_final['frecuencia_transacciones'].mean():.1f}")
        print(f"- Comercios únicos promedio: {self.df_clientes_final['comercios_unicos'].mean():.1f}")
        
    def run_preprocessing(self, clientes_path, transacciones_path):
        """Ejecutar todo el pipeline de preprocesamiento"""
        print("🚀 INICIANDO PREPROCESAMIENTO DATATHON BANCARIO")
        print("="*50)
        
        # Cargar datos
        self.load_data(clientes_path, transacciones_path)
        
        # Limpieza
        self.clean_clients_data()
        self.clean_transactions_data()
        
        # Normalización
        self.normalize_clients_data()
        self.normalize_transactions_data()
        
        # Métricas
        self.calculate_client_metrics()
        
        # Resumen
        self.get_summary()
        
        print("\n✅ PREPROCESAMIENTO COMPLETADO")
        
        return self.df_clientes_final, self.df_transacciones

# EJEMPLO DE USO
if __name__ == "__main__":
    # Inicializar preprocesador
    preprocessor = BankDataPreprocessor()
    
    # Ejecutar preprocesamiento completo
    # NOTA: Reemplaza con las rutas reales de tus archivos CSV
    clientes_procesados, transacciones_procesadas = preprocessor.run_preprocessing(
        clientes_path='clientes.csv',
        transacciones_path='transacciones.csv'
    )
    
    # Guardar datos procesados
    clientes_procesados.to_csv('clientes_procesados.csv', index=False)
    transacciones_procesadas.to_csv('transacciones_procesadas.csv', index=False)
    
    print("\n💾 Datos guardados:")
    print("- clientes_procesados.csv")
    print("- transacciones_procesadas.csv")
    
    # Mostrar ejemplos de los datos procesados
    print("\n🔍 MUESTRA DE DATOS PROCESADOS:")
    print("\nCLIENTES (primeras 3 filas):")
    print(clientes_procesados.head(3))
    
    print("\nTRANSACCIONES (primeras 3 filas):")
    print(transacciones_procesadas.head(3))