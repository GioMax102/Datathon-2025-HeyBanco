// lib/datasetLoader.ts - Enhanced dataset loader with multiple fallback strategies and configurable user display options

export interface RawDatathonUser {
  id: string
  fecha_nacimiento: string
  fecha_alta: string
  id_municipio: number
  id_estado: number
  tipo_persona: string
  genero: string
  actividad_empresarial: string
  // Add these if they exist in your dataset
  nombre?: string
  apellidos?: string
  nombre_completo?: string
}

export interface DatathonUser {
  user_id: string
  nombre: string
  apellidos: string
  saldo_actual: number
  fecha_nacimiento?: string
  fecha_alta?: string
  id_municipio?: number
  id_estado?: number
  tipo_persona?: string
  genero?: string
  actividad_empresarial?: string
}

export class DatasetLoader {
  private readonly githubUrls = [
    // Primary URL
    "https://raw.githubusercontent.com/Git-Pompeyo/Preccion1/refs/heads/main/backend/data/base_clientes_final.json",
    // Alternative URLs to try
    "https://raw.githubusercontent.com/Git-Pompeyo/Preccion1/main/backend/data/base_clientes_final.json",
    "https://api.github.com/repos/Git-Pompeyo/Preccion1/contents/backend/data/base_clientes_final.json",
  ]

  // Configuration for how to handle user names
  private readonly nameStrategy: "generate" | "use_id" | "use_real" | "anonymous" = "use_id" // Changed default

  async loadUsers(): Promise<DatathonUser[]> {
    // Try multiple strategies
    const strategies = [
      () => this.loadFromGitHubWithRetry(),
      () => this.loadFromGitHubAPI(),
      () => this.loadFromProxy(),
      () => this.getDemoUsersExtended(),
    ]

    for (const strategy of strategies) {
      try {
        const users = await strategy()
        if (users.length > 10) {
          // Only accept if we got a reasonable number of users
          return users
        }
      } catch (error) {
        console.warn("Strategy failed, trying next:", error.message)
        continue
      }
    }

    console.log("🔄 All strategies failed, using demo users")
    return this.getDemoUsers()
  }

  private async loadFromGitHubWithRetry(): Promise<DatathonUser[]> {
    for (const url of this.githubUrls) {
      try {
        console.log("📥 Trying GitHub URL:", url)

        const response = await fetch(url, {
          method: "GET",
          headers: {
            Accept: "application/json",
            "Cache-Control": "no-cache",
            "User-Agent": "Banking-App/1.0",
          },
          mode: "cors",
        })

        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: ${response.statusText}`)
        }

        const data = await response.json()

        // Handle GitHub API response format
        if (data.content && data.encoding === "base64") {
          const decodedContent = atob(data.content)
          const jsonData = JSON.parse(decodedContent)
          return this.transformAndValidateUsers(jsonData)
        }

        // Handle direct JSON response
        const rawUsers = Array.isArray(data) ? data : data.users || data.dataset || []
        return this.transformAndValidateUsers(rawUsers)
      } catch (error) {
        console.warn(`Failed to fetch from ${url}:`, error.message)
        continue
      }
    }

    throw new Error("All GitHub URLs failed")
  }

  private async loadFromGitHubAPI(): Promise<DatathonUser[]> {
    const apiUrl = "https://api.github.com/repos/Git-Pompeyo/Preccion1/contents/backend/data/base_clientes_final.json"

    console.log("📥 Trying GitHub API:", apiUrl)

    const response = await fetch(apiUrl, {
      headers: {
        Accept: "application/vnd.github.v3+json",
        "User-Agent": "Banking-App/1.0",
      },
    })

    if (!response.ok) {
      throw new Error(`GitHub API failed: ${response.status}`)
    }

    const data = await response.json()

    if (data.content && data.encoding === "base64") {
      const decodedContent = atob(data.content)
      const jsonData = JSON.parse(decodedContent)
      const rawUsers = Array.isArray(jsonData) ? jsonData : jsonData.users || jsonData.dataset || []
      return this.transformAndValidateUsers(rawUsers)
    }

    throw new Error("Invalid GitHub API response format")
  }

  private async loadFromProxy(): Promise<DatathonUser[]> {
    // Use a CORS proxy as fallback
    const proxyUrl = `https://api.allorigins.win/get?url=${encodeURIComponent(this.githubUrls[0])}`

    console.log("📥 Trying CORS proxy:", proxyUrl)

    const response = await fetch(proxyUrl)

    if (!response.ok) {
      throw new Error(`Proxy failed: ${response.status}`)
    }

    const data = await response.json()
    const jsonData = JSON.parse(data.contents)
    const rawUsers = Array.isArray(jsonData) ? jsonData : jsonData.users || jsonData.dataset || []
    return this.transformAndValidateUsers(rawUsers)
  }

  private transformAndValidateUsers(rawUsers: RawDatathonUser[]): DatathonUser[] {
    const validUsers: DatathonUser[] = []

    console.log(`🔄 Processing ${rawUsers.length} users from dataset...`)
    console.log(`📋 Name strategy: ${this.nameStrategy}`)

    rawUsers.forEach((rawUser, index) => {
      try {
        // Validate required fields
        if (!rawUser.id || typeof rawUser.id !== "string") {
          if (index < 5) console.warn(`User ${index}: Missing or invalid id`)
          return
        }

        // Handle names based on strategy
        const { nombre, apellidos } = this.getDisplayName(rawUser)

        const saldo_actual = this.generateBalanceFromUserData(rawUser)

        const transformedUser: DatathonUser = {
          user_id: rawUser.id, // Use the exact ID from dataset
          nombre,
          apellidos,
          saldo_actual,
          fecha_nacimiento: rawUser.fecha_nacimiento,
          fecha_alta: rawUser.fecha_alta,
          id_municipio: rawUser.id_municipio,
          id_estado: rawUser.id_estado,
          tipo_persona: rawUser.tipo_persona,
          genero: rawUser.genero?.trim(),
          actividad_empresarial: rawUser.actividad_empresarial,
        }

        validUsers.push(transformedUser)

        // Log first few users for debugging
        if (index < 5) {
          console.log(
            `✅ User ${index + 1}: ID=${transformedUser.user_id}, Display=${transformedUser.nombre} ${transformedUser.apellidos}`,
          )
        }
      } catch (error) {
        if (index < 5) console.warn(`Error transforming user ${index}:`, error)
      }
    })

    console.log(`✅ Successfully transformed ${validUsers.length} users from ${rawUsers.length} total`)

    // Log some sample user IDs for testing
    const sampleIds = validUsers.slice(0, 10).map((u) => u.user_id)
    console.log("🔑 Sample user IDs for testing:", sampleIds)

    return validUsers
  }

  private getDisplayName(user: RawDatathonUser): { nombre: string; apellidos: string } {
    switch (this.nameStrategy) {
      case "use_real":
        // Use real names if they exist in dataset
        if (user.nombre && user.apellidos) {
          return { nombre: user.nombre, apellidos: user.apellidos }
        }
        if (user.nombre_completo) {
          const parts = user.nombre_completo.split(" ")
          return {
            nombre: parts[0] || "Usuario",
            apellidos: parts.slice(1).join(" ") || "",
          }
        }
        // Fallback to ID if no real names
        return { nombre: `Usuario`, apellidos: user.id }

      case "use_id":
        // Just use the ID as display name
        return { nombre: `Usuario`, apellidos: user.id }

      case "anonymous":
        // Anonymous display
        return { nombre: "Usuario", apellidos: "Anónimo" }

      case "generate":
      default:
        // Generate realistic names (original approach)
        return this.generateNamesFromUserData(user)
    }
  }

  private generateNamesFromUserData(user: RawDatathonUser): { nombre: string; apellidos: string } {
    // Mexican names based on INEGI data
    const maleNames = [
      "José", // Most common
      "Luis",
      "Juan",
      "Miguel",
      "Carlos",
      "Antonio",
      "Francisco",
      "Alejandro",
      "Roberto",
      "Fernando",
    ]

    const femaleNames = [
      "María", // Most common
      "Guadalupe",
      "Rosa",
      "Josefina",
      "Ana",
      "Carmen",
      "Elena",
      "Patricia",
      "Laura",
      "Sofía",
    ]

    const surnames = [
      "García", // Most common Mexican surnames
      "Rodríguez",
      "López",
      "Martínez",
      "González",
      "Pérez",
      "Sánchez",
      "Ramírez",
      "Cruz",
      "Flores",
      "Morales",
      "Jiménez",
      "Hernández",
      "Torres",
      "Vargas",
    ]

    const isGeneroMasculino =
      user.genero?.trim().toLowerCase().includes("m") ||
      user.genero?.trim().toLowerCase().includes("h") ||
      Math.random() > 0.5

    const nombres = isGeneroMasculino ? maleNames : femaleNames

    // Use user ID for consistent generation
    const idHash = user.id.split("").reduce((a, b) => {
      a = (a << 5) - a + b.charCodeAt(0)
      return a & a
    }, 0)

    const nameIndex = Math.abs(idHash) % nombres.length
    const surname1Index = Math.abs(idHash * 7) % surnames.length
    const surname2Index = Math.abs(idHash * 13) % surnames.length

    return {
      nombre: nombres[nameIndex],
      apellidos: `${surnames[surname1Index]} ${surnames[surname2Index]}`,
    }
  }

  private generateBalanceFromUserData(user: RawDatathonUser): number {
    let baseBalance = 25000

    if (user.actividad_empresarial?.includes("EMPLEADO")) {
      baseBalance += Math.random() * 30000
    } else if (user.actividad_empresarial?.includes("PROFESIONAL")) {
      baseBalance += Math.random() * 50000
    } else if (user.actividad_empresarial?.includes("EMPRESARIO")) {
      baseBalance += Math.random() * 100000
    }

    if (user.fecha_alta) {
      const altaDate = new Date(user.fecha_alta)
      const yearsActive = (Date.now() - altaDate.getTime()) / (1000 * 60 * 60 * 24 * 365)
      baseBalance += yearsActive * 2000
    }

    const idHash = user.id.split("").reduce((a, b) => {
      a = (a << 5) - a + b.charCodeAt(0)
      return a & a
    }, 0)

    const variation = ((Math.abs(idHash) % 100) / 100) * 0.4 - 0.2
    const finalBalance = baseBalance * (1 + variation)

    return Math.max(1000, Math.round(finalBalance * 100) / 100)
  }

  private getDemoUsers(): DatathonUser[] {
    return [
      {
        user_id: "a010",
        nombre: "Usuario",
        apellidos: "a010",
        saldo_actual: 45420.75,
        fecha_nacimiento: "1984-06-19",
        fecha_alta: "2015-10-25",
        id_municipio: 6822006,
        id_estado: 68,
        tipo_persona: "Persona Fisica Sin Actividad Empresarial",
        genero: "F",
        actividad_empresarial: "EMPLEADO DEL SECTOR SERVICIOS",
      },
      {
        user_id: "a011",
        nombre: "Usuario",
        apellidos: "a011",
        saldo_actual: 23150.3,
        fecha_nacimiento: "1990-03-15",
        fecha_alta: "2018-05-12",
        id_municipio: 6822006,
        id_estado: 68,
        tipo_persona: "Persona Fisica Sin Actividad Empresarial",
        genero: "M",
        actividad_empresarial: "EMPLEADO DEL SECTOR SERVICIOS",
      },
      {
        user_id: "a012",
        nombre: "Usuario",
        apellidos: "a012",
        saldo_actual: 67890.45,
        fecha_nacimiento: "1987-11-08",
        fecha_alta: "2016-02-20",
        id_municipio: 6822006,
        id_estado: 68,
        tipo_persona: "Persona Fisica Sin Actividad Empresarial",
        genero: "F",
        actividad_empresarial: "PROFESIONAL INDEPENDIENTE",
      },
    ]
  }

  private getDemoUsersExtended(): DatathonUser[] {
    const demoUsers: DatathonUser[] = []

    for (let i = 10; i < 50; i++) {
      const id = `a${i.toString().padStart(3, "0")}`

      demoUsers.push({
        user_id: id,
        nombre: "Usuario",
        apellidos: id,
        saldo_actual: 20000 + Math.random() * 50000,
        fecha_nacimiento: `198${(i % 9) + 1}-${String((i % 12) + 1).padStart(2, "0")}-${String((i % 28) + 1).padStart(2, "0")}`,
        fecha_alta: `201${(i % 9) + 1}-${String((i % 12) + 1).padStart(2, "0")}-${String((i % 28) + 1).padStart(2, "0")}`,
        id_municipio: 6822006 + (i % 100),
        id_estado: 68,
        tipo_persona: "Persona Fisica Sin Actividad Empresarial",
        genero: i % 2 === 0 ? "M" : "F",
        actividad_empresarial: i % 3 === 0 ? "EMPLEADO DEL SECTOR SERVICIOS" : "PROFESIONAL INDEPENDIENTE",
      })
    }

    console.log(`🔄 Generated ${demoUsers.length} extended demo users`)
    return demoUsers
  }
}
