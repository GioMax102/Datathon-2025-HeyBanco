export interface ModelRequest {
  user_id: string
  // Add other parameters your model might need
  days_ahead?: number
  include_recurring?: boolean
}

export interface ModelResponse {
  comercio: string
  monto_predicho: number
  fecha_predicha: string
  tipo_recurrencia: "predicha"
}

export class DatathonModelAdapter {
  private endpoint: string
  private apiKey: string

  constructor(endpoint: string) {
    this.endpoint = endpoint
    this.apiKey = "123456789" // Your provided API key
    console.log("🔧 DatathonModelAdapter initialized")
    console.log("🔗 Endpoint configured:", this.endpoint)
    console.log("🔑 API Key configured:", this.apiKey ? "✅ Present" : "❌ Missing")
  }

  async callModel(request: ModelRequest): Promise<ModelResponse[]> {
    console.log("🚀 Starting model call process...")
    console.log("🔗 Target endpoint:", this.endpoint)
    console.log("📤 Request payload:", JSON.stringify(request, null, 2))
    console.log("🕐 Timestamp:", new Date().toISOString())

    // Try multiple strategies to call the model
    const strategies = [
      { name: "Bearer Token", fn: () => this.callWithBearer(request) },
      { name: "API Key Headers", fn: () => this.callWithApiKey(request) },
      { name: "No Authentication", fn: () => this.callWithoutAuth(request) },
      { name: "Form Data", fn: () => this.callWithFormData(request) },
    ]

    let lastError: Error | null = null

    for (let i = 0; i < strategies.length; i++) {
      const strategy = strategies[i]
      try {
        console.log(`🔄 Attempting strategy ${i + 1}/${strategies.length}: ${strategy.name}`)
        console.log(`⏱️ Strategy start time:`, new Date().toISOString())

        const result = await strategy.fn()

        console.log(`✅ SUCCESS! Strategy "${strategy.name}" worked`)
        console.log(`📥 Received ${result.length} predictions`)
        console.log(`⏱️ Strategy completion time:`, new Date().toISOString())

        return result
      } catch (error) {
        lastError = error as Error
        console.error(`❌ Strategy "${strategy.name}" failed:`)
        console.error(`   Error type: ${error instanceof Error ? error.constructor.name : typeof error}`)
        console.error(`   Error message: ${error instanceof Error ? error.message : String(error)}`)

        if (i < strategies.length - 1) {
          console.log(`🔄 Trying next strategy...`)
        }
      }
    }

    console.error("❌ ALL STRATEGIES FAILED!")
    console.error("📋 Final error details:")
    console.error(`   Last error: ${lastError?.message}`)
    console.error(`   Endpoint: ${this.endpoint}`)
    console.error(`   User ID: ${request.user_id}`)
    console.error(`   Timestamp: ${new Date().toISOString()}`)

    throw lastError || new Error("All model call strategies failed")
  }

  private async callWithBearer(request: ModelRequest): Promise<ModelResponse[]> {
    console.log("🔐 Using Bearer token authentication")

    const headers = {
      "Content-Type": "application/json",
      Authorization: `Bearer ${this.apiKey}`,
    }

    console.log("📋 Request headers:", JSON.stringify(headers, null, 2))

    const response = await fetch(this.endpoint, {
      method: "POST",
      headers,
      body: JSON.stringify(request),
    })

    return this.handleResponse(response, "Bearer Token")
  }

  private async callWithApiKey(request: ModelRequest): Promise<ModelResponse[]> {
    console.log("🔑 Using API key headers")

    const headers = {
      "Content-Type": "application/json",
      "X-API-Key": this.apiKey,
      "api-key": this.apiKey,
    }

    console.log("📋 Request headers:", JSON.stringify(headers, null, 2))

    const response = await fetch(this.endpoint, {
      method: "POST",
      headers,
      body: JSON.stringify(request),
    })

    return this.handleResponse(response, "API Key Headers")
  }

  private async callWithoutAuth(request: ModelRequest): Promise<ModelResponse[]> {
    console.log("🔓 Using no authentication")

    const headers = {
      "Content-Type": "application/json",
    }

    console.log("📋 Request headers:", JSON.stringify(headers, null, 2))

    const response = await fetch(this.endpoint, {
      method: "POST",
      headers,
      body: JSON.stringify(request),
    })

    return this.handleResponse(response, "No Authentication")
  }

  private async callWithFormData(request: ModelRequest): Promise<ModelResponse[]> {
    console.log("📝 Using FormData format")

    const formData = new FormData()
    formData.append("user_id", request.user_id)
    formData.append("days_ahead", String(request.days_ahead || 30))
    formData.append("include_recurring", String(request.include_recurring || true))

    console.log("📋 FormData entries:")
    for (const [key, value] of formData.entries()) {
      console.log(`   ${key}: ${value}`)
    }

    const headers = {
      Authorization: `Bearer ${this.apiKey}`,
    }

    console.log("📋 Request headers:", JSON.stringify(headers, null, 2))

    const response = await fetch(this.endpoint, {
      method: "POST",
      headers,
      body: formData,
    })

    return this.handleResponse(response, "Form Data")
  }

  private async handleResponse(response: Response, strategyName: string): Promise<ModelResponse[]> {
    console.log(`📥 Response received for strategy "${strategyName}":`)
    console.log(`   Status: ${response.status} ${response.statusText}`)
    console.log(`   OK: ${response.ok}`)
    console.log(`   URL: ${response.url}`)
    console.log(`   Type: ${response.type}`)

    const responseHeaders = Object.fromEntries(response.headers.entries())
    console.log(`   Headers:`, JSON.stringify(responseHeaders, null, 2))

    if (!response.ok) {
      let errorText: string
      try {
        errorText = await response.text()
        console.error(`❌ Error response body:`, errorText)
      } catch (e) {
        errorText = "Could not read error response"
        console.error(`❌ Could not read error response:`, e)
      }

      throw new Error(`HTTP ${response.status}: ${errorText}`)
    }

    let data: any
    try {
      const responseText = await response.text()
      console.log(`📄 Raw response text:`, responseText.substring(0, 500) + (responseText.length > 500 ? "..." : ""))

      data = JSON.parse(responseText)
      console.log(`📊 Parsed JSON response:`, JSON.stringify(data, null, 2))
    } catch (e) {
      console.error(`❌ Failed to parse JSON response:`, e)
      throw new Error(`Invalid JSON response: ${e}`)
    }

    // Transform the response to match our expected format
    const transformed = this.transformResponse(data)
    console.log(`✅ Successfully transformed ${transformed.length} predictions`)

    return transformed
  }

  private transformResponse(data: any): ModelResponse[] {
    console.log("🔄 Starting response transformation...")
    console.log("📊 Input data type:", typeof data)
    console.log("📊 Input data:", JSON.stringify(data, null, 2))

    // Handle different response formats from your model
    let predictions: any[] = []

    if (Array.isArray(data)) {
      console.log("✅ Data is already an array")
      predictions = data
    } else if (data.predictions) {
      console.log("✅ Found predictions field")
      predictions = data.predictions
    } else if (data.results) {
      console.log("✅ Found results field")
      predictions = data.results
    } else if (data.data) {
      console.log("✅ Found data field")
      predictions = data.data
    } else if (data.prediction) {
      console.log("✅ Found single prediction field")
      predictions = [data.prediction]
    } else {
      console.log("✅ Treating as single prediction object")
      predictions = [data]
    }

    console.log(`🔄 Extracted ${predictions.length} raw predictions:`)
    predictions.forEach((pred, index) => {
      console.log(`   Prediction ${index + 1}:`, JSON.stringify(pred, null, 2))
    })

    const transformed = predictions.map((pred: any, index: number) => {
      console.log(`🔄 Transforming prediction ${index + 1}:`)

      const comercio = pred.comercio || pred.merchant || pred.store || pred.business || "COMERCIO"
      const monto = Number(pred.monto_predicho || pred.amount || pred.predicted_amount || pred.value || 0)
      const fecha = pred.fecha_predicha || pred.date || pred.predicted_date || pred.when || this.getDefaultDate()

      console.log(`   comercio: ${comercio}`)
      console.log(`   monto_predicho: ${monto}`)
      console.log(`   fecha_predicha: ${fecha}`)

      return {
        comercio,
        monto_predicho: monto,
        fecha_predicha: fecha,
        tipo_recurrencia: "predicha" as const,
      }
    })

    console.log(`✅ Final transformed predictions:`)
    transformed.forEach((pred, index) => {
      console.log(`   ${index + 1}. ${pred.comercio}: $${pred.monto_predicho} on ${pred.fecha_predicha}`)
    })

    return transformed
  }

  private getDefaultDate(): string {
    const date = new Date()
    date.setDate(date.getDate() + Math.floor(Math.random() * 30) + 1)
    const formatted = date.toISOString().split("T")[0]
    console.log(`🗓️ Generated default date: ${formatted}`)
    return formatted
  }

  // Test if the endpoint is reachable - simplified version
  async testConnection(): Promise<boolean> {
    console.log("🔍 Starting simplified connection test...")

    // Skip actual network test during development
    // This prevents initialization errors
    console.log("🔄 Skipping network test during development")
    console.log("🎭 Connection test will be performed when model is actually called")

    return false // Always return false to use demo mode during development
  }
}
