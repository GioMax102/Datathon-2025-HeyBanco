// lib/bankingService.ts
import helloWorldMachine from "@/lib/helloWorldMachine"
import { datathonService } from "@/lib/datathonService"

export interface Usuario {
  id: string
  nombre: string
  apellidos: string
  email: string
  telefono: string
  fechaNacimiento: string
  direccion: {
    calle: string
    ciudad: string
    estado: string
    codigoPostal: string
  }
  saldo: number
  monedas: number
  referidos: number
  nivelCliente: "Básico" | "Premium" | "Elite"
  fechaRegistro: string
  ultimoAcceso: string
  scoring: number
  limiteCredito: number
  cuentasActivas: string[]
  // Add datathon integration
  isDatathonUser?: boolean
  datathonUserId?: string
}

export interface Transaccion {
  id: string
  fecha: string
  monto: number
  tipo: "ingreso" | "egreso" | "transferencia"
  categoria: string
  subcategoria?: string
  descripcion: string
  comercio?: string
  ubicacion?: {
    lat: number
    lng: number
    direccion: string
  }
  metodoPago: string
  numeroTarjeta?: string
  autorizacion: string
  estado: "completada" | "pendiente" | "cancelada" | "revertida"
  comision?: number
  tasa?: number
  saldoAnterior: number
  saldoPosterior: number
  etiquetas?: string[]
}

export interface ProductoBancario {
  id: string
  tipo: "cuenta" | "tarjeta_credito" | "tarjeta_debito" | "credito" | "inversion" | "seguro"
  nombre: string
  numero: string
  saldo?: number
  limite?: number
  fechaVencimiento?: string
  tasa: number
  estado: "activo" | "bloqueado" | "cancelado"
  fechaApertura: string
  beneficios: string[]
  costoAnual?: number
  rendimiento?: number
}

export interface Notificacion {
  id: string
  tipo: "transaccion" | "seguridad" | "promocion" | "vencimiento" | "limite" | "meta" | "sistema"
  titulo: string
  mensaje: string
  fecha: string
  leida: boolean
  prioridad: "baja" | "media" | "alta" | "critica"
  categoria: string
  acciones?: {
    texto: string
    tipo: "primary" | "secondary" | "danger"
    accion: string
  }[]
  metadatos?: Record<string, any>
}

export interface MetaFinanciera {
  id: string
  nombre: string
  descripcion: string
  objetivo: number
  actual: number
  fechaLimite: string
  fechaCreacion: string
  categoria: "ahorro" | "inversion" | "pago_deuda" | "compra" | "emergencia"
  prioridad: "baja" | "media" | "alta"
  estado: "activa" | "pausada" | "completada" | "vencida"
  aporteAutomatico?: {
    activo: boolean
    monto: number
    frecuencia: "semanal" | "quincenal" | "mensual"
    fechaProximo: string
  }
  recordatorios: boolean
}

export interface AnalisisFinanciero {
  ingresosMensuales: number
  gastosMensuales: number
  ahorroPromedio: number
  categoriasMasGasto: { categoria: string; monto: number; porcentaje: number }[]
  tendenciaGastos: "creciente" | "estable" | "decreciente"
  saludFinanciera: number
  recomendaciones: string[]
  alertas: string[]
  patrimonio: {
    activos: number
    pasivos: number
    patrimonioNeto: number
  }
}

class BankingService {
  private usuarios: Map<string, Usuario> = new Map()
  private transacciones: Map<string, Transaccion[]> = new Map()
  private productos: Map<string, ProductoBancario[]> = new Map()
  private notificaciones: Map<string, Notificacion[]> = new Map()
  private metas: Map<string, MetaFinanciera[]> = new Map()

  constructor() {
    this.initializeDemoData()
  }

  private initializeDemoData() {
    const usuarioDemo: Usuario = {
      id: "user_demo_123",
      nombre: "María Elena",
      apellidos: "González Ramírez",
      email: "maria.gonzalez@email.com",
      telefono: "+52 81 1234 5678",
      fechaNacimiento: "1990-05-15",
      direccion: {
        calle: "Av. Constitución 123, Col. Centro",
        ciudad: "Monterrey",
        estado: "Nuevo León",
        codigoPostal: "64000",
      },
      saldo: 45420.75,
      monedas: 3850,
      referidos: 18,
      nivelCliente: "Premium",
      fechaRegistro: "2023-01-15",
      ultimoAcceso: new Date().toISOString(),
      scoring: 720,
      limiteCredito: 85000,
      cuentasActivas: ["hey_cuenta_001", "hey_credito_001"],
    }

    this.usuarios.set("demo", usuarioDemo)
    this.generateDemoTransactions("user_demo_123")
    this.generateDemoProducts("user_demo_123")
    this.generateDemoNotifications("user_demo_123")
    this.generateDemoMetas("user_demo_123")
  }

  private generateDemoTransactions(userId: string) {
    const transacciones: Transaccion[] = [
      {
        id: "txn_001",
        fecha: "2025-05-25T08:30:00Z",
        monto: -850.5,
        tipo: "egreso",
        categoria: "Alimentación",
        subcategoria: "Supermercado",
        descripcion: "Soriana Híper Centro",
        comercio: "Soriana",
        ubicacion: {
          lat: 25.6714,
          lng: -100.3095,
          direccion: "Av. Constitución 300, Centro, Monterrey",
        },
        metodoPago: "Tarjeta Débito",
        numeroTarjeta: "**** 4521",
        autorizacion: "AUTH123456",
        estado: "completada",
        saldoAnterior: 46271.25,
        saldoPosterior: 45420.75,
        etiquetas: ["recurrente", "necesario"],
      },
      {
        id: "txn_002",
        fecha: "2025-05-24T19:45:00Z",
        monto: -320.0,
        tipo: "egreso",
        categoria: "Transporte",
        subcategoria: "Ride Sharing",
        descripcion: "Uber - Viaje al Centro",
        comercio: "Uber",
        metodoPago: "Tarjeta Crédito",
        numeroTarjeta: "**** 8901",
        autorizacion: "AUTH789012",
        estado: "completada",
        saldoAnterior: 46591.25,
        saldoPosterior: 46271.25,
        etiquetas: ["ocasional"],
      },
      {
        id: "txn_003",
        fecha: "2025-05-24T14:20:00Z",
        monto: 15000.0,
        tipo: "ingreso",
        categoria: "Salario",
        descripcion: "Nómina Quincenal - TechCorp SA",
        metodoPago: "Transferencia Bancaria",
        autorizacion: "PAYROLL_052425",
        estado: "completada",
        saldoAnterior: 31591.25,
        saldoPosterior: 46591.25,
        etiquetas: ["ingreso_fijo", "nomina"],
      },
      // Agregar más transacciones...
    ]

    this.transacciones.set(userId, transacciones)
  }

  private generateDemoProducts(userId: string) {
    const productos: ProductoBancario[] = [
      {
        id: "hey_cuenta_001",
        tipo: "cuenta",
        nombre: "Cuenta Hey Premium",
        numero: "**** **** **** 4521",
        saldo: 45420.75,
        tasa: 2.5,
        estado: "activo",
        fechaApertura: "2023-01-15",
        beneficios: [
          "Sin comisiones",
          "Rendimiento 2.5% anual",
          "Transferencias ilimitadas",
          "Tarjeta de débito gratis",
        ],
      },
      {
        id: "hey_credito_001",
        tipo: "tarjeta_credito",
        nombre: "Tarjeta Hey Cashback",
        numero: "**** **** **** 8901",
        limite: 85000,
        saldo: 12500,
        tasa: 24.9,
        fechaVencimiento: "2028-12-31",
        estado: "activo",
        fechaApertura: "2023-03-10",
        beneficios: [
          "2% cashback en supermercados",
          "1.5% cashback en gasolina",
          "1% cashback en todo lo demás",
          "Sin anualidad primer año",
        ],
        costoAnual: 1200,
      },
    ]

    this.productos.set(userId, productos)
  }

  private generateDemoNotifications(userId: string) {
    const notificaciones: Notificacion[] = [
      {
        id: "notif_001",
        tipo: "seguridad",
        titulo: "Inicio de sesión detectado",
        mensaje: "Se detectó un inicio de sesión en tu cuenta desde un nuevo dispositivo",
        fecha: new Date().toISOString(),
        leida: false,
        prioridad: "alta",
        categoria: "Seguridad",
        acciones: [
          { texto: "Revisar actividad", tipo: "primary", accion: "view_activity" },
          { texto: "No soy yo", tipo: "danger", accion: "report_suspicious" },
        ],
      },
      {
        id: "notif_002",
        tipo: "limite",
        titulo: "Límite de gasto alcanzado",
        mensaje: "Has alcanzado el 80% de tu límite semanal de gastos ($2,800)",
        fecha: new Date(Date.now() - 3600000).toISOString(),
        leida: false,
        prioridad: "media",
        categoria: "Presupuesto",
        acciones: [{ texto: "Ajustar límite", tipo: "primary", accion: "adjust_limit" }],
      },
    ]

    this.notificaciones.set(userId, notificaciones)
  }

  private generateDemoMetas(userId: string) {
    const metas: MetaFinanciera[] = [
      {
        id: "meta_001",
        nombre: "Fondo de Emergencia",
        descripcion: "Ahorrar 6 meses de gastos como fondo de emergencia",
        objetivo: 150000,
        actual: 89500,
        fechaLimite: "2025-12-31",
        fechaCreacion: "2024-01-01",
        categoria: "emergencia",
        prioridad: "alta",
        estado: "activa",
        aporteAutomatico: {
          activo: true,
          monto: 5000,
          frecuencia: "mensual",
          fechaProximo: "2025-06-01",
        },
        recordatorios: true,
      },
      {
        id: "meta_002",
        nombre: "Vacaciones Europa 2025",
        descripcion: "Viaje de 15 días por Europa en diciembre",
        objetivo: 80000,
        actual: 32000,
        fechaLimite: "2025-11-30",
        fechaCreacion: "2024-06-01",
        categoria: "compra",
        prioridad: "media",
        estado: "activa",
        recordatorios: true,
      },
    ]

    this.metas.set(userId, metas)
  }

  // Métodos públicos
  async authenticate(username: string, password: string): Promise<Usuario | null> {
    // First try datathon authentication
    try {
      const datathonUser = await datathonService.authenticate(username, password)
      if (datathonUser) {
        // Convert datathon user to app user format
        const usuario: Usuario = {
          id: datathonUser.user_id,
          nombre: datathonUser.nombre,
          apellidos: datathonUser.apellidos,
          email: `${datathonUser.user_id}@datathon.com`,
          telefono: "+52 81 0000 0000",
          fechaNacimiento: "1990-01-01",
          direccion: {
            calle: "Dirección del dataset",
            ciudad: "Ciudad",
            estado: "Estado",
            codigoPostal: "00000",
          },
          saldo: datathonUser.saldo_actual,
          monedas: 1000,
          referidos: 5,
          nivelCliente: "Premium",
          fechaRegistro: "2024-01-01",
          ultimoAcceso: new Date().toISOString(),
          scoring: 720,
          limiteCredito: 50000,
          cuentasActivas: ["datathon_account"],
          isDatathonUser: true,
          datathonUserId: datathonUser.user_id,
        }

        return usuario
      }
    } catch (error) {
      console.error("Datathon auth error:", error)
    }

    // Fallback to demo authentication
    await new Promise((resolve) => setTimeout(resolve, 1000))

    if (username === "demo" && password === "123456") {
      const usuario = this.usuarios.get("demo")!
      usuario.ultimoAcceso = new Date().toISOString()
      return usuario
    }

    return null
  }

  async getTransacciones(
    userId: string,
    filtros?: {
      fechaInicio?: string
      fechaFin?: string
      categoria?: string
      tipo?: string
      limite?: number
    },
  ): Promise<Transaccion[]> {
    let transacciones = this.transacciones.get(userId) || []

    if (filtros) {
      if (filtros.categoria) {
        transacciones = transacciones.filter((t) => t.categoria === filtros.categoria)
      }
      if (filtros.tipo) {
        transacciones = transacciones.filter((t) => t.tipo === filtros.tipo)
      }
      if (filtros.limite) {
        transacciones = transacciones.slice(0, filtros.limite)
      }
    }

    return transacciones.sort((a, b) => new Date(b.fecha).getTime() - new Date(a.fecha).getTime())
  }

  async getProductos(userId: string): Promise<ProductoBancario[]> {
    return this.productos.get(userId) || []
  }

  async getNotificaciones(userId: string): Promise<Notificacion[]> {
    return this.notificaciones.get(userId) || []
  }

  async getMetas(userId: string): Promise<MetaFinanciera[]> {
    return this.metas.get(userId) || []
  }

  async getAnalisisFinanciero(userId: string): Promise<AnalisisFinanciero> {
    const transacciones = await this.getTransacciones(userId)
    const productos = await this.getProductos(userId)

    // Calcular análisis
    const ingresos = transacciones.filter((t) => t.tipo === "ingreso")
    const gastos = transacciones.filter((t) => t.tipo === "egreso")

    const ingresosMensuales = ingresos.reduce((sum, t) => sum + t.monto, 0)
    const gastosMensuales = Math.abs(gastos.reduce((sum, t) => sum + t.monto, 0))

    // Categorías más gastadas
    const categoriasMasGasto = gastos.reduce(
      (acc, t) => {
        acc[t.categoria] = (acc[t.categoria] || 0) + Math.abs(t.monto)
        return acc
      },
      {} as Record<string, number>,
    )

    const categoriasOrdenadas = Object.entries(categoriasMasGasto)
      .map(([categoria, monto]) => ({
        categoria,
        monto,
        porcentaje: (monto / gastosMensuales) * 100,
      }))
      .sort((a, b) => b.monto - a.monto)

    return {
      ingresosMensuales,
      gastosMensuales,
      ahorroPromedio: ingresosMensuales - gastosMensuales,
      categoriasMasGasto: categoriasOrdenadas,
      tendenciaGastos: "estable",
      saludFinanciera: 78,
      recomendaciones: [
        "Considera aumentar tu fondo de emergencia",
        "Evalúa reducir gastos en entretenimiento",
        "Excelente control en gastos de alimentación",
      ],
      alertas: ["Tu gasto en transporte aumentó 15% este mes"],
      patrimonio: {
        activos: 145420,
        pasivos: 12500,
        patrimonioNeto: 132920,
      },
    }
  }

  async getPredictionsAI(userId: string): Promise<any> {
    const transacciones = await this.getTransacciones(userId, { limite: 50 })
    const historial = transacciones.map((t) => ({
      fecha: t.fecha,
      monto: Math.abs(t.monto),
      giro: t.categoria,
      descripcion: t.descripcion,
    }))

    try {
      return await helloWorldMachine.predecir(historial)
    } catch (error) {
      console.error("Error en predicciones IA:", error)
      return ["user_demo_123", []]
    }
  }

  // Métodos para actualizar datos
  async marcarNotificacionLeida(userId: string, notifId: string): Promise<void> {
    const notificaciones = this.notificaciones.get(userId) || []
    const notif = notificaciones.find((n) => n.id === notifId)
    if (notif) {
      notif.leida = true
    }
  }

  async crearMeta(
    userId: string,
    meta: Omit<MetaFinanciera, "id" | "fechaCreacion" | "actual" | "estado">,
  ): Promise<string> {
    const metas = this.metas.get(userId) || []
    const nuevaMeta: MetaFinanciera = {
      ...meta,
      id: `meta_${Date.now()}`,
      fechaCreacion: new Date().toISOString(),
      actual: 0,
      estado: "activa",
    }
    metas.push(nuevaMeta)
    this.metas.set(userId, metas)
    return nuevaMeta.id
  }

  async actualizarMeta(userId: string, metaId: string, actualizacion: Partial<MetaFinanciera>): Promise<void> {
    const metas = this.metas.get(userId) || []
    const meta = metas.find((m) => m.id === metaId)
    if (meta) {
      Object.assign(meta, actualizacion)
    }
  }
}

export const bankingService = new BankingService()
