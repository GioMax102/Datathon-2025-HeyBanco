// lib/themeSystem.ts
import { useState, useEffect, createContext, useContext } from 'react'

export type ThemeMode = 'dark' | 'light' | 'auto' | 'midnight' | 'ocean' | 'forest'

export interface Theme {
  mode: ThemeMode
  colors: {
    primary: string
    secondary: string
    accent: string
    background: string
    surface: string
    text: string
    textSecondary: string
    success: string
    warning: string
    error: string
    gradientStart: string
    gradientEnd: string
  }
  effects: {
    glassmorphism: boolean
    animations: boolean
    haptics: boolean
    soundEffects: boolean
  }
}

const themes: Record<ThemeMode, Theme> = {
  dark: {
    mode: 'dark',
    colors: {
      primary: '#8B5CF6',
      secondary: '#3B82F6',
      accent: '#F59E0B',
      background: '#111827',
      surface: '#1F2937',
      text: '#F9FAFB',
      textSecondary: '#9CA3AF',
      success: '#10B981',
      warning: '#F59E0B',
      error: '#EF4444',
      gradientStart: '#7C3AED',
      gradientEnd: '#3B82F6'
    },
    effects: {
      glassmorphism: true,
      animations: true,
      haptics: true,
      soundEffects: false
    }
  },
  light: {
    mode: 'light',
    colors: {
      primary: '#7C3AED',
      secondary: '#2563EB',
      accent: '#D97706',
      background: '#FFFFFF',
      surface: '#F9FAFB',
      text: '#111827',
      textSecondary: '#6B7280',
      success: '#059669',
      warning: '#D97706',
      error: '#DC2626',
      gradientStart: '#8B5CF6',
      gradientEnd: '#3B82F6'
    },
    effects: {
      glassmorphism: false,
      animations: true,
      haptics: true,
      soundEffects: false
    }
  },
  midnight: {
    mode: 'midnight',
    colors: {
      primary: '#6366F1',
      secondary: '#8B5CF6',
      accent: '#F472B6',
      background: '#0F0F23',
      surface: '#1E1E3F',
      text: '#E0E7FF',
      textSecondary: '#A5B4FC',
      success: '#34D399',
      warning: '#FBBF24',
      error: '#F87171',
      gradientStart: '#4F46E5',
      gradientEnd: '#7C3AED'
    },
    effects: {
      glassmorphism: true,
      animations: true,
      haptics: true,
      soundEffects: true
    }
  },
  ocean: {
    mode: 'ocean',
    colors: {
      primary: '#0EA5E9',
      secondary: '#06B6D4',
      accent: '#F0F9FF',
      background: '#0C1B2A',
      surface: '#1E3A5F',
      text: '#F0F9FF',
      textSecondary: '#7DD3FC',
      success: '#22D3EE',
      warning: '#FDE047',
      error: '#F87171',
      gradientStart: '#0EA5E9',
      gradientEnd: '#06B6D4'
    },
    effects: {
      glassmorphism: true,
      animations: true,
      haptics: true,
      soundEffects: true
    }
  },
  forest: {
    mode: 'forest',
    colors: {
      primary: '#059669',
      secondary: '#10B981',
      accent: '#84CC16',
      background: '#0A1A0A',
      surface: '#1F2A1F',
      text: '#F0FDF4',
      textSecondary: '#86EFAC',
      success: '#22C55E',
      warning: '#EAB308',
      error: '#EF4444',
      gradientStart: '#059669',
      gradientEnd: '#84CC16'
    },
    effects: {
      glassmorphism: true,
      animations: true,
      haptics: true,
      soundEffects: true
    }
  },
  auto: {
    mode: 'auto',
    colors: {
      primary: '#8B5CF6',
      secondary: '#3B82F6',
      accent: '#F59E0B',
      background: '#111827',
      surface: '#1F2937',
      text: '#F9FAFB',
      textSecondary: '#9CA3AF',
      success: '#10B981',
      warning: '#F59E0B',
      error: '#EF4444',
      gradientStart: '#7C3AED',
      gradientEnd: '#3B82F6'
    },
    effects: {
      glassmorphism: true,
      animations: true,
      haptics: true,
      soundEffects: false
    }
  }
}

export interface UserPreferences {
  theme: ThemeMode
  language: 'es' | 'en'
  currency: 'MXN' | 'USD' | 'EUR'
  notifications: {
    push: boolean
    email: boolean
    sms: boolean
  }
  accessibility: {
    reducedMotion: boolean
    highContrast: boolean
    fontSize: 'small' | 'medium' | 'large'
  }
  dashboard: {
    widgets: string[]
    layout: 'grid' | 'list'
    showBalance: boolean
  }
}

const defaultPreferences: UserPreferences = {
  theme: 'dark',
  language: 'es',
  currency: 'MXN',
  notifications: {
    push: true,
    email: true,
    sms: false
  },
  accessibility: {
    reducedMotion: false,
    highContrast: false,
    fontSize: 'medium'
  },
  dashboard: {
    widgets: ['balance', 'transactions', 'goals', 'insights'],
    layout: 'grid',
    showBalance: true
  }
}

const ThemeContext = createContext<{
  theme: Theme
  preferences: UserPreferences
  updateTheme: (mode: ThemeMode) => void
  updatePreferences: (prefs: Partial<UserPreferences>) => void
} | null>(null)

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [preferences, setPreferences] = useState<UserPreferences>(defaultPreferences)
  const [currentTheme, setCurrentTheme] = useState<Theme>(themes.dark)

  useEffect(() => {
    // Cargar preferencias guardadas
    const saved = localStorage.getItem('hey_banco_preferences')
    if (saved) {
      const savedPrefs = JSON.parse(saved)
      setPreferences(savedPrefs)
      updateTheme(savedPrefs.theme)
    }
  }, [])

  useEffect(() => {
    // Auto theme detection
    if (preferences.theme === 'auto') {
      const hour = new Date().getHours()
      const isDark = hour < 6 || hour > 18
      setCurrentTheme(isDark ? themes.dark : themes.light)
    } else {
      setCurrentTheme(themes[preferences.theme])
    }
  }, [preferences.theme])

  const updateTheme = (mode: ThemeMode) => {
    const newPrefs = { ...preferences, theme: mode }
    setPreferences(newPrefs)
    localStorage.setItem('hey_banco_preferences', JSON.stringify(newPrefs))
    
    // Apply theme to document
    applyThemeToDocument(themes[mode === 'auto' ? 'dark' : mode])
  }

  const updatePreferences = (newPrefs: Partial<UserPreferences>) => {
    const updated = { ...preferences, ...newPrefs }
    setPreferences(updated)
    localStorage.setItem('hey_banco_preferences', JSON.stringify(updated))
  }

  const applyThemeToDocument = (theme: Theme) => {
    const root = document.documentElement
    Object.entries(theme.colors).forEach(([key, value]) => {
      root.style.setProperty(`--color-${key}`, value)
    })
    
    root.className = theme.mode === 'light' ? 'light' : 'dark'
  }

  return (
    <ThemeContext.Provider value={{
      theme: currentTheme,
      preferences,
      updateTheme,
      updatePreferences
    }}>
      {children}
    </ThemeContext.Provider>
  )
}

export function useTheme() {
  const context = useContext(ThemeContext)
  if (!context) {
    throw new Error('useTheme must be used within ThemeProvider')
  }
  return context
}

// Haptic Feedback System
export class HapticService {
  private static enabled = true

  static enable() {
    this.enabled = true
  }

  static disable() {
    this.enabled = false
  }

  static light() {
    if (!this.enabled) return
    if ('vibrate' in navigator) {
      navigator.vibrate(50)
    }
  }

  static medium() {
    if (!this.enabled) return
    if ('vibrate' in navigator) {
      navigator.vibrate(100)
    }
  }

  static heavy() {
    if (!this.enabled) return
    if ('vibrate' in navigator) {
      navigator.vibrate([100, 50, 100])
    }
  }

  static success() {
    if (!this.enabled) return
    if ('vibrate' in navigator) {
      navigator.vibrate([50, 50, 50])
    }
  }

  static error() {
    if (!this.enabled) return
    if ('vibrate' in navigator) {
      navigator.vibrate([200, 100, 200])
    }
  }
}

// Sound Effects System
export class SoundService {
  private static enabled = false
  private static audioContext: AudioContext | null = null

  static enable() {
    this.enabled = true
    if (!this.audioContext) {
      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()
    }
  }

  static disable() {
    this.enabled = false
  }

  static playTone(frequency: number, duration: number = 100) {
    if (!this.enabled || !this.audioContext) return

    const oscillator = this.audioContext.createOscillator()
    const gainNode = this.audioContext.createGain()

    oscillator.connect(gainNode)
    gainNode.connect(this.audioContext.destination)

    oscillator.frequency.value = frequency
    oscillator.type = 'sine'

    gainNode.gain.setValueAtTime(0.1, this.audioContext.currentTime)
    gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + duration / 1000)

    oscillator.start(this.audioContext.currentTime)
    oscillator.stop(this.audioContext.currentTime + duration / 1000)
  }

  static success() {
    this.playTone(523.25, 150) // C5
  }

  static error() {
    this.playTone(207.65, 200) // G#3
  }

  static click() {
    this.playTone(800, 50)
  }

  static notification() {
    this.playTone(659.25, 100) // E5
    setTimeout(() => this.playTone(783.99, 100), 100) // G5
  }
}

// Animation utilities
export const animations = {
  fadeIn: 'animate-in fade-in duration-300',
  fadeOut: 'animate-out fade-out duration-200',
  slideUp: 'animate-in slide-in-from-bottom-4 duration-300',
  slideDown: 'animate-out slide-out-to-bottom-4 duration-200',
  scaleIn: 'animate-in zoom-in-95 duration-200',
  scaleOut: 'animate-out zoom-out-95 duration-150',
  bounceIn: 'animate-bounce',
  pulse: 'animate-pulse',
  spin: 'animate-spin'
}

export function getGreeting(hour: number = new Date().getHours()): string {
  if (hour < 6) return '🌙 Buenas noches'
  if (hour < 12) return '🌅 Buenos días'
  if (hour < 18) return '☀️ Buenas tardes'
  return '🌆 Buenas noches'
}

export function getContextualBackground(saldo: number, theme: Theme): string {
  const baseGradient = `linear-gradient(135deg, ${theme.colors.gradientStart}, ${theme.colors.gradientEnd})`
  
  if (saldo < 1000) {
    return `linear-gradient(135deg, ${theme.colors.error}40, ${theme.colors.warning}40)`
  } else if (saldo > 50000) {
    return `linear-gradient(135deg, ${theme.colors.success}40, ${theme.colors.primary}40)`
  }
  
  return baseGradient
}
