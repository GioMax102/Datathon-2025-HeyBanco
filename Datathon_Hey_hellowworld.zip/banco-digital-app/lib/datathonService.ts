// lib/datathonService.ts - Service to integrate your datathon model

import { DatathonModelAdapter } from "./datathonModelAdapter"
import { DatasetLoader, type DatathonUser } from "./datasetLoader"

export interface PrediccionTransaccion {
  comercio: string
  monto_predicho: number
  fecha_predicha: string // YYYY-MM-DD
  tipo_recurrencia: "predicha"
}

export type { DatathonUser } from "./datasetLoader"

class DatathonService {
  private modelAdapter: DatathonModelAdapter
  private users: Map<string, DatathonUser> = new Map()
  private datasetLoader: DatasetLoader
  private modelAvailable = false
  private lastModelTest: Date | null = null

  constructor() {
    console.log("🚀 Initializing DatathonService...")

    // Use Hugging Face Spaces endpoint
    const endpoint = process.env.NEXT_PUBLIC_MODEL_ENDPOINT || "https://pompeyo28-prediccion-datathon.hf.space/predict"
    console.log("🔗 Model endpoint configured:", endpoint)

    this.modelAdapter = new DatathonModelAdapter(endpoint)

    this.datasetLoader = new DatasetLoader({
      source: "github",
      fallbackToDemo: true,
    })

    console.log("📊 Dataset loader configured with GitHub source")

    // Initialize users asynchronously
    this.initializeUsers()

    // Skip connection test during initialization to prevent errors
    console.log("🔄 Skipping initial connection test to prevent startup errors")
    console.log("🎭 App will start in demo mode and test connection when needed")
    this.modelAvailable = false
  }

  private async testModelConnection() {
    console.log("🔍 Testing model connection...")
    this.lastModelTest = new Date()

    try {
      this.modelAvailable = await this.modelAdapter.testConnection()
      console.log(`🔍 Model connection test completed at ${this.lastModelTest.toISOString()}`)
      console.log(`🔍 Model status: ${this.modelAvailable ? "✅ Available" : "❌ Unavailable"}`)

      if (!this.modelAvailable) {
        console.log("🎭 Model unavailable - app will use demo predictions")
      }
    } catch (error) {
      console.error("🔍 Model connection test failed:")
      console.error(`   Error: ${error instanceof Error ? error.message : String(error)}`)
      console.log("🎭 Falling back to demo mode - this is expected during development")
      this.modelAvailable = false
    }
  }

  private async initializeUsers() {
    console.log("👥 Initializing users from dataset...")

    try {
      const users = await this.datasetLoader.loadUsers()

      users.forEach((user) => {
        this.users.set(user.user_id, user)
      })

      console.log(`✅ Successfully loaded ${this.users.size} users from dataset`)

      // Log some sample user IDs for testing
      const sampleIds = Array.from(this.users.keys()).slice(0, 10)
      console.log("🔑 Sample user IDs for testing:", sampleIds)
    } catch (error) {
      console.error("❌ Error loading users from dataset:")
      console.error(`   Error type: ${error instanceof Error ? error.constructor.name : typeof error}`)
      console.error(`   Error message: ${error instanceof Error ? error.message : String(error)}`)
    }
  }

  // Authenticate user with dataset user_id
  async authenticate(userId: string, password: string): Promise<DatathonUser | null> {
    console.log(`🔐 Authentication attempt for user: ${userId}`)
    console.log(`🔐 Password provided: ${password ? "✅ Yes" : "❌ No"}`)

    if (password !== "123456") {
      console.log("❌ Authentication failed: Invalid password")
      return null
    }

    const user = this.users.get(userId)
    if (!user) {
      console.warn(`❌ Authentication failed: User ${userId} not found in dataset`)
      console.log(`📊 Total users in dataset: ${this.users.size}`)
      console.log(`🔑 Available user IDs (first 10):`, Array.from(this.users.keys()).slice(0, 10))
      return null
    }

    console.log(`✅ Authentication successful for user: ${userId}`)
    console.log(`👤 User details:`, JSON.stringify(user, null, 2))
    return user
  }

  // Get predictions from your model
  async getPredictions(userId: string): Promise<PrediccionTransaccion[]> {
    console.log(`🔮 Starting prediction request for user: ${userId}`)
    console.log(`🕐 Request timestamp: ${new Date().toISOString()}`)
    console.log(`🔍 Model availability status: ${this.modelAvailable ? "✅ Available" : "❌ Unavailable"}`)

    // Always use demo data during development to avoid connection issues
    console.log("🎭 Using demo predictions for stable development experience")
    return this.getDemoPredictions(userId)

    // Uncomment this section when your model endpoint is ready for testing:
    /*
    if (!this.modelAvailable) {
      // Test connection on first prediction request
      console.log("🔍 Testing model connection on first prediction request...")
      await this.testModelConnection()
    }

    if (!this.modelAvailable) {
      console.log("🔄 Model marked as unavailable, using demo predictions")
      return this.getDemoPredictions(userId)
    }

    console.log("🚀 Attempting to call real model...")

    try {
      const startTime = Date.now()
      console.log(`⏱️ Model call started at: ${new Date(startTime).toISOString()}`)

      const predictions = await this.modelAdapter.callModel({
        user_id: userId,
        days_ahead: 30,
        include_recurring: true,
      })

      const endTime = Date.now()
      const duration = endTime - startTime

      console.log(`✅ Model call successful!`)
      console.log(`⏱️ Model call completed at: ${new Date(endTime).toISOString()}`)
      console.log(`⏱️ Total duration: ${duration}ms`)
      console.log(`📊 Received ${predictions.length} predictions for user ${userId}`)

      predictions.forEach((pred, index) => {
        console.log(`   ${index + 1}. ${pred.comercio}: $${pred.monto_predicho} on ${pred.fecha_predicha}`)
      })

      return predictions
    } catch (error) {
      console.error("❌ Model call failed, switching to demo mode:")
      console.error(`   Error type: ${error instanceof Error ? error.constructor.name : typeof error}`)
      console.error(`   Error message: ${error instanceof Error ? error.message : String(error)}`)

      // Mark model as unavailable for future calls
      this.modelAvailable = false
      console.log("🔄 Model marked as unavailable for future requests")

      // Fallback to demo data
      console.log("🎭 Falling back to demo predictions")
      return this.getDemoPredictions(userId)
    }
    */
  }

  // Demo predictions for development/testing
  private getDemoPredictions(userId: string): PrediccionTransaccion[] {
    console.log(`🎭 Generating demo predictions for user: ${userId}`)
    console.log(`🕐 Demo generation timestamp: ${new Date().toISOString()}`)

    const today = new Date()
    const predictions: PrediccionTransaccion[] = [
      {
        comercio: "OXXO",
        monto_predicho: 156.5,
        fecha_predicha: this.formatDate(new Date(today.getTime() + 2 * 24 * 60 * 60 * 1000)),
        tipo_recurrencia: "predicha",
      },
      {
        comercio: "SORIANA",
        monto_predicho: 850.75,
        fecha_predicha: this.formatDate(new Date(today.getTime() + 5 * 24 * 60 * 60 * 1000)),
        tipo_recurrencia: "predicha",
      },
      {
        comercio: "CFE",
        monto_predicho: 1200.0,
        fecha_predicha: this.formatDate(new Date(today.getTime() + 10 * 24 * 60 * 60 * 1000)),
        tipo_recurrencia: "predicha",
      },
      {
        comercio: "UBER",
        monto_predicho: 320.25,
        fecha_predicha: this.formatDate(new Date(today.getTime() + 3 * 24 * 60 * 60 * 1000)),
        tipo_recurrencia: "predicha",
      },
      {
        comercio: "NETFLIX",
        monto_predicho: 199.0,
        fecha_predicha: this.formatDate(new Date(today.getTime() + 15 * 24 * 60 * 60 * 1000)),
        tipo_recurrencia: "predicha",
      },
    ]

    console.log(`🎭 Generated ${predictions.length} demo predictions:`)
    predictions.forEach((pred, index) => {
      console.log(`   ${index + 1}. ${pred.comercio}: $${pred.monto_predicho} on ${pred.fecha_predicha}`)
    })

    return predictions
  }

  private formatDate(date: Date): string {
    return date.toISOString().split("T")[0] // YYYY-MM-DD
  }

  // Calculate projected balance based on predictions
  calculateProjectedBalance(currentBalance: number, predictions: PrediccionTransaccion[]): number {
    const totalPredictedSpending = predictions.reduce((sum, pred) => sum + pred.monto_predicho, 0)
    return currentBalance - totalPredictedSpending
  }

  // Analyze financial situation based on predictions
  analyzeFinancialSituation(
    currentBalance: number,
    predictions: PrediccionTransaccion[],
    savingsGoal?: number,
    weeklyBudget?: number,
  ): {
    projectedBalance: number
    isBalanceLow: boolean
    isBalanceHigh: boolean
    shouldActivateConservationMode: boolean
    savingsAlert?: string
    spendingAlert?: string
    recommendations: string[]
  } {
    const projectedBalance = this.calculateProjectedBalance(currentBalance, predictions)

    // Thresholds
    const lowBalanceThreshold = 15000
    const highBalanceThreshold = 50000
    const conservationModeThreshold = 10000

    const isBalanceLow = projectedBalance < lowBalanceThreshold
    const isBalanceHigh = projectedBalance > highBalanceThreshold
    const shouldActivateConservationMode = projectedBalance < conservationModeThreshold

    const recommendations: string[] = []
    let savingsAlert: string | undefined
    let spendingAlert: string | undefined

    // 🔑 Smart Balance Analysis
    if (isBalanceLow) {
      recommendations.push("💳 Considera microcréditos para cubrir compromisos financieros")
      recommendations.push("💰 Activa ahorro automático con montos pequeños")
      recommendations.push("⚠️ Revisa gastos no esenciales para reducir")
    }

    if (isBalanceHigh) {
      recommendations.push("💡 Aprovecha promociones en tiendas afiliadas")
      recommendations.push("📈 Considera opciones de inversión")
      recommendations.push("🎯 Aumenta tu meta de ahorro mensual")
    }

    // Savings goal analysis
    if (savingsGoal) {
      const monthlySavings = currentBalance - projectedBalance
      const projectedMonthlySavings = Math.max(0, monthlySavings)

      if (projectedMonthlySavings < savingsGoal) {
        savingsAlert = `⚠️ ¡Heads up! No vas a alcanzar tu meta de ahorro. Te faltan ${(savingsGoal - projectedMonthlySavings).toFixed(2)} MXN`
        recommendations.push("🎯 Ajusta tu meta de ahorro o reduce gastos opcionales")
      }
    }

    // Weekly spending analysis
    if (weeklyBudget) {
      const weeklyPredictions = predictions.filter((pred) => {
        const predDate = new Date(pred.fecha_predicha)
        const today = new Date()
        const weekFromNow = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000)
        return predDate >= today && predDate <= weekFromNow
      })

      const weeklySpending = weeklyPredictions.reduce((sum, pred) => sum + pred.monto_predicho, 0)

      if (weeklySpending > weeklyBudget) {
        spendingAlert = `🚨 Vas a exceder tu presupuesto semanal por ${(weeklySpending - weeklyBudget).toFixed(2)} MXN`
        recommendations.push("📊 Revisa y ajusta tus gastos semanales planificados")
      }
    }

    return {
      projectedBalance,
      isBalanceLow,
      isBalanceHigh,
      shouldActivateConservationMode,
      savingsAlert,
      spendingAlert,
      recommendations,
    }
  }

  // Get upcoming payments for conservation mode
  getUpcomingPayments(predictions: PrediccionTransaccion[], days = 30): PrediccionTransaccion[] {
    const today = new Date()
    const futureDate = new Date(today.getTime() + days * 24 * 60 * 60 * 1000)

    return predictions
      .filter((pred) => {
        const predDate = new Date(pred.fecha_predicha)
        return predDate >= today && predDate <= futureDate
      })
      .sort((a, b) => new Date(a.fecha_predicha).getTime() - new Date(b.fecha_predicha).getTime())
  }

  // Calculate recommended daily spending for conservation mode
  calculateDailySpendingLimit(
    currentBalance: number,
    essentialPayments: PrediccionTransaccion[],
    daysUntilEndOfMonth: number,
  ): number {
    const essentialTotal = essentialPayments.reduce((sum, payment) => sum + payment.monto_predicho, 0)
    const availableForDaily = Math.max(0, currentBalance - essentialTotal)
    return Math.floor(availableForDaily / daysUntilEndOfMonth)
  }

  // Check if user exists in dataset
  userExistsInDataset(userId: string): boolean {
    return this.users.has(userId)
  }

  // Get all users from dataset (for development)
  getAllUsers(): DatathonUser[] {
    return Array.from(this.users.values())
  }

  // Check if model is available
  isModelAvailable(): boolean {
    return this.modelAvailable
  }
}

export const datathonService = new DatathonService()
