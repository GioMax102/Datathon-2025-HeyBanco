// lib/helloWorldMachine.ts
// Wrapper para tu librería helloWorldMachine

interface Transaccion {
  monto: number
  giro: string
  fecha?: string
}

interface HistorialTransaccion {
  fecha: string
  monto: number
  giro: string
  descripcion?: string
}

// FUNCIÓN TEMPORAL - REEMPLAZAR CON TU MODELO REAL
async function predecir(historial: HistorialTransaccion[]): Promise<[string, Transaccion[]]> {
  try {
    // AQUÍ VA TU CÓDIGO REAL:
    // const resultado = await helloWorldMachine.predecir(historial)
    // return resultado

    // SIMULACIÓN TEMPORAL (BORRAR CUANDO TENGAS TU MODELO):
    await new Promise((resolve) => setTimeout(resolve, 1000)) // Simular delay

    const prediccionesEjemplo: Transaccion[] = [
      { monto: 8500, giro: "Vivienda" },
      { monto: 2300, giro: "Tarjeta" },
      { monto: 1200, giro: "Servicios" },
      { monto: 850, giro: "Alimentación" },
      { monto: 450, giro: "Transporte" },
      { monto: 300, giro: "Entretenimiento" },
    ]

    return ["usuario_123", prediccionesEjemplo]
  } catch (error) {
    console.error("Error en predicción:", error)
    throw new Error("Error al generar predicciones")
  }
}

// Exportar como default
const helloWorldMachine = {
  predecir,
}

export default helloWorldMachine
