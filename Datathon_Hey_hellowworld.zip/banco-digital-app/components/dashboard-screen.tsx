"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { CreditCard, TrendingUp, AlertTriangle, PiggyBank, Zap, X, DollarSign } from "lucide-react"
import { BankingActions } from "@/lib/bankingActions"
import type { Usuario } from "@/lib/bankingService"

interface DashboardScreenProps {
  usuario: Usuario
  modoConservar: boolean
  onToggleModoConservar: () => void
  onUpdateSaldo?: (nuevoSaldo: number) => void
}

export function DashboardScreen({
  usuario,
  modoConservar,
  onToggleModoConservar,
  onUpdateSaldo,
}: DashboardScreenProps) {
  const [loadingAction, setLoadingAction] = useState<string | null>(null)
  const [modalAbierto, setModalAbierto] = useState<string | null>(null)
  const [montoInversion, setMontoInversion] = useState("")
  const [montoAhorro, setMontoAhorro] = useState("")
  const [mensaje, setMensaje] = useState<{ tipo: "success" | "error"; texto: string } | null>(null)

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("es-MX", {
      style: "currency",
      currency: "MXN",
    }).format(amount)
  }

  const mostrarMensaje = (tipo: "success" | "error", texto: string) => {
    setMensaje({ tipo, texto })
    setTimeout(() => setMensaje(null), 5000)
  }

  const handleSolicitarTarjeta = async () => {
    setLoadingAction("tarjeta")
    try {
      const resultado = await BankingActions.solicitarTarjetaCredito(usuario)
      mostrarMensaje(resultado.success ? "success" : "error", resultado.message)
    } catch (error) {
      mostrarMensaje("error", "Error al procesar solicitud")
    } finally {
      setLoadingAction(null)
    }
  }

  const handleSolicitarPrestamo = async () => {
    setLoadingAction("prestamo")
    try {
      await new Promise((resolve) => setTimeout(resolve, 2000))
      if (usuario.scoring < 700) {
        mostrarMensaje("error", "Tu scoring no cumple los requisitos mínimos para préstamos")
        return
      }
      mostrarMensaje("success", `Préstamo pre-aprobado hasta ${formatCurrency(150000)} con tasa preferencial`)
    } catch (error) {
      mostrarMensaje("error", "Error al procesar solicitud")
    } finally {
      setLoadingAction(null)
    }
  }

  const handleIniciarInversion = async () => {
    const monto = Number.parseFloat(montoInversion)
    if (!monto || monto <= 0) {
      mostrarMensaje("error", "Ingresa un monto válido")
      return
    }

    setLoadingAction("inversion")
    try {
      const resultado = await BankingActions.iniciarInversion(usuario, monto)
      if (resultado.success && onUpdateSaldo) {
        onUpdateSaldo(usuario.saldo - monto)
      }
      mostrarMensaje(resultado.success ? "success" : "error", resultado.message)
      if (resultado.success) {
        setModalAbierto(null)
        setMontoInversion("")
      }
    } catch (error) {
      mostrarMensaje("error", "Error al procesar inversión")
    } finally {
      setLoadingAction(null)
    }
  }

  // PRODUCTOS CONTRATADOS - Lista específica requerida
  const productosContratados = [
    {
      id: 1,
      nombre: "Cuenta Hey Digital",
      numero: "**** **** **** 4521",
      saldo: usuario.saldo,
      tipo: "cuenta",
      icono: CreditCard,
      color: "text-green-400",
      bgColor: "bg-green-900/30",
    },
    {
      id: 2,
      nombre: "Crédito Personal",
      disponible: 85000,
      tasa: "8.9% anual",
      tipo: "credito",
      icono: DollarSign,
      color: "text-blue-400",
      bgColor: "bg-blue-900/30",
    },
  ]

  // PRODUCTOS SUGERIDOS - Tarjetas y préstamos específicos
  const productosSugeridos = [
    {
      id: 1,
      nombre: "Tarjeta de Crédito Hey",
      descripcion: "Sin anualidad primer año",
      beneficio: "Cashback 2% en supermercados",
      tipo: "tarjeta",
      icono: CreditCard,
      color: "text-orange-400",
      bgColor: "bg-orange-900/30",
      borderColor: "border-orange-800/30",
      accion: handleSolicitarTarjeta,
    },
    {
      id: 2,
      nombre: "Préstamo Personal",
      descripcion: "Hasta $150,000",
      beneficio: "Tasa desde 12.9% anual",
      tipo: "prestamo",
      icono: TrendingUp,
      color: "text-purple-400",
      bgColor: "bg-purple-900/30",
      borderColor: "border-purple-800/30",
      accion: handleSolicitarPrestamo,
    },
    {
      id: 3,
      nombre: "Inversión Hey",
      descripcion: "Desde $100",
      beneficio: "Rendimiento hasta 12% anual",
      tipo: "inversion",
      icono: PiggyBank,
      color: "text-emerald-400",
      bgColor: "bg-emerald-900/30",
      borderColor: "border-emerald-800/30",
      accion: () => setModalAbierto("inversion"),
    },
  ]

  return (
    <div className="p-4 pb-20 space-y-6">
      {/* Mensaje de notificación */}
      {mensaje && (
        <div
          className={`fixed top-24 left-1/2 transform -translate-x-1/2 z-50 p-4 rounded-lg border max-w-sm w-full mx-4 ${
            mensaje.tipo === "success"
              ? "bg-green-900/90 border-green-600 text-green-100"
              : "bg-red-900/90 border-red-600 text-red-100"
          }`}
        >
          <div className="flex items-center justify-between">
            <p className="text-sm">{mensaje.texto}</p>
            <Button variant="ghost" size="sm" onClick={() => setMensaje(null)} className="text-current p-1 h-auto">
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}

      {/* ✅ REQUERIMIENTO 1.1: MOSTRAR NOMBRE DEL USUARIO */}
      <div className="flex items-center justify-between pt-8">
        <div>
          <h1 className="text-2xl font-light text-gray-100">Hola, {usuario.nombre.split(" ")[0]}</h1>
          <p className="text-gray-400 text-sm">
            {new Date().getHours() < 12
              ? "Buenos días"
              : new Date().getHours() < 18
                ? "Buenas tardes"
                : "Buenas noches"}
          </p>
        </div>
        {modoConservar && (
          <Badge variant="outline" className="bg-amber-900/20 text-amber-400 border-amber-600">
            <AlertTriangle className="w-3 h-3 mr-1" />
            Modo Conservar
          </Badge>
        )}
      </div>

      {/* ✅ REQUERIMIENTO 1.2: SALDO TOTAL, MONEDAS VIRTUALES Y REFERIDOS */}
      <Card
        className={`${
          modoConservar
            ? "bg-gray-800/50 border-gray-700"
            : "bg-gradient-to-br from-purple-900/40 to-blue-900/40 border-purple-800/30"
        }`}
      >
        <CardContent className="p-6">
          {/* SALDO TOTAL */}
          <div className="space-y-2">
            <p className="text-gray-300 text-sm">Saldo total</p>
            <p className="text-3xl font-light text-white">{formatCurrency(usuario.saldo)}</p>
          </div>

          {/* MONEDAS VIRTUALES Y REFERIDOS */}
          {!modoConservar && (
            <div className="flex justify-between mt-4 pt-4 border-t border-purple-800/30">
              <div className="text-center">
                <p className="text-purple-300 text-xs">Monedas virtuales</p>
                <p className="text-white font-medium">{usuario.monedas.toLocaleString()}</p>
              </div>
              <div className="text-center">
                <p className="text-purple-300 text-xs">Referidos</p>
                <p className="text-white font-medium">{usuario.referidos}</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* ✅ REQUERIMIENTO 1.3: LISTA DE PRODUCTOS CONTRATADOS (CUENTAS, CRÉDITOS) */}
      <div className="space-y-3">
        <h2 className="text-lg font-medium text-gray-100">Productos contratados</h2>

        {productosContratados.map((producto) => {
          const Icono = producto.icono
          return (
            <Card key={producto.id} className="bg-gray-800/50 border-gray-700">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`w-10 h-10 ${producto.bgColor} rounded-lg flex items-center justify-center`}>
                      <Icono className={`w-5 h-5 ${producto.color}`} />
                    </div>
                    <div>
                      <p className="text-white font-medium">{producto.nombre}</p>
                      <p className="text-gray-400 text-sm">
                        {producto.numero || `Disponible: ${formatCurrency(producto.disponible || 0)}`}
                      </p>
                    </div>
                  </div>
                  <p className={`${producto.color} font-medium`}>
                    {producto.saldo ? formatCurrency(producto.saldo) : producto.tasa}
                  </p>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* ✅ REQUERIMIENTO 1.4: LISTA DE PRODUCTOS SUGERIDOS (TARJETAS, PRÉSTAMOS) */}
      {!modoConservar && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-medium text-gray-100">Productos sugeridos</h2>
            <Badge variant="outline" className="bg-blue-900/20 text-blue-400 border-blue-600">
              <Zap className="w-3 h-3 mr-1" />
              Recomendados
            </Badge>
          </div>

          {productosSugeridos.map((producto) => {
            const Icono = producto.icono
            const isActionLoading =
              (loadingAction === "tarjeta" && producto.tipo === "tarjeta") ||
              (loadingAction === "prestamo" && producto.tipo === "prestamo")

            return (
              <Card
                key={producto.id}
                className={`bg-gradient-to-r from-gray-800/60 to-gray-800/40 ${producto.borderColor} border`}
              >
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className={`w-10 h-10 ${producto.bgColor} rounded-lg flex items-center justify-center`}>
                        <Icono className={`w-5 h-5 ${producto.color}`} />
                      </div>
                      <div>
                        <p className="text-white font-medium">{producto.nombre}</p>
                        <p className="text-gray-400 text-sm">{producto.descripcion}</p>
                        <p className={`${producto.color} text-xs`}>{producto.beneficio}</p>
                      </div>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={producto.accion}
                      disabled={isActionLoading}
                      className={`border-gray-600 text-gray-300 hover:bg-gray-700/20`}
                    >
                      {isActionLoading ? (
                        <div className="flex items-center">
                          <div className="animate-spin w-4 h-4 border-2 border-current border-t-transparent rounded-full mr-2"></div>
                          Procesando...
                        </div>
                      ) : (
                        "Solicitar"
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      )}

      {/* Modal de Inversión */}
      {modalAbierto === "inversion" && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-md bg-gray-800 border-gray-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-white">Inversión Hey</h3>
                <Button variant="ghost" size="sm" onClick={() => setModalAbierto(null)} className="text-gray-400">
                  <X className="w-4 h-4" />
                </Button>
              </div>

              <div className="space-y-4">
                <div className="bg-emerald-900/20 rounded-lg p-3 border border-emerald-800/30">
                  <p className="text-emerald-400 text-sm">Rendimiento esperado: 12% anual</p>
                  <p className="text-gray-300 text-xs">Inversión mínima: $100</p>
                </div>

                <div>
                  <Label className="text-gray-300">Monto a invertir</Label>
                  <Input
                    type="number"
                    value={montoInversion}
                    onChange={(e) => setMontoInversion(e.target.value)}
                    placeholder="1000"
                    className="bg-gray-700/50 border-gray-600 text-white"
                  />
                  <p className="text-gray-400 text-xs mt-1">Saldo disponible: {formatCurrency(usuario.saldo)}</p>
                </div>

                <Button
                  onClick={handleIniciarInversion}
                  disabled={loadingAction === "inversion"}
                  className="w-full bg-emerald-600 hover:bg-emerald-700"
                >
                  {loadingAction === "inversion" ? (
                    <div className="flex items-center">
                      <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2"></div>
                      Procesando inversión...
                    </div>
                  ) : (
                    "Invertir Ahora"
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
