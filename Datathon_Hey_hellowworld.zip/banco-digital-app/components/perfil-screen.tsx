"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  User,
  Settings,
  CreditCard,
  Shield,
  HelpCircle,
  LogOut,
  Bell,
  Eye,
  Lock,
  Download,
  X,
  CheckCircle,
} from "lucide-react"
import { BankingActions } from "@/lib/bankingActions"
import type { Usuario } from "@/lib/bankingService"

interface PerfilScreenProps {
  usuario: Usuario
  onLogout: () => void
}

export function PerfilScreen({ usuario, onLogout }: PerfilScreenProps) {
  const [modalAbierto, setModalAbierto] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState<string | null>(null)
  const [passwords, setPasswords] = useState({
    actual: "",
    nueva: "",
    confirmar: "",
  })
  const [mensaje, setMensaje] = useState<{ tipo: "success" | "error"; texto: string } | null>(null)

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("es-MX", {
      style: "currency",
      currency: "MXN",
    }).format(amount)
  }

  const mostrarMensaje = (tipo: "success" | "error", texto: string) => {
    setMensaje({ tipo, texto })
    setTimeout(() => setMensaje(null), 4000)
  }

  const handleLogout = () => {
    if (confirm("¿Estás seguro de que deseas cerrar sesión?")) {
      onLogout()
    }
  }

  const handleCambiarContrasena = async () => {
    if (passwords.nueva !== passwords.confirmar) {
      mostrarMensaje("error", "Las contraseñas no coinciden")
      return
    }

    if (passwords.nueva.length < 6) {
      mostrarMensaje("error", "La nueva contraseña debe tener al menos 6 caracteres")
      return
    }

    setIsLoading("password")
    try {
      const resultado = await BankingActions.cambiarContrasena(passwords.actual, passwords.nueva)
      mostrarMensaje(resultado.success ? "success" : "error", resultado.message)

      if (resultado.success) {
        setModalAbierto(null)
        setPasswords({ actual: "", nueva: "", confirmar: "" })
      }
    } catch (error) {
      mostrarMensaje("error", "Error al cambiar contraseña")
    } finally {
      setIsLoading(null)
    }
  }

  const handleExportarDatos = async () => {
    setIsLoading("export")
    try {
      const resultado = await BankingActions.exportarDatos(usuario)
      if (resultado.success && resultado.url) {
        mostrarMensaje("success", "Datos exportados exitosamente. Descarga iniciada.")
        // Simular descarga
        const link = document.createElement("a")
        link.href = resultado.url
        link.download = `datos_bancarios_${new Date().toISOString().split("T")[0]}.zip`
        link.click()
      }
    } catch (error) {
      mostrarMensaje("error", "Error al exportar datos")
    } finally {
      setIsLoading(null)
    }
  }

  const handleConfiguracion = (tipo: string) => {
    switch (tipo) {
      case "general":
        mostrarMensaje("success", "Configuración general - Próximamente")
        break
      case "tarjetas":
        mostrarMensaje("success", "Gestión de tarjetas - Próximamente")
        break
      case "seguridad":
        setModalAbierto("seguridad")
        break
      case "notificaciones":
        mostrarMensaje("success", "Ve a la sección de Notificaciones para configurar")
        break
      case "privacidad":
        mostrarMensaje("success", "Configuración de privacidad - Próximamente")
        break
      case "ayuda":
        mostrarMensaje("success", "Conectando con soporte...")
        break
      default:
        mostrarMensaje("success", "Función disponible próximamente")
    }
  }

  const opcionesMenu = [
    {
      id: "general",
      nombre: "Configuración General",
      descripcion: "Personaliza tu experiencia",
      icono: Settings,
      accion: () => handleConfiguracion("general"),
    },
    {
      id: "tarjetas",
      nombre: "Mis Tarjetas y Cuentas",
      descripcion: "Gestiona tus productos",
      icono: CreditCard,
      accion: () => handleConfiguracion("tarjetas"),
    },
    {
      id: "seguridad",
      nombre: "Seguridad y Privacidad",
      descripcion: "Protege tu cuenta",
      icono: Shield,
      accion: () => handleConfiguracion("seguridad"),
    },
    {
      id: "notificaciones",
      nombre: "Notificaciones",
      descripcion: "Configura tus alertas",
      icono: Bell,
      accion: () => handleConfiguracion("notificaciones"),
    },
    {
      id: "privacidad",
      nombre: "Datos y Privacidad",
      descripcion: "Controla tu información",
      icono: Eye,
      accion: () => handleConfiguracion("privacidad"),
    },
    {
      id: "ayuda",
      nombre: "Ayuda y Soporte",
      descripcion: "Obtén asistencia",
      icono: HelpCircle,
      accion: () => handleConfiguracion("ayuda"),
    },
  ]

  return (
    <div className="p-4 pb-20 space-y-6">
      {/* Mensaje de notificación */}
      {mensaje && (
        <div
          className={`fixed top-24 left-1/2 transform -translate-x-1/2 z-50 p-4 rounded-lg border max-w-sm w-full mx-4 ${
            mensaje.tipo === "success"
              ? "bg-green-900/90 border-green-600 text-green-100"
              : "bg-red-900/90 border-red-600 text-red-100"
          }`}
        >
          <div className="flex items-center justify-between">
            <p className="text-sm">{mensaje.texto}</p>
            <Button variant="ghost" size="sm" onClick={() => setMensaje(null)} className="text-current p-1 h-auto">
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="pt-8">
        <h1 className="text-2xl font-light text-gray-100">Perfil</h1>
        <p className="text-gray-400 text-sm">Configuración y preferencias de tu cuenta</p>
      </div>

      {/* Información del Usuario */}
      <Card className="bg-gradient-to-br from-purple-900/40 to-blue-900/40 border-purple-800/30">
        <CardContent className="p-6">
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 bg-purple-900/50 rounded-full flex items-center justify-center flex-shrink-0">
              <User className="w-8 h-8 text-purple-400" />
            </div>
            <div className="flex-1 min-w-0">
              <h2 className="text-xl font-medium text-white truncate">
                {usuario.nombre && usuario.apellidos && usuario.nombre !== usuario.id
                  ? `${usuario.nombre} ${usuario.apellidos}`
                  : `Usuario ${usuario.id.substring(0, 6)}...`}
              </h2>
              <p className="text-gray-300 text-sm truncate">
                {usuario.email.length > 25 ? `${usuario.email.substring(0, 25)}...` : usuario.email}
              </p>
              <p className="text-gray-400 text-xs truncate">{usuario.telefono}</p>
              <div className="flex items-center space-x-2 mt-2 flex-wrap">
                <Badge variant="outline" className="bg-green-900/20 text-green-400 border-green-600 text-xs">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  Verificada
                </Badge>
                <Badge variant="outline" className="bg-blue-900/20 text-blue-400 border-blue-600 text-xs">
                  {usuario.nivelCliente}
                </Badge>
              </div>
            </div>
          </div>

          {/* Estadísticas del usuario */}
          <div className="grid grid-cols-3 gap-4 mt-6 pt-4 border-t border-purple-800/30">
            <div className="text-center">
              <p className="text-purple-300 text-xs">Saldo Total</p>
              <p className="text-white font-medium">{formatCurrency(usuario.saldo)}</p>
            </div>
            <div className="text-center">
              <p className="text-purple-300 text-xs">Scoring</p>
              <p className="text-white font-medium">{usuario.scoring}/850</p>
            </div>
            <div className="text-center">
              <p className="text-purple-300 text-xs">Miembro desde</p>
              <p className="text-white font-medium">{new Date(usuario.fechaRegistro).getFullYear()}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Opciones del Perfil */}
      <div className="space-y-3">
        <h2 className="text-lg font-medium text-gray-100">Configuración</h2>

        {opcionesMenu.map((opcion) => {
          const Icono = opcion.icono
          return (
            <Card key={opcion.id} className="bg-gray-800/50 border-gray-700">
              <CardContent className="p-4">
                <button
                  onClick={opcion.accion}
                  className="flex items-center justify-between w-full text-left hover:bg-gray-700/30 -m-4 p-4 rounded-lg transition-colors"
                >
                  <div className="flex items-center space-x-3">
                    <Icono className="w-5 h-5 text-gray-400" />
                    <div>
                      <span className="text-white font-medium">{opcion.nombre}</span>
                      <p className="text-gray-400 text-sm">{opcion.descripcion}</p>
                    </div>
                  </div>
                  <span className="text-gray-400">{">"}</span>
                </button>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Información Adicional */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardContent className="p-4">
          <h3 className="text-white font-medium mb-3">Información de la App</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-400">Versión</span>
              <span className="text-white">2.1.0</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Última actualización</span>
              <span className="text-white">25 May 2025</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">ID de Usuario</span>
              <span className="text-white font-mono text-xs">{usuario.id.substring(0, 6)}...</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Último acceso</span>
              <span className="text-white text-xs">{new Date(usuario.ultimoAcceso).toLocaleString("es-MX")}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Acciones de Cuenta */}
      <div className="space-y-3">
        <h2 className="text-lg font-medium text-gray-100">Cuenta</h2>

        <Button
          onClick={() => setModalAbierto("password")}
          variant="outline"
          className="w-full border-blue-600 text-blue-400 hover:bg-blue-900/20"
        >
          <Lock className="w-4 h-4 mr-2" />
          Cambiar Contraseña
        </Button>

        <Button
          onClick={handleExportarDatos}
          disabled={isLoading === "export"}
          variant="outline"
          className="w-full border-gray-600 text-gray-300 hover:bg-gray-700/20"
        >
          {isLoading === "export" ? (
            <div className="flex items-center">
              <div className="animate-spin w-4 h-4 border-2 border-gray-300 border-t-transparent rounded-full mr-2"></div>
              Exportando datos...
            </div>
          ) : (
            <>
              <Download className="w-4 h-4 mr-2" />
              Exportar Datos
            </>
          )}
        </Button>
      </div>

      {/* Cerrar Sesión */}
      <Button
        onClick={handleLogout}
        variant="outline"
        className="w-full border-red-600 text-red-400 hover:bg-red-900/20"
      >
        <LogOut className="w-4 h-4 mr-2" />
        Cerrar Sesión
      </Button>

      {/* Footer */}
      <div className="text-center pt-4">
        <p className="text-gray-500 text-xs">© 2025 Hey Banco. Todos los derechos reservados.</p>
        <p className="text-gray-500 text-xs mt-1">Términos y condiciones • Política de privacidad</p>
      </div>

      {/* Modal Cambiar Contraseña */}
      {modalAbierto === "password" && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-md bg-gray-800 border-gray-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-white">Cambiar Contraseña</h3>
                <Button variant="ghost" size="sm" onClick={() => setModalAbierto(null)} className="text-gray-400">
                  <X className="w-4 h-4" />
                </Button>
              </div>

              <div className="space-y-4">
                <div>
                  <Label className="text-gray-300">Contraseña actual</Label>
                  <Input
                    type="password"
                    value={passwords.actual}
                    onChange={(e) => setPasswords({ ...passwords, actual: e.target.value })}
                    placeholder="Ingresa tu contraseña actual"
                    className="bg-gray-700/50 border-gray-600 text-white"
                  />
                </div>

                <div>
                  <Label className="text-gray-300">Nueva contraseña</Label>
                  <Input
                    type="password"
                    value={passwords.nueva}
                    onChange={(e) => setPasswords({ ...passwords, nueva: e.target.value })}
                    placeholder="Mínimo 6 caracteres"
                    className="bg-gray-700/50 border-gray-600 text-white"
                  />
                </div>

                <div>
                  <Label className="text-gray-300">Confirmar nueva contraseña</Label>
                  <Input
                    type="password"
                    value={passwords.confirmar}
                    onChange={(e) => setPasswords({ ...passwords, confirmar: e.target.value })}
                    placeholder="Repite la nueva contraseña"
                    className="bg-gray-700/50 border-gray-600 text-white"
                  />
                </div>

                <div className="bg-blue-900/20 rounded-lg p-3 border border-blue-800/30">
                  <p className="text-blue-400 text-sm font-medium mb-1">Consejos de seguridad:</p>
                  <ul className="text-gray-300 text-xs space-y-1">
                    <li>• Usa al menos 8 caracteres</li>
                    <li>• Incluye mayúsculas y minúsculas</li>
                    <li>• Agrega números y símbolos</li>
                  </ul>
                </div>

                <Button
                  onClick={handleCambiarContrasena}
                  disabled={isLoading === "password" || !passwords.actual || !passwords.nueva || !passwords.confirmar}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  {isLoading === "password" ? (
                    <div className="flex items-center">
                      <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2"></div>
                      Cambiando contraseña...
                    </div>
                  ) : (
                    "Cambiar Contraseña"
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Modal Configuración de Seguridad */}
      {modalAbierto === "seguridad" && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-md bg-gray-800 border-gray-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-white">Configuración de Seguridad</h3>
                <Button variant="ghost" size="sm" onClick={() => setModalAbierto(null)} className="text-gray-400">
                  <X className="w-4 h-4" />
                </Button>
              </div>

              <div className="space-y-4">
                {/* Autenticación de dos factores */}
                <div className="flex items-center justify-between p-3 bg-green-900/20 rounded-lg border border-green-800/30">
                  <div>
                    <p className="text-white font-medium">Autenticación de dos factores</p>
                    <p className="text-gray-400 text-sm">Protección adicional para tu cuenta</p>
                  </div>
                  <Badge className="bg-green-900/20 text-green-400 border-green-600">Activo</Badge>
                </div>

                {/* Notificaciones de seguridad */}
                <div className="flex items-center justify-between p-3 bg-blue-900/20 rounded-lg border border-blue-800/30">
                  <div>
                    <p className="text-white font-medium">Alertas de seguridad</p>
                    <p className="text-gray-400 text-sm">Notificaciones de actividad sospechosa</p>
                  </div>
                  <button className="w-10 h-6 bg-blue-600 rounded-full relative">
                    <div className="w-4 h-4 bg-white rounded-full absolute right-1 top-1"></div>
                  </button>
                </div>

                {/* Sesiones activas */}
                <div className="p-3 bg-gray-700/50 rounded-lg">
                  <p className="text-white font-medium mb-2">Sesiones activas</p>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-white text-sm">Dispositivo actual</p>
                        <p className="text-gray-400 text-xs">Chrome en Windows</p>
                      </div>
                      <Badge variant="outline" className="bg-green-900/20 text-green-400 border-green-600">
                        Activa
                      </Badge>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Button
                    onClick={() => setModalAbierto("password")}
                    variant="outline"
                    className="w-full border-blue-600 text-blue-400"
                  >
                    <Lock className="w-4 h-4 mr-2" />
                    Cambiar Contraseña
                  </Button>

                  <Button
                    variant="outline"
                    className="w-full border-red-600 text-red-400"
                    onClick={() => {
                      mostrarMensaje("success", "Todas las sesiones remotas cerradas")
                      setModalAbierto(null)
                    }}
                  >
                    Cerrar todas las sesiones
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
