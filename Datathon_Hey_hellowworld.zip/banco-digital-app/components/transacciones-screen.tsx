"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  ArrowUpCircle,
  ArrowDownCircle,
  Search,
  Calendar,
  MapPin,
  CreditCard,
  Smartphone,
  ShoppingCart,
  Car,
  Home,
  Coffee,
  Download,
  MoreHorizontal,
} from "lucide-react"
import { bankingService, type Transaccion, type Usuario } from "@/lib/bankingService"

interface TransaccionesScreenProps {
  usuario: Usuario
}

export function TransaccionesScreen({ usuario }: TransaccionesScreenProps) {
  const [transacciones, setTransacciones] = useState<Transaccion[]>([])
  const [filtroTexto, setFiltroTexto] = useState("")
  const [filtroCategoria, setFiltroCategoria] = useState<string>("todas")
  const [filtroTipo, setFiltroTipo] = useState<string>("todas")
  const [isLoading, setIsLoading] = useState(true)
  const [transaccionSeleccionada, setTransaccionSeleccionada] = useState<Transaccion | null>(null)

  useEffect(() => {
    cargarTransacciones()
  }, [filtroCategoria, filtroTipo])

  const cargarTransacciones = async () => {
    setIsLoading(true)
    try {
      const filtros: any = {}
      if (filtroCategoria !== "todas") filtros.categoria = filtroCategoria
      if (filtroTipo !== "todas") filtros.tipo = filtroTipo

      const data = await bankingService.getTransacciones(usuario.id, filtros)
      setTransacciones(data)
    } catch (error) {
      console.error("Error cargando transacciones:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("es-MX", {
      style: "currency",
      currency: "MXN",
    }).format(Math.abs(amount))
  }

  const formatFecha = (fechaStr: string) => {
    const fecha = new Date(fechaStr)
    const hoy = new Date()
    const ayer = new Date(hoy)
    ayer.setDate(hoy.getDate() - 1)

    if (fecha.toDateString() === hoy.toDateString()) {
      return `Hoy ${fecha.toLocaleTimeString("es-MX", { hour: "2-digit", minute: "2-digit" })}`
    } else if (fecha.toDateString() === ayer.toDateString()) {
      return `Ayer ${fecha.toLocaleTimeString("es-MX", { hour: "2-digit", minute: "2-digit" })}`
    } else {
      return fecha.toLocaleDateString("es-MX", {
        day: "2-digit",
        month: "short",
        hour: "2-digit",
        minute: "2-digit",
      })
    }
  }

  const getIconoCategoria = (categoria: string) => {
    const iconos: Record<string, any> = {
      Alimentación: ShoppingCart,
      Transporte: Car,
      Vivienda: Home,
      Entretenimiento: Coffee,
      Salario: ArrowUpCircle,
      Servicios: Smartphone,
    }
    const Icono = iconos[categoria] || CreditCard
    return <Icono className="w-5 h-5" />
  }

  const getColorCategoria = (tipo: string, categoria: string) => {
    if (tipo === "ingreso") return "text-green-400 bg-green-900/20"

    const colores: Record<string, string> = {
      Alimentación: "text-orange-400 bg-orange-900/20",
      Transporte: "text-blue-400 bg-blue-900/20",
      Vivienda: "text-purple-400 bg-purple-900/20",
      Entretenimiento: "text-pink-400 bg-pink-900/20",
      Servicios: "text-cyan-400 bg-cyan-900/20",
    }
    return colores[categoria] || "text-gray-400 bg-gray-900/20"
  }

  const categorias = ["todas", "Alimentación", "Transporte", "Vivienda", "Entretenimiento", "Servicios", "Salario"]
  const tipos = ["todas", "ingreso", "egreso", "transferencia"]

  const transaccionesFiltradas = transacciones.filter((transaccion) => {
    const coincideTexto =
      transaccion.descripcion.toLowerCase().includes(filtroTexto.toLowerCase()) ||
      transaccion.comercio?.toLowerCase().includes(filtroTexto.toLowerCase())
    return coincideTexto
  })

  // Agrupar transacciones por fecha
  const transaccionesAgrupadas = transaccionesFiltradas.reduce(
    (grupos, transaccion) => {
      const fecha = new Date(transaccion.fecha).toDateString()
      if (!grupos[fecha]) {
        grupos[fecha] = []
      }
      grupos[fecha].push(transaccion)
      return grupos
    },
    {} as Record<string, Transaccion[]>,
  )

  const calcularTotalPorTipo = (tipo: "ingreso" | "egreso") => {
    return transaccionesFiltradas.filter((t) => t.tipo === tipo).reduce((sum, t) => sum + Math.abs(t.monto), 0)
  }

  return (
    <div className="p-4 pb-20 space-y-6">
      {/* Header */}
      <div className="pt-8">
        <h1 className="text-2xl font-light text-gray-100">Movimientos</h1>
        <p className="text-gray-400 text-sm">Historial completo de transacciones</p>
      </div>

      {/* Resumen rápido */}
      <div className="grid grid-cols-2 gap-4">
        <Card className="bg-green-900/20 border-green-800/30">
          <CardContent className="p-4 text-center">
            <ArrowUpCircle className="w-6 h-6 text-green-400 mx-auto mb-2" />
            <p className="text-green-400 text-xs">Ingresos</p>
            <p className="text-white font-medium">{formatCurrency(calcularTotalPorTipo("ingreso"))}</p>
          </CardContent>
        </Card>

        <Card className="bg-red-900/20 border-red-800/30">
          <CardContent className="p-4 text-center">
            <ArrowDownCircle className="w-6 h-6 text-red-400 mx-auto mb-2" />
            <p className="text-red-400 text-xs">Gastos</p>
            <p className="text-white font-medium">{formatCurrency(calcularTotalPorTipo("egreso"))}</p>
          </CardContent>
        </Card>
      </div>

      {/* Filtros y búsqueda */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardContent className="p-4 space-y-4">
          {/* Búsqueda */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              placeholder="Buscar por comercio o descripción..."
              value={filtroTexto}
              onChange={(e) => setFiltroTexto(e.target.value)}
              className="pl-10 bg-gray-700/50 border-gray-600 text-white"
            />
          </div>

          {/* Filtros */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-gray-400 text-sm mb-2">Categoría</p>
              <select
                value={filtroCategoria}
                onChange={(e) => setFiltroCategoria(e.target.value)}
                className="w-full bg-gray-700/50 border border-gray-600 rounded-md px-3 py-2 text-white text-sm"
              >
                {categorias.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat === "todas" ? "Todas" : cat}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <p className="text-gray-400 text-sm mb-2">Tipo</p>
              <select
                value={filtroTipo}
                onChange={(e) => setFiltroTipo(e.target.value)}
                className="w-full bg-gray-700/50 border border-gray-600 rounded-md px-3 py-2 text-white text-sm"
              >
                {tipos.map((tipo) => (
                  <option key={tipo} value={tipo}>
                    {tipo === "todas"
                      ? "Todos"
                      : tipo === "ingreso"
                        ? "Ingresos"
                        : tipo === "egreso"
                          ? "Gastos"
                          : "Transferencias"}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Acciones */}
          <div className="flex space-x-2">
            <Button size="sm" variant="outline" className="border-blue-600 text-blue-400">
              <Calendar className="w-4 h-4 mr-2" />
              Rango de fechas
            </Button>
            <Button size="sm" variant="outline" className="border-gray-600 text-gray-300">
              <Download className="w-4 h-4 mr-2" />
              Exportar
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Lista de transacciones agrupadas */}
      {isLoading ? (
        <div className="flex justify-center py-8">
          <div className="animate-spin w-8 h-8 border-2 border-blue-400 border-t-transparent rounded-full"></div>
        </div>
      ) : (
        <div className="space-y-6">
          {Object.entries(transaccionesAgrupadas).map(([fecha, transaccionesDia]) => {
            const fechaObj = new Date(fecha)
            const totalDia = transaccionesDia.reduce((sum, t) => sum + t.monto, 0)

            return (
              <div key={fecha} className="space-y-3">
                {/* Header del día */}
                <div className="flex items-center justify-between">
                  <h3 className="text-white font-medium">
                    {fechaObj.toLocaleDateString("es-MX", {
                      weekday: "long",
                      day: "2-digit",
                      month: "long",
                    })}
                  </h3>
                  <div className="text-right">
                    <p className={`text-sm font-medium ${totalDia >= 0 ? "text-green-400" : "text-red-400"}`}>
                      {totalDia >= 0 ? "+" : ""}
                      {formatCurrency(totalDia)}
                    </p>
                    <p className="text-gray-400 text-xs">
                      {transaccionesDia.length} movimiento{transaccionesDia.length !== 1 ? "s" : ""}
                    </p>
                  </div>
                </div>

                {/* Transacciones del día */}
                <div className="space-y-2">
                  {transaccionesDia.map((transaccion) => (
                    <Card
                      key={transaccion.id}
                      className="bg-gray-800/50 border-gray-700 cursor-pointer hover:bg-gray-700/30 transition-colors"
                      onClick={() => setTransaccionSeleccionada(transaccion)}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <div
                              className={`w-10 h-10 rounded-lg flex items-center justify-center ${getColorCategoria(
                                transaccion.tipo,
                                transaccion.categoria,
                              )}`}
                            >
                              {getIconoCategoria(transaccion.categoria)}
                            </div>

                            <div className="flex-1 min-w-0">
                              <div className="flex items-center space-x-2">
                                <p className="text-white font-medium truncate">
                                  {transaccion.comercio || transaccion.descripcion}
                                </p>
                                <Badge
                                  variant="outline"
                                  className={`text-xs ${
                                    transaccion.estado === "completada"
                                      ? "bg-green-900/20 text-green-400 border-green-600"
                                      : transaccion.estado === "pendiente"
                                        ? "bg-yellow-900/20 text-yellow-400 border-yellow-600"
                                        : "bg-red-900/20 text-red-400 border-red-600"
                                  }`}
                                >
                                  {transaccion.estado}
                                </Badge>
                              </div>

                              <div className="flex items-center space-x-2 mt-1">
                                <p className="text-gray-400 text-sm">{transaccion.categoria}</p>
                                {transaccion.numeroTarjeta && (
                                  <>
                                    <span className="text-gray-600">•</span>
                                    <p className="text-gray-400 text-sm">{transaccion.numeroTarjeta}</p>
                                  </>
                                )}
                              </div>

                              <p className="text-gray-500 text-xs mt-1">{formatFecha(transaccion.fecha)}</p>
                            </div>
                          </div>

                          <div className="text-right">
                            <p
                              className={`font-medium ${
                                transaccion.tipo === "ingreso" ? "text-green-400" : "text-red-400"
                              }`}
                            >
                              {transaccion.tipo === "ingreso" ? "+" : "-"}
                              {formatCurrency(transaccion.monto)}
                            </p>

                            {transaccion.ubicacion && (
                              <div className="flex items-center justify-end mt-1">
                                <MapPin className="w-3 h-3 text-gray-500 mr-1" />
                                <p className="text-gray-500 text-xs truncate max-w-20">
                                  {transaccion.ubicacion.direccion.split(",")[0]}
                                </p>
                              </div>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )
          })}

          {transaccionesFiltradas.length === 0 && (
            <Card className="bg-gray-800/50 border-gray-700">
              <CardContent className="p-8 text-center">
                <Search className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-white font-medium mb-2">No se encontraron transacciones</h3>
                <p className="text-gray-400 text-sm">Intenta ajustar los filtros o el término de búsqueda</p>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* Modal de detalle de transacción */}
      {transaccionSeleccionada && (
        <div className="fixed inset-0 bg-black/50 flex items-end justify-center z-50 p-4">
          <Card className="w-full max-w-sm bg-gray-800 border-gray-700 max-h-[85vh] overflow-y-auto">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg text-white">Detalle de Transacción</CardTitle>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setTransaccionSeleccionada(null)}
                  className="border-gray-600 text-gray-300"
                >
                  Cerrar
                </Button>
              </div>
            </CardHeader>

            <CardContent className="space-y-6">
              {/* Información principal */}
              <div className="text-center">
                <div
                  className={`w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 ${getColorCategoria(
                    transaccionSeleccionada.tipo,
                    transaccionSeleccionada.categoria,
                  )}`}
                >
                  {getIconoCategoria(transaccionSeleccionada.categoria)}
                </div>

                <h3 className="text-xl font-medium text-white mb-2">
                  {transaccionSeleccionada.comercio || transaccionSeleccionada.descripcion}
                </h3>

                <p
                  className={`text-3xl font-light mb-2 ${
                    transaccionSeleccionada.tipo === "ingreso" ? "text-green-400" : "text-red-400"
                  }`}
                >
                  {transaccionSeleccionada.tipo === "ingreso" ? "+" : "-"}
                  {formatCurrency(transaccionSeleccionada.monto)}
                </p>

                <Badge
                  variant="outline"
                  className={`${
                    transaccionSeleccionada.estado === "completada"
                      ? "bg-green-900/20 text-green-400 border-green-600"
                      : transaccionSeleccionada.estado === "pendiente"
                        ? "bg-yellow-900/20 text-yellow-400 border-yellow-600"
                        : "bg-red-900/20 text-red-400 border-red-600"
                  }`}
                >
                  {transaccionSeleccionada.estado}
                </Badge>
              </div>

              {/* Detalles */}
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-gray-400">Fecha y hora</p>
                    <p className="text-white">{formatFecha(transaccionSeleccionada.fecha)}</p>
                  </div>
                  <div>
                    <p className="text-gray-400">Categoría</p>
                    <p className="text-white">{transaccionSeleccionada.categoria}</p>
                  </div>
                  <div>
                    <p className="text-gray-400">Método de pago</p>
                    <p className="text-white">{transaccionSeleccionada.metodoPago}</p>
                  </div>
                  <div>
                    <p className="text-gray-400">Autorización</p>
                    <p className="text-white font-mono text-xs">{transaccionSeleccionada.autorizacion}</p>
                  </div>
                </div>

                {transaccionSeleccionada.numeroTarjeta && (
                  <div>
                    <p className="text-gray-400 text-sm">Tarjeta utilizada</p>
                    <div className="flex items-center space-x-2 mt-1">
                      <CreditCard className="w-4 h-4 text-gray-400" />
                      <p className="text-white">{transaccionSeleccionada.numeroTarjeta}</p>
                    </div>
                  </div>
                )}

                {transaccionSeleccionada.ubicacion && (
                  <div>
                    <p className="text-gray-400 text-sm">Ubicación</p>
                    <div className="flex items-start space-x-2 mt-1">
                      <MapPin className="w-4 h-4 text-gray-400 mt-0.5" />
                      <p className="text-white text-sm">{transaccionSeleccionada.ubicacion.direccion}</p>
                    </div>
                  </div>
                )}

                {transaccionSeleccionada.subcategoria && (
                  <div>
                    <p className="text-gray-400 text-sm">Subcategoría</p>
                    <p className="text-white">{transaccionSeleccionada.subcategoria}</p>
                  </div>
                )}

                {transaccionSeleccionada.comision && (
                  <div className="bg-amber-900/20 border border-amber-800/30 rounded-lg p-3">
                    <p className="text-amber-400 text-sm">Comisión aplicada</p>
                    <p className="text-white font-medium">{formatCurrency(transaccionSeleccionada.comision)}</p>
                  </div>
                )}

                {/* Saldos */}
                <div className="bg-gray-700/50 rounded-lg p-3">
                  <p className="text-gray-400 text-sm mb-2">Movimiento de saldo</p>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Saldo anterior:</span>
                      <span className="text-white">{formatCurrency(transaccionSeleccionada.saldoAnterior)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Saldo posterior:</span>
                      <span className="text-white">{formatCurrency(transaccionSeleccionada.saldoPosterior)}</span>
                    </div>
                  </div>
                </div>

                {/* Etiquetas */}
                {transaccionSeleccionada.etiquetas && transaccionSeleccionada.etiquetas.length > 0 && (
                  <div>
                    <p className="text-gray-400 text-sm mb-2">Etiquetas</p>
                    <div className="flex flex-wrap gap-2">
                      {transaccionSeleccionada.etiquetas.map((etiqueta, index) => (
                        <Badge key={index} variant="outline" className="bg-blue-900/20 text-blue-400 border-blue-600">
                          {etiqueta}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Acciones */}
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-2">
                  <Button variant="outline" className="border-blue-600 text-blue-400">
                    <Download className="w-4 h-4 mr-2" />
                    Comprobante
                  </Button>

                  <Button variant="outline" className="border-gray-600 text-gray-300">
                    <MoreHorizontal className="w-4 h-4 mr-2" />
                    Más opciones
                  </Button>
                </div>

                {transaccionSeleccionada.estado === "pendiente" && (
                  <Button variant="outline" className="w-full border-red-600 text-red-400">
                    Cancelar transacción
                  </Button>
                )}

                {transaccionSeleccionada.tipo === "egreso" && transaccionSeleccionada.comercio && (
                  <Button variant="outline" className="w-full border-green-600 text-green-400">
                    Repetir transacción
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
