import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { 
  Target, 
  Plus, 
  Calendar,
  TrendingUp,
  PiggyBank,
  Home,
  Plane,
  GraduationCap,
  Shield,
  DollarSign,
  Settings,
  Zap,
  CheckCircle,
  Clock,
  Pause,
  MoreVertical
} from "lucide-react"
import { bankingService, type MetaFinanciera, type Usuario } from "@/lib/bankingService"

interface MetasScreenProps {
  usuario: Usuario
}

export function MetasScreen({ usuario }: MetasScreenProps) {
  const [metas, setMetas] = useState<MetaFinanciera[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [mostrarCrearMeta, setMostrarCrearMeta] = useState(false)
  const [metaSeleccionada, setMetaSeleccionada] = useState<MetaFinanciera | null>(null)
  const [nuevaMeta, setNuevaMeta] = useState({
    nombre: '',
    descripcion: '',
    objetivo: 0,
    fechaLimite: '',
    categoria: 'ahorro' as const,
    prioridad: 'media' as const,
    aporteAutomatico: {
      activo: false,
      monto: 0,
      frecuencia: 'mensual' as const
    }
  })

  useEffect(() => {
    cargarMetas()
  }, [])

  const cargarMetas = async () => {
    setIsLoading(true)
    try {
      const data = await bankingService.getMetas(usuario.id)
      setMetas(data)
    } catch (error) {
      console.error('Error cargando metas:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("es-MX", {
      style: "currency",
      currency: "MXN",
    }).format(amount)
  }

  const formatFecha = (fechaStr: string) => {
    return new Date(fechaStr).toLocaleDateString('es-MX', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    })
  }

  const calcularDiasRestantes = (fechaLimite: string) => {
    const hoy = new Date()
    const limite = new Date(fechaLimite)
    const diferencia = limite.getTime() - hoy.getTime()
    return Math.ceil(diferencia / (1000 * 3600 * 24))
  }

  const calcularProgreso = (actual: number, objetivo: number) => {
    return Math.min((actual / objetivo) * 100, 100)
  }

  const getIconoCategoria = (categoria: string) => {
    const iconos: Record<string, any> = {
      'ahorro': PiggyBank,
      'inversion': TrendingUp,
      'compra': Home,
      'emergencia': Shield,
      'educacion': GraduationCap
    }
    const Icono = iconos[categoria] || Target
    return <Icono className="w-5 h-5" />
  }

  const getColorCategoria = (categoria: string) => {
    const colores: Record<string, string> = {
      'ahorro': 'text-green-400 bg-green-900/20 border-green-800/30',
      'inversion': 'text-blue-400 bg-blue-900/20 border-blue-800/30',
      'compra': 'text-purple-400 bg-purple-900/20 border-purple-800/30',
      'emergencia': 'text-amber-400 bg-amber-900/20 border-amber-800/30',
      'educacion': 'text-cyan-400 bg-cyan-900/20 border-cyan-800/30'
    }
    return colores[categoria] || 'text-gray-400 bg-gray-900/20 border-gray-800/30'
  }

  const getColorPrioridad = (prioridad: string) => {
    const colores: Record<string, string> = {
      'alta': 'bg-red-900/20 text-red-400 border-red-600',
      'media': 'bg-yellow-900/20 text-yellow-400 border-yellow-600',
      'baja': 'bg-green-900/20 text-green-400 border-green-600'
    }
    return colores[prioridad] || 'bg-gray-900/20 text-gray-400 border-gray-600'
  }

  const getIconoEstado = (estado: string) => {
    switch (estado) {
      case 'completada':
        return <CheckCircle className="w-4 h-4 text-green-400" />
      case 'pausada':
        return <Pause className="w-4 h-4 text-yellow-400" />
      case 'vencida':
        return <Clock className="w-4 h-4 text-red-400" />
      default:
        return <Target className="w-4 h-4 text-blue-400" />
    }
  }

  const crearMeta = async () => {
    try {
      await bankingService.crearMeta(usuario.id, nuevaMeta)
      await cargarMetas()
      setMostrarCrearMeta(false)
      setNuevaMeta({
        nombre: '',
        descripcion: '',
        objetivo: 0,
        fechaLimite: '',
        categoria: 'ahorro',
        prioridad: 'media',
        aporteAutomatico: {
          activo: false,
          monto: 0,
          frecuencia: 'mensual'
        }
      })
    } catch (error) {
      console.error('Error creando meta:', error)
    }
  }

  const metasActivas = metas.filter(m => m.estado === 'activa')
  const metasCompletadas = metas.filter(m => m.estado === 'completada')
  const totalObjetivos = metas.reduce((sum, m) => sum + m.objetivo, 0)
  const totalAhorrado = metas.reduce((sum, m) => sum + m.actual, 0)

  return (
    <div className="p-4 pb-20 space-y-6">
      {/* Header */}
      <div className="pt-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-light text-gray-100">Metas Financieras</h1>
            <p className="text-gray-400 text-sm">Planifica y alcanza tus objetivos</p>
          </div>
          <Button
            onClick={() => setMostrarCrearMeta(true)}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Nueva Meta
          </Button>
        </div>
      </div>

      {/* Resumen General */}
      <Card className="bg-gradient-to-br from-blue-900/40 to-purple-900/40 border-blue-800/30">
        <CardContent className="p-6">
          <div className="grid grid-cols-2 gap-6">
            <div className="text-center">
              <div className="flex items-center justify-center space-x-2 mb-2">
                <Target className="w-5 h-5 text-blue-400" />
                <p className="text-blue-400 text-sm">Progreso Total</p>
              </div>
              <p className="text-2xl font-light text-white">
                {totalObjetivos > 0 ? Math.round((totalAhorrado / totalObjetivos) * 100) : 0}%
              </p>
              <p className="text-gray-400 text-xs">
                {formatCurrency(totalAhorrado)} de {formatCurrency(totalObjetivos)}
              </p>
            </div>
            
            <div className="text-center">
              <div className="flex items-center justify-center space-x-2 mb-2">
                <CheckCircle className="w-5 h-5 text-green-400" />
                <p className="text-green-400 text-sm">Metas Activas</p>
              </div>
              <p className="text-2xl font-light text-white">{metasActivas.length}</p>
              <p className="text-gray-400 text-xs">
                {metasCompletadas.length} completadas
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Lista de Metas */}
      {isLoading ? (
        <div className="flex justify-center py-8">
          <div className="animate-spin w-8 h-8 border-2 border-blue-400 border-t-transparent rounded-full"></div>
        </div>
      ) : (
        <div className="space-y-4">
          {metas.length === 0 ? (
            <Card className="bg-gray-800/50 border-gray-700">
              <CardContent className="p-8 text-center">
                <Target className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-white font-medium mb-2">¡Crea tu primera meta!</h3>
                <p className="text-gray-400 text-sm mb-4">
                  Define objetivos claros y alcanza tus sueños financieros
                </p>
                <Button
                  onClick={() => setMostrarCrearMeta(true)}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Crear Meta
                </Button>
              </CardContent>
            </Card>
          ) : (
            metas.map((meta) => {
              const progreso = calcularProgreso(meta.actual, meta.objetivo)
              const diasRestantes = calcularDiasRestantes(meta.fechaLimite)
              const colorCategoria = getColorCategoria(meta.categoria)

              return (
                <Card key={meta.id} className="bg-gray-800/50 border-gray-700">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-start space-x-4">
                        <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${colorCategoria}`}>
                          {getIconoCategoria(meta.categoria)}
                        </div>
                        
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-1">
                            <h3 className="text-white font-medium">{meta.nombre}</h3>
                            {getIconoEstado(meta.estado)}
                            <Badge variant="outline" className={getColorPrioridad(meta.prioridad)}>
                              {meta.prioridad}
                            </Badge>
                          </div>
                          <p className="text-gray-400 text-sm">{meta.descripcion}</p>
                          
                          <div className="flex items-center space-x-4 mt-2 text-xs text-gray-500">
                            <div className="flex items-center">
                              <Calendar className="w-3 h-3 mr-1" />
                              <span>
                                {diasRestantes > 0 ? `${diasRestantes} días restantes` : 
                                 diasRestantes === 0 ? 'Vence hoy' : `Venció hace ${Math.abs(diasRestantes)} días`}
                              </span>
                            </div>
                            
                            {meta.aporteAutomatico?.activo && (
                              <div className="flex items-center">
                                <Zap className="w-3 h-3 mr-1 text-blue-400" />
                                <span className="text-blue-400">Auto: {formatCurrency(meta.aporteAutomatico.monto)}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                      
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setMetaSeleccionada(meta)}
                        className="border-gray-600 text-gray-300"
                      >
                        <MoreVertical className="w-4 h-4" />
                      </Button>
                    </div>

                    {/* Progreso */}
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-300">Progreso: {progreso.toFixed(1)}%</span>
                        <span className="text-white font-medium">
                          {formatCurrency(meta.actual)} / {formatCurrency(meta.objetivo)}
                        </span>
                      </div>
                      <Progress value={progreso} className="h-2" />
                      
                      {progreso >= 100 && (
                        <div className="flex items-center space-x-2 mt-2">
                          <CheckCircle className="w-4 h-4 text-green-400" />
                          <span className="text-green-400 text-sm">¡Meta completada! 🎉</span>
                        </div>
                      )}
                    </div>

                    {/* Acciones rápidas */}
                    <div className="flex space-x-2 mt-4">
                      <Button size="sm" variant="outline" className="border-blue-600 text-blue-400">
                        <DollarSign className="w-4 h-4 mr-1" />
                        Aportar
                      </Button>
                      
                      {!meta.aporteAutomatico?.activo && meta.estado === 'activa' && (
                        <Button size="sm" variant="outline" className="border-purple-600 text-purple-400">
                          <Zap className="w-4 h-4 mr-1" />
                          Automatizar
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              )
            })
          )}
        </div>
      )}

      {/* Modal Crear Meta */}
      {mostrarCrearMeta && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-md bg-gray-800 border-gray-700 max-h-[90vh] overflow-y-auto">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg text-white">Nueva Meta Financiera</CardTitle>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setMostrarCrearMeta(false)}
                  className="border-gray-600 text-gray-300"
                >
                  Cancelar
                </Button>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <div>
                <Label className="text-gray-300">Nombre de la meta</Label>
                <Input
                  value={nuevaMeta.nombre}
                  onChange={(e) => setNuevaMeta({...nuevaMeta, nombre: e.target.value})}
                  placeholder="Ej: Vacaciones en Europa"
                  className="bg-gray-700/50 border-gray-600 text-white"
                />
              </div>

              <div>
                <Label className="text-gray-300">Descripción</Label>
                <Input
                  value={nuevaMeta.descripcion}
                  onChange={(e) => setNuevaMeta({...nuevaMeta, descripcion: e.target.value})}
                  placeholder="Describe tu objetivo..."
                  className="bg-gray-700/50 border-gray-600 text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-300">Monto objetivo</Label>
                  <Input
                    type="number"
                    value={nuevaMeta.objetivo}
                    onChange={(e) => setNuevaMeta({...nuevaMeta, objetivo: Number(e.target.value)})}
                    placeholder="50000"
                    className="bg-gray-700/50 border-gray-600 text-white"
                  />
                </div>

                <div>
                  <Label className="text-gray-300">Fecha límite</Label>
                  <Input
                    type="date"
                    value={nuevaMeta.fechaLimite}
                    onChange={(e) => setNuevaMeta({...nuevaMeta, fechaLimite: e.target.value})}
                    className="bg-gray-700/50 border-gray-600 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-300">Categoría</Label>
                  <select
                    value={nuevaMeta.categoria}
                    onChange={(e) => setNuevaMeta({...nuevaMeta, categoria: e.target.value as any})}
                    className="w-full bg-gray-700/50 border border-gray-600 rounded-md px-3 py-2 text-white"
                  >
                    <option value="ahorro">Ahorro</option>
                    <option value="inversion">Inversión</option>
                    <option value="compra">Compra</option>
                    <option value="emergencia">Emergencia</option>
                    <option value="educacion">Educación</option>
                  </select>
                </div>

                <div>
                  <Label className="text-gray-300">Prioridad</Label>
                  <select
                    value={nuevaMeta.prioridad}
                    onChange={(e) => setNuevaMeta({...nuevaMeta, prioridad: e.target.value as any})}
                    className="w-full bg-gray-700/50 border border-gray-600 rounded-md px-3 py-2 text-white"
                  >
                    <option value="baja">Baja</option>
                    <option value="media">Media</option>
                    <option value="alta">Alta</option>
                  </select>
                </div>
              </div>

              {/* Aporte automático */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label className="text-gray-300">Aporte automático</Label>
                  <button
                    type="button"
                    onClick={() => setNuevaMeta({
                      ...nuevaMeta,
                      aporteAutomatico: {
                        ...nuevaMeta.aporteAutomatico,
                        activo: !nuevaMeta.aporteAutomatico.activo
                      }
                    })}
                    className={`w-12 h-6 rounded-full relative transition-colors ${
                      nuevaMeta.aporteAutomatico.activo ? 'bg-blue-600' : 'bg-gray-600'
                    }`}
                  >
                    <div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-transform ${
                      nuevaMeta.aporteAutomatico.activo ? 'translate-x-7' : 'translate-x-1'
                    }`} />
                  </button>
                </div>

                {nuevaMeta.aporteAutomatico.activo && (
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-gray-300 text-sm">Monto</Label>
                      <Input
                        type="number"
                        value={nuevaMeta.aporteAutomatico.monto}
                        onChange={(e) => setNuevaMeta({
                          ...nuevaMeta,
                          aporteAutomatico: {
                            ...nuevaMeta.aporteAutomatico,
                            monto: Number(e.target.value)
                          }
                        })}
                        placeholder="1000"
                        className="bg-gray-700/50 border-gray-600 text-white"
                      />
                    </div>

                    <div>
                      <Label className="text-gray-300 text-sm">Frecuencia</Label>
                      <select
                        value={nuevaMeta.aporteAutomatico.frecuencia}
                        onChange={(e) => setNuevaMeta({
                          ...nuevaMeta,
                          aporteAutomatico: {
                            ...nuevaMeta.aporteAutomatico,
                            frecuencia: e.target.value as any
                          }
                        })}
                        className="w-full bg-gray-700/50 border border-gray-600 rounded-md px-3 py-2 text-white text-sm"
                      >
                        <option value="semanal">Semanal</option>
                        <option value="quincenal">Quincenal</option>
                        <option value="mensual">Mensual</option>
                      </select>
                    </div>
                  </div>
                )}
              </div>

              <Button
                onClick={crearMeta}
                className="w-full bg-blue-600 hover:bg-blue-700"
                disabled={!nuevaMeta.nombre || !nuevaMeta.objetivo || !nuevaMeta.fechaLimite}
              >
                <Target className="w-4 h-4 mr-2" />
                Crear Meta
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Modal Detalle Meta */}
      {metaSeleccionada && (
        <div className="fixed inset-0 bg-black/50 flex items-end justify-center z-50 p-4">
          <Card className="w-full max-w-sm bg-gray-800 border-gray-700 max-h-[85vh] overflow-y-auto">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg text-white">Gestionar Meta</CardTitle>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setMetaSeleccionada(null)}
                  className="border-gray-600 text-gray-300"
                >
                  Cerrar
                </Button>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-6">
              {/* Información de la meta */}
              <div className="text-center">
                <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 ${
                  getColorCategoria(metaSeleccionada.categoria)
                }`}>
                  {getIconoCategoria(metaSeleccionada.categoria)}
                </div>
                <h3 className="text-xl font-medium text-white mb-2">
                  {metaSeleccionada.nombre}
                </h3>
                <p className="text-gray-400 text-sm mb-4">
                  {metaSeleccionada.descripcion}
                </p>
                
                <div className="text-center">
                  <p className="text-3xl font-light text-white">
                    {calcularProgreso(metaSeleccionada.actual, metaSeleccionada.objetivo).toFixed(1)}%
                  </p>
                  <p className="text-gray-400 text-sm">
                    {formatCurrency(metaSeleccionada.actual)} de {formatCurrency(metaSeleccionada.objetivo)}
                  </p>
                  <Progress 
                    value={calcularProgreso(metaSeleccionada.actual, metaSeleccionada.objetivo)} 
                    className="mt-2" 
                  />
                </div>
              </div>

              {/* Detalles */}
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-gray-400">Fecha límite</p>
                    <p className="text-white">{formatFecha(metaSeleccionada.fechaLimite)}</p>
                  </div>
                  <div>
                    <p className="text-gray-400">Días restantes</p>
                    <p className="text-white">{calcularDiasRestantes(metaSeleccionada.fechaLimite)}</p>
                  </div>
                  <div>
                    <p className="text-gray-400">Prioridad</p>
                    <Badge variant="outline" className={getColorPrioridad(metaSeleccionada.prioridad)}>
                      {metaSeleccionada.prioridad}
                    </Badge>
                  </div>
                  <div>
                    <p className="text-gray-400">Estado</p>
                    <div className="flex items-center space-x-1">
                      {getIconoEstado(metaSeleccionada.estado)}
                      <span className="text-white capitalize">{metaSeleccionada.estado}</span>
                    </div>
                  </div>
                </div>

                {metaSeleccionada.aporteAutomatico?.activo && (
                  <div className="bg-blue-900/20 border border-blue-800/30 rounded-lg p-3">
                    <div className="flex items-center space-x-2 mb-2">
                      <Zap className="w-4 h-4 text-blue-400" />
                      <span className="text-blue-400 text-sm font-medium">Aporte Automático Activo</span>
                    </div>
                    <p className="text-white text-sm">
                      {formatCurrency(metaSeleccionada.aporteAutomatico.monto)} {metaSeleccionada.aporteAutomatico.frecuencia}
                    </p>
                    <p className="text-gray-400 text-xs">
                      Próximo aporte: {formatFecha(metaSeleccionada.aporteAutomatico.fechaProximo || new Date().toISOString())}
                    </p>
                  </div>
                )}

                {/* Proyección */}
                {metaSeleccionada.aporteAutomatico?.activo && (
                  <div className="bg-gray-700/50 rounded-lg p-3">
                    <p className="text-gray-400 text-sm mb-2">Proyección</p>
                    <p className="text-white text-sm">
                      Con aportes automáticos, alcanzarás tu meta aproximadamente el{' '}
                      {new Date(Date.now() + (
                        (metaSeleccionada.objetivo - metaSeleccionada.actual) / 
                        metaSeleccionada.aporteAutomatico.monto * 30 * 24 * 60 * 60 * 1000
                      )).toLocaleDateString('es-MX')}
                    </p>
                  </div>
                )}
              </div>

              {/* Acciones */}
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-2">
                  <Button variant="outline" className="border-green-600 text-green-400">
                    <DollarSign className="w-4 h-4 mr-2" />
                    Aportar
                  </Button>
                  
                  <Button variant="outline" className="border-blue-600 text-blue-400">
                    <Settings className="w-4 h-4 mr-2" />
                    Configurar
                  </Button>
                </div>

                {metaSeleccionada.estado === 'activa' && (
                  <Button variant="outline" className="w-full border-yellow-600 text-yellow-400">
                    <Pause className="w-4 h-4 mr-2" />
                    Pausar Meta
                  </Button>
                )}

                {calcularProgreso(metaSeleccionada.actual, metaSeleccionada.objetivo) >= 100 && 
                 metaSeleccionada.estado !== 'completada' && (
                  <Button className="w-full bg-green-600 hover:bg-green-700">
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Marcar como Completada
                  </Button>
                )}
              </div>

              {/* Historial de aportes */}
              <div>
                <h4 className="text-white font-medium mb-3">Últimos aportes</h4>
                <div className="space-y-2">
                  <div className="flex justify-between items-center py-2 border-b border-gray-700">
                    <div>
                      <p className="text-white text-sm">Aporte manual</p>
                      <p className="text-gray-400 text-xs">25 May 2025</p>
                    </div>
                    <p className="text-green-400 font-medium">+{formatCurrency(5000)}</p>
                  </div>
                  
                  <div className="flex justify-between items-center py-2 border-b border-gray-700">
                    <div>
                      <p className="text-white text-sm">Aporte automático</p>
                      <p className="text-gray-400 text-xs">1 May 2025</p>
                    </div>
                    <p className="text-green-400 font-medium">+{formatCurrency(2000)}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
