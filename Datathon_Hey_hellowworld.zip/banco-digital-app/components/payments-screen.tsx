"use client"

import { useState, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { QrCode, Scan, Send, Users, Clock, X, ContactRound, Zap, Calendar, DollarSign } from "lucide-react"
import type { Usuario } from "@/lib/bankingService"

interface PaymentsScreenProps {
  usuario: Usuario
}

interface Contact {
  id: string
  name: string
  phone: string
  avatar?: string
  isFrequent: boolean
  lastTransaction?: string
}

interface ScheduledPayment {
  id: string
  recipient: string
  amount: number
  frequency: "weekly" | "monthly" | "biweekly"
  nextDate: string
  isActive: boolean
}

export function PaymentsScreen({ usuario }: PaymentsScreenProps) {
  const [activeTab, setActiveTab] = useState<"send" | "qr" | "schedule" | "split">("send")
  const [modalOpen, setModalOpen] = useState<string | null>(null)
  const [paymentData, setPaymentData] = useState({
    amount: "",
    recipient: "",
    concept: "",
    method: "instant",
  })
  const [qrData, setQrData] = useState("")
  const [scanning, setScanning] = useState(false)
  const [splitGroup, setSplitGroup] = useState<Contact[]>([])
  const [mensaje, setMensaje] = useState<{ tipo: "success" | "error"; texto: string } | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)

  // Contactos frecuentes simulados
  const frequentContacts: Contact[] = [
    { id: "1", name: "Ana García", phone: "+52 81 1234 5678", isFrequent: true, lastTransaction: "2025-05-20" },
    { id: "2", name: "Carlos López", phone: "+52 81 8765 4321", isFrequent: true, lastTransaction: "2025-05-18" },
    { id: "3", name: "Diana Ruiz", phone: "+52 81 5555 1234", isFrequent: true, lastTransaction: "2025-05-15" },
    { id: "4", name: "Eduardo Sánchez", phone: "+52 81 9999 8888", isFrequent: false },
    { id: "5", name: "Fernanda Torres", phone: "+52 81 7777 6666", isFrequent: false },
  ]

  const scheduledPayments: ScheduledPayment[] = [
    { id: "1", recipient: "Renta Depto", amount: 8500, frequency: "monthly", nextDate: "2025-06-01", isActive: true },
    { id: "2", recipient: "Gimnasio Fit", amount: 450, frequency: "monthly", nextDate: "2025-06-05", isActive: true },
    { id: "3", recipient: "Ana García", amount: 500, frequency: "weekly", nextDate: "2025-05-28", isActive: false },
  ]

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("es-MX", {
      style: "currency",
      currency: "MXN",
    }).format(amount)
  }

  const mostrarMensaje = (tipo: "success" | "error", texto: string) => {
    setMensaje({ tipo, texto })
    setTimeout(() => setMensaje(null), 4000)
  }

  const handleSendPayment = async () => {
    if (!paymentData.amount || !paymentData.recipient) {
      mostrarMensaje("error", "Completa todos los campos obligatorios")
      return
    }

    const amount = Number.parseFloat(paymentData.amount)
    if (amount <= 0 || amount > usuario.saldo) {
      mostrarMensaje("error", "Monto inválido o saldo insuficiente")
      return
    }

    setIsLoading(true)

    try {
      // Simular procesamiento de pago
      await new Promise((resolve) => setTimeout(resolve, 2000))

      mostrarMensaje("success", `Pago de ${formatCurrency(amount)} enviado exitosamente`)

      setPaymentData({ amount: "", recipient: "", concept: "", method: "instant" })
      setModalOpen(null)
    } catch (error) {
      mostrarMensaje("error", "Error al procesar el pago")
    } finally {
      setIsLoading(false)
    }
  }

  const generateQR = () => {
    const amount = Number.parseFloat(paymentData.amount)
    if (!amount || amount <= 0) {
      mostrarMensaje("error", "Ingresa un monto válido")
      return
    }

    // Simular generación de QR
    const qrString = JSON.stringify({
      type: "payment_request",
      recipient: usuario.id,
      amount: amount,
      concept: paymentData.concept || "Pago Hey Banco",
      timestamp: Date.now(),
    })

    setQrData(qrString)
    setModalOpen("qr-display")
  }

  const startQRScanning = async () => {
    setScanning(true)
    setModalOpen("qr-scan")

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
      })

      if (videoRef.current) {
        videoRef.current.srcObject = stream
        videoRef.current.play()
      }
    } catch (error) {
      mostrarMensaje("error", "No se pudo acceder a la cámara")
      setScanning(false)
      setModalOpen(null)
    }
  }

  const stopQRScanning = () => {
    if (videoRef.current?.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks()
      tracks.forEach((track) => track.stop())
    }
    setScanning(false)
    setModalOpen(null)
  }

  const processQRCode = () => {
    // Simular procesamiento de QR
    const mockQRData = {
      type: "payment_request",
      recipient: "OXXO Constitución",
      amount: 156.5,
      concept: "Compra en tienda",
    }

    setPaymentData({
      amount: mockQRData.amount.toString(),
      recipient: mockQRData.recipient,
      concept: mockQRData.concept,
      method: "instant",
    })

    stopQRScanning()
    setModalOpen("payment-confirm")
  }

  const addToSplitGroup = (contact: Contact) => {
    if (!splitGroup.find((c) => c.id === contact.id)) {
      setSplitGroup([...splitGroup, contact])
    }
  }

  const removeFromSplitGroup = (contactId: string) => {
    setSplitGroup(splitGroup.filter((c) => c.id !== contactId))
  }

  const processSplitPayment = async () => {
    if (splitGroup.length === 0 || !paymentData.amount) {
      mostrarMensaje("error", "Selecciona contactos y monto")
      return
    }

    const totalAmount = Number.parseFloat(paymentData.amount)
    const amountPerPerson = totalAmount / (splitGroup.length + 1) // +1 incluye al usuario

    setIsLoading(true)

    try {
      await new Promise((resolve) => setTimeout(resolve, 1500))

      mostrarMensaje(
        "success",
        `Solicitud de ${formatCurrency(amountPerPerson)} enviada a ${splitGroup.length} contactos`,
      )
      setSplitGroup([])
      setPaymentData({ amount: "", recipient: "", concept: "", method: "instant" })
    } catch (error) {
      mostrarMensaje("error", "Error al procesar split")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="p-4 pb-20 space-y-6">
      {/* Mensaje de notificación */}
      {mensaje && (
        <div
          className={`fixed top-24 left-1/2 transform -translate-x-1/2 z-50 p-4 rounded-lg border max-w-sm w-full mx-4 ${
            mensaje.tipo === "success"
              ? "bg-green-900/90 border-green-600 text-green-100"
              : "bg-red-900/90 border-red-600 text-red-100"
          }`}
        >
          <div className="flex items-center justify-between">
            <p className="text-sm">{mensaje.texto}</p>
            <Button variant="ghost" size="sm" onClick={() => setMensaje(null)} className="text-current p-1 h-auto">
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="pt-8">
        <h1 className="text-2xl font-light text-gray-100">Pagos y Transferencias</h1>
        <p className="text-gray-400 text-sm">Envía dinero de forma rápida y segura</p>
      </div>

      {/* Saldo disponible */}
      <Card className="bg-gradient-to-r from-green-900/20 to-emerald-900/20 border-green-800/30">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-400 text-sm">Saldo disponible</p>
              <p className="text-white text-2xl font-light">{formatCurrency(usuario.saldo)}</p>
            </div>
            <div className="w-12 h-12 bg-green-900/30 rounded-xl flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-green-400" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tabs de navegación */}
      <div className="flex space-x-1 bg-gray-800/50 rounded-lg p-1">
        {[
          { key: "send", label: "Enviar", icon: Send },
          { key: "qr", label: "QR", icon: QrCode },
          { key: "schedule", label: "Programar", icon: Calendar },
          { key: "split", label: "Dividir", icon: Users },
        ].map((tab) => (
          <Button
            key={tab.key}
            variant={activeTab === tab.key ? "default" : "ghost"}
            size="sm"
            onClick={() => setActiveTab(tab.key as any)}
            className={`flex-1 ${activeTab === tab.key ? "bg-blue-600" : "text-gray-400"}`}
          >
            <tab.icon className="w-4 h-4 mr-1" />
            {tab.label}
          </Button>
        ))}
      </div>

      {/* Contenido según tab activo */}
      {activeTab === "send" && (
        <div className="space-y-4">
          {/* Contactos frecuentes */}
          <div>
            <h3 className="text-white font-medium mb-3">Contactos frecuentes</h3>
            <div className="flex space-x-3 overflow-x-auto pb-2">
              {frequentContacts
                .filter((c) => c.isFrequent)
                .map((contact) => (
                  <button
                    key={contact.id}
                    onClick={() => {
                      setPaymentData({ ...paymentData, recipient: contact.name })
                      setModalOpen("payment-form")
                    }}
                    className="flex flex-col items-center space-y-2 min-w-[80px]"
                  >
                    <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center">
                      <ContactRound className="w-6 h-6 text-white" />
                    </div>
                    <p className="text-gray-300 text-xs text-center">{contact.name.split(" ")[0]}</p>
                  </button>
                ))}
            </div>
          </div>

          {/* Acciones rápidas */}
          <div className="grid grid-cols-2 gap-3">
            <Button
              onClick={() => setModalOpen("payment-form")}
              className="bg-blue-600 hover:bg-blue-700 h-16 flex flex-col"
            >
              <Send className="w-6 h-6 mb-1" />
              <span>Enviar Dinero</span>
            </Button>

            <Button
              onClick={startQRScanning}
              variant="outline"
              className="border-gray-600 text-gray-300 h-16 flex flex-col"
            >
              <Scan className="w-6 h-6 mb-1" />
              <span>Escanear QR</span>
            </Button>
          </div>
        </div>
      )}

      {activeTab === "qr" && (
        <div className="space-y-4">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Generar código QR</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-gray-300">Monto a cobrar</Label>
                <Input
                  type="number"
                  value={paymentData.amount}
                  onChange={(e) => setPaymentData({ ...paymentData, amount: e.target.value })}
                  placeholder="0.00"
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
              <div>
                <Label className="text-gray-300">Concepto (opcional)</Label>
                <Input
                  value={paymentData.concept}
                  onChange={(e) => setPaymentData({ ...paymentData, concept: e.target.value })}
                  placeholder="Descripción del pago"
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
              <Button onClick={generateQR} className="w-full bg-purple-600 hover:bg-purple-700">
                <QrCode className="w-4 h-4 mr-2" />
                Generar QR
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      {activeTab === "schedule" && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-white font-medium">Pagos programados</h3>
            <Button size="sm" className="bg-green-600 hover:bg-green-700">
              <Calendar className="w-4 h-4 mr-1" />
              Nuevo
            </Button>
          </div>

          {scheduledPayments.map((payment) => (
            <Card key={payment.id} className="bg-gray-800/50 border-gray-700">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-blue-900/30 rounded-lg flex items-center justify-center">
                      <Calendar className="w-5 h-5 text-blue-400" />
                    </div>
                    <div>
                      <p className="text-white font-medium">{payment.recipient}</p>
                      <p className="text-gray-400 text-sm">
                        {payment.frequency === "monthly"
                          ? "Mensual"
                          : payment.frequency === "weekly"
                            ? "Semanal"
                            : "Quincenal"}{" "}
                        • Próximo: {new Date(payment.nextDate).toLocaleDateString("es-MX")}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-white font-medium">{formatCurrency(payment.amount)}</p>
                    <Badge
                      className={payment.isActive ? "bg-green-900/20 text-green-400" : "bg-gray-700 text-gray-400"}
                    >
                      {payment.isActive ? "Activo" : "Pausado"}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {activeTab === "split" && (
        <div className="space-y-4">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Dividir gasto</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-gray-300">Monto total</Label>
                <Input
                  type="number"
                  value={paymentData.amount}
                  onChange={(e) => setPaymentData({ ...paymentData, amount: e.target.value })}
                  placeholder="0.00"
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
              <div>
                <Label className="text-gray-300">Concepto</Label>
                <Input
                  value={paymentData.concept}
                  onChange={(e) => setPaymentData({ ...paymentData, concept: e.target.value })}
                  placeholder="Ej: Cena en restaurante"
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>

              {/* Contactos seleccionados */}
              {splitGroup.length > 0 && (
                <div>
                  <p className="text-gray-300 text-sm mb-2">Dividir entre {splitGroup.length + 1} personas:</p>
                  <div className="flex flex-wrap gap-2">
                    {splitGroup.map((contact) => (
                      <Badge key={contact.id} className="bg-blue-900/20 text-blue-400 border-blue-600">
                        {contact.name}
                        <button onClick={() => removeFromSplitGroup(contact.id)} className="ml-1">
                          <X className="w-3 h-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                  {paymentData.amount && (
                    <p className="text-gray-400 text-sm mt-2">
                      {formatCurrency(Number.parseFloat(paymentData.amount) / (splitGroup.length + 1))} por persona
                    </p>
                  )}
                </div>
              )}

              {/* Lista de contactos */}
              <div>
                <p className="text-gray-300 text-sm mb-2">Seleccionar contactos:</p>
                <div className="space-y-2 max-h-40 overflow-y-auto">
                  {frequentContacts.map((contact) => (
                    <button
                      key={contact.id}
                      onClick={() => addToSplitGroup(contact)}
                      disabled={splitGroup.some((c) => c.id === contact.id)}
                      className={`w-full p-2 rounded-lg border text-left transition-colors ${
                        splitGroup.some((c) => c.id === contact.id)
                          ? "bg-blue-900/20 border-blue-600 text-blue-400"
                          : "bg-gray-700 border-gray-600 text-white hover:bg-gray-600"
                      }`}
                    >
                      <p className="font-medium">{contact.name}</p>
                      <p className="text-xs text-gray-400">{contact.phone}</p>
                    </button>
                  ))}
                </div>
              </div>

              <Button
                onClick={processSplitPayment}
                disabled={splitGroup.length === 0 || !paymentData.amount || isLoading}
                className="w-full bg-green-600 hover:bg-green-700"
              >
                {isLoading ? (
                  <div className="flex items-center">
                    <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2"></div>
                    Enviando solicitudes...
                  </div>
                ) : (
                  <>
                    <Users className="w-4 h-4 mr-2" />
                    Enviar solicitudes
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Modal de formulario de pago */}
      {modalOpen === "payment-form" && (
        <div className="fixed inset-0 bg-black/50 flex items-end justify-center z-50 p-4">
          <Card className="w-full max-w-sm bg-gray-800 border-gray-700">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-white">Enviar dinero</CardTitle>
                <Button variant="ghost" size="sm" onClick={() => setModalOpen(null)} className="text-gray-400">
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-gray-300">Destinatario</Label>
                <Input
                  value={paymentData.recipient}
                  onChange={(e) => setPaymentData({ ...paymentData, recipient: e.target.value })}
                  placeholder="Nombre o número de cuenta"
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
              <div>
                <Label className="text-gray-300">Monto</Label>
                <Input
                  type="number"
                  value={paymentData.amount}
                  onChange={(e) => setPaymentData({ ...paymentData, amount: e.target.value })}
                  placeholder="0.00"
                  className="bg-gray-700 border-gray-600 text-white"
                />
                <p className="text-gray-400 text-xs mt-1">Disponible: {formatCurrency(usuario.saldo)}</p>
              </div>
              <div>
                <Label className="text-gray-300">Concepto (opcional)</Label>
                <Input
                  value={paymentData.concept}
                  onChange={(e) => setPaymentData({ ...paymentData, concept: e.target.value })}
                  placeholder="Descripción del pago"
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>

              <div className="space-y-2">
                <Label className="text-gray-300">Tipo de envío</Label>
                <div className="space-y-2">
                  <button
                    onClick={() => setPaymentData({ ...paymentData, method: "instant" })}
                    className={`w-full p-3 rounded-lg border text-left ${
                      paymentData.method === "instant"
                        ? "bg-blue-900/20 border-blue-600 text-blue-400"
                        : "bg-gray-700 border-gray-600 text-white"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Inmediato</p>
                        <p className="text-xs text-gray-400">Sin costo adicional</p>
                      </div>
                      <Zap className="w-5 h-5" />
                    </div>
                  </button>
                  <button
                    onClick={() => setPaymentData({ ...paymentData, method: "scheduled" })}
                    className={`w-full p-3 rounded-lg border text-left ${
                      paymentData.method === "scheduled"
                        ? "bg-blue-900/20 border-blue-600 text-blue-400"
                        : "bg-gray-700 border-gray-600 text-white"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Programado</p>
                        <p className="text-xs text-gray-400">Enviar más tarde</p>
                      </div>
                      <Clock className="w-5 h-5" />
                    </div>
                  </button>
                </div>
              </div>

              <Button
                onClick={handleSendPayment}
                disabled={isLoading || !paymentData.amount || !paymentData.recipient}
                className="w-full bg-blue-600 hover:bg-blue-700"
              >
                {isLoading ? (
                  <div className="flex items-center">
                    <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2"></div>
                    Procesando...
                  </div>
                ) : (
                  `Enviar ${paymentData.amount ? formatCurrency(Number.parseFloat(paymentData.amount)) : ""}`
                )}
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Modal QR Display */}
      {modalOpen === "qr-display" && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-sm bg-gray-800 border-gray-700">
            <CardContent className="p-6 text-center">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-white font-medium">Código QR generado</h3>
                <Button variant="ghost" size="sm" onClick={() => setModalOpen(null)} className="text-gray-400">
                  <X className="w-4 h-4" />
                </Button>
              </div>

              {/* QR Code simulado */}
              <div className="w-48 h-48 bg-white rounded-lg mx-auto mb-4 flex items-center justify-center">
                <div className="grid grid-cols-8 gap-1">
                  {Array.from({ length: 64 }).map((_, i) => (
                    <div key={i} className={`w-2 h-2 ${Math.random() > 0.5 ? "bg-black" : "bg-white"}`}></div>
                  ))}
                </div>
              </div>

              <p className="text-white font-medium mb-2">{formatCurrency(Number.parseFloat(paymentData.amount))}</p>
              <p className="text-gray-400 text-sm mb-4">{paymentData.concept || "Pago Hey Banco"}</p>

              <p className="text-gray-500 text-xs">Muestra este código para recibir el pago</p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Modal QR Scanner */}
      {modalOpen === "qr-scan" && (
        <div className="fixed inset-0 bg-black flex items-center justify-center z-50">
          <div className="relative w-full h-full">
            <video ref={videoRef} className="w-full h-full object-cover" autoPlay playsInline />
            <canvas ref={canvasRef} className="hidden" />

            {/* Overlay */}
            <div className="absolute inset-0 bg-black/50">
              <div className="flex flex-col h-full">
                <div className="p-4 flex items-center justify-between">
                  <h3 className="text-white font-medium">Escanear código QR</h3>
                  <Button variant="ghost" size="sm" onClick={stopQRScanning} className="text-white">
                    <X className="w-6 h-6" />
                  </Button>
                </div>

                <div className="flex-1 flex items-center justify-center">
                  <div className="w-64 h-64 border-2 border-white rounded-lg relative">
                    <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-blue-400 rounded-tl-lg"></div>
                    <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-blue-400 rounded-tr-lg"></div>
                    <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-blue-400 rounded-bl-lg"></div>
                    <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-blue-400 rounded-br-lg"></div>
                  </div>
                </div>

                <div className="p-4 text-center">
                  <p className="text-white mb-4">Coloca el código QR dentro del marco</p>
                  <Button onClick={processQRCode} className="bg-blue-600 hover:bg-blue-700">
                    Procesar QR (Demo)
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
