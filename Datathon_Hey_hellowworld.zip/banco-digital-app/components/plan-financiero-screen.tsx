"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  TrendingDown,
  Target,
  AlertCircle,
  Calendar,
  DollarSign,
  CheckCircle,
  AlertTriangle,
  Brain,
} from "lucide-react"
import type { Usuario } from "@/lib/bankingService"

interface PlanFinancieroScreenProps {
  usuario: Usuario
}

export function PlanFinancieroScreen({ usuario }: PlanFinancieroScreenProps) {
  const [alertasActivas, setAlertasActivas] = useState<string[]>([])
  const [mostrarGraficas, setMostrarGraficas] = useState(true)

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("es-MX", {
      style: "currency",
      currency: "MXN",
    }).format(amount)
  }

  // 🎯 DATOS SIMULADOS DEL MODELO (en producción vendrían de tu API)
  const gastoProyectadoSemanal = 3200 // Predicción del modelo para esta semana
  const gastoProyectadoMensual = 13760 // Predicción del modelo para este mes
  const ahorroProyectado = 4500 // Ahorro estimado basado en predicciones

  // ✅ METAS DEL USUARIO
  const metaAhorro = 50000
  const limiteSemanal = 2800
  const limiteMensual = 12000

  // 🧠 ANÁLISIS INTELIGENTE
  const ahorroActual = Math.min(usuario.saldo * 0.6, metaAhorro)
  const progresoAhorro = (ahorroActual / metaAhorro) * 100
  const mesesRestantes = 8
  const ahorroProyectadoTotal = ahorroActual + ahorroProyectado * mesesRestantes

  // 🚨 DETECCIÓN DE PROBLEMAS
  const noAlcanzaraMeta = ahorroProyectadoTotal < metaAhorro
  const excedeLimiteSemanal = gastoProyectadoSemanal > limiteSemanal
  const excedeLimiteMensual = gastoProyectadoMensual > limiteMensual

  const deficitAhorro = noAlcanzaraMeta ? metaAhorro - ahorroProyectadoTotal : 0
  const excesoSemanal = excedeLimiteSemanal ? gastoProyectadoSemanal - limiteSemanal : 0
  const excesoMensual = excedeLimiteMensual ? gastoProyectadoMensual - limiteMensual : 0

  // 📊 ACTUALIZAR ALERTAS AUTOMÁTICAMENTE
  useEffect(() => {
    const nuevasAlertas: string[] = []

    if (noAlcanzaraMeta) nuevasAlertas.push("meta_ahorro")
    if (excedeLimiteSemanal) nuevasAlertas.push("limite_semanal")
    if (excedeLimiteMensual) nuevasAlertas.push("limite_mensual")

    setAlertasActivas(nuevasAlertas)
  }, [noAlcanzaraMeta, excedeLimiteSemanal, excedeLimiteMensual])

  return (
    <div className="p-4 pb-20 space-y-6">
      {/* Header */}
      <div className="pt-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-light text-gray-100">Plan Financiero</h1>
            <p className="text-gray-400 text-sm">Proyecciones y control de metas con IA</p>
          </div>

          {/* Toggle para mostrar/ocultar gráficas */}
          <Button
            variant="outline"
            size="sm"
            onClick={() => setMostrarGraficas(!mostrarGraficas)}
            className="border-gray-600 text-gray-300"
          >
            {mostrarGraficas ? "Ocultar Gráficas" : "Mostrar Gráficas"}
          </Button>
        </div>

        {/* Contador de Alertas */}
        {alertasActivas.length > 0 && (
          <div className="mt-2">
            <Badge variant="outline" className="bg-red-900/20 text-red-400 border-red-600">
              <AlertTriangle className="w-3 h-3 mr-1" />
              {alertasActivas.length} alerta{alertasActivas.length > 1 ? "s" : ""} activa
              {alertasActivas.length > 1 ? "s" : ""}
            </Badge>
          </div>
        )}
      </div>

      {/* 🎯 PROYECCIÓN DE AHORRO VS META */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg text-gray-100 flex items-center">
            <Target className="w-5 h-5 mr-2 text-green-400" />
            Proyección de Ahorro vs Meta 2025
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {mostrarGraficas && (
            <>
              {/* Progreso actual */}
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-300">Progreso actual</span>
                  <span className="text-gray-300">{progresoAhorro.toFixed(1)}%</span>
                </div>
                <Progress value={progresoAhorro} className="h-3" />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-gray-400 text-xs">Ahorrado actual</p>
                  <p className="text-white font-medium">{formatCurrency(ahorroActual)}</p>
                </div>
                <div className="text-right">
                  <p className="text-gray-400 text-xs">Meta objetivo</p>
                  <p className="text-white font-medium">{formatCurrency(metaAhorro)}</p>
                </div>
              </div>

              {/* Proyección con IA */}
              <div className="bg-blue-900/20 rounded-lg p-3 border border-blue-800/30">
                <div className="flex justify-between items-center mb-2">
                  <div className="flex items-center">
                    <Brain className="w-4 h-4 text-blue-400 mr-2" />
                    <p className="text-blue-400 text-sm font-medium">Proyección IA a fin de año</p>
                  </div>
                  <p className="text-white font-medium">{formatCurrency(ahorroProyectadoTotal)}</p>
                </div>
                <p className="text-gray-300 text-xs">
                  Con ahorro mensual promedio de {formatCurrency(ahorroProyectado)} (predicho por modelo)
                </p>
              </div>
            </>
          )}

          {/* 🚨 ALERTA SI NO SE VA A LOGRAR LA META */}
          {noAlcanzaraMeta ? (
            <div className="bg-red-900/20 border border-red-800/30 rounded-lg p-3">
              <div className="flex items-center mb-2">
                <AlertCircle className="w-4 h-4 text-red-400 mr-2" />
                <span className="text-red-400 text-sm font-medium">⚠️ No alcanzarás tu meta</span>
              </div>
              <p className="text-gray-300 text-sm mb-2">
                Te faltarán {formatCurrency(deficitAhorro)} para cumplir tu objetivo
              </p>
              <p className="text-red-400 text-xs">
                Necesitas ahorrar {formatCurrency(Math.ceil(deficitAhorro / mesesRestantes))} adicionales por mes
              </p>
            </div>
          ) : (
            <div className="bg-green-900/20 border border-green-800/30 rounded-lg p-3">
              <div className="flex items-center">
                <CheckCircle className="w-4 h-4 text-green-400 mr-2" />
                <span className="text-green-400 text-sm">✅ Vas por buen camino para alcanzar tu meta</span>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* 📊 CONTROL DE GASTO SEMANAL */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg text-gray-100 flex items-center">
            <TrendingDown className="w-5 h-5 mr-2 text-orange-400" />
            Control de Gasto Semanal (Predicción IA)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {mostrarGraficas && (
            <>
              {/* Progreso de gasto */}
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-300">Gasto proyectado esta semana</span>
                  <span className="text-gray-300">{formatCurrency(gastoProyectadoSemanal)}</span>
                </div>
                <Progress value={Math.min((gastoProyectadoSemanal / limiteSemanal) * 100, 100)} className="h-3" />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-gray-400 text-xs">Límite semanal</p>
                  <p className="text-white font-medium">{formatCurrency(limiteSemanal)}</p>
                </div>
                <div className="text-right">
                  <p className="text-gray-400 text-xs">{excedeLimiteSemanal ? "Excedente" : "Disponible"}</p>
                  <p className={`font-medium ${excedeLimiteSemanal ? "text-red-400" : "text-green-400"}`}>
                    {excedeLimiteSemanal ? "+" : ""}
                    {formatCurrency(Math.abs(excesoSemanal))}
                  </p>
                </div>
              </div>
            </>
          )}

          {/* 🚨 ALERTA SI SE EXCEDE EL LÍMITE SEMANAL */}
          {excedeLimiteSemanal ? (
            <div className="bg-red-900/20 border border-red-800/30 rounded-lg p-3">
              <div className="flex items-center mb-2">
                <AlertTriangle className="w-4 h-4 text-red-400 mr-2" />
                <span className="text-red-400 text-sm font-medium">🚨 Vas a exceder tu límite semanal</span>
              </div>
              <p className="text-gray-300 text-sm mb-1">
                Exceso del {((excesoSemanal / limiteSemanal) * 100).toFixed(1)}% sobre tu límite establecido
              </p>
              <p className="text-red-400 text-xs">
                El modelo predice {formatCurrency(excesoSemanal)} de exceso - reduce gastos no esenciales
              </p>
            </div>
          ) : (
            <div className="bg-green-900/20 border border-green-800/30 rounded-lg p-3">
              <div className="flex items-center">
                <CheckCircle className="w-4 h-4 text-green-400 mr-2" />
                <span className="text-green-400 text-sm">✅ Te mantienes dentro de tu presupuesto semanal</span>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* 📈 CONTROL DE GASTO MENSUAL */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg text-gray-100 flex items-center">
            <Calendar className="w-5 h-5 mr-2 text-purple-400" />
            Proyección Mensual
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {mostrarGraficas && (
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-blue-900/20 rounded-lg p-3">
                <p className="text-blue-400 text-xs">Ingresos estimados</p>
                <p className="text-white font-medium">{formatCurrency(18500)}</p>
              </div>
              <div className="bg-orange-900/20 rounded-lg p-3">
                <p className="text-orange-400 text-xs">Gastos proyectados (IA)</p>
                <p className="text-white font-medium">{formatCurrency(gastoProyectadoMensual)}</p>
              </div>
            </div>
          )}

          {excedeLimiteMensual ? (
            <div className="bg-red-900/20 border border-red-800/30 rounded-lg p-3">
              <div className="flex items-center mb-2">
                <AlertTriangle className="w-4 h-4 text-red-400 mr-2" />
                <span className="text-red-400 text-sm font-medium">🚨 Excederás tu límite mensual</span>
              </div>
              <p className="text-gray-300 text-sm">Exceso proyectado: {formatCurrency(excesoMensual)}</p>
            </div>
          ) : (
            <div className="bg-green-900/20 rounded-lg p-3">
              <p className="text-green-400 text-xs">Ahorro proyectado este mes</p>
              <p className="text-white font-medium">{formatCurrency(ahorroProyectado)}</p>
              <Badge variant="outline" className="mt-2 bg-green-900/20 text-green-400 border-green-600">
                {ahorroProyectado > 4000 ? "+12% vs mes anterior" : "Mantener constancia"}
              </Badge>
            </div>
          )}
        </CardContent>
      </Card>

      {/* 🎯 ACCIONES RECOMENDADAS AUTOMÁTICAS */}
      <div className="space-y-3">
        <h2 className="text-lg font-medium text-gray-100">Acciones Recomendadas por IA</h2>

        <div className="grid grid-cols-1 gap-3">
          {noAlcanzaraMeta && (
            <Button variant="outline" className="border-red-600 text-red-400 hover:bg-red-900/20 justify-start">
              <Target className="w-4 h-4 mr-2" />
              <div className="text-left">
                <p className="font-medium">Ajustar Meta de Ahorro</p>
                <p className="text-xs text-gray-400">
                  Aumenta ahorro mensual en {formatCurrency(Math.ceil(deficitAhorro / mesesRestantes))}
                </p>
              </div>
            </Button>
          )}

          {excedeLimiteSemanal && (
            <Button
              variant="outline"
              className="border-orange-600 text-orange-400 hover:bg-orange-900/20 justify-start"
            >
              <TrendingDown className="w-4 h-4 mr-2" />
              <div className="text-left">
                <p className="font-medium">Reducir Gastos Semanales</p>
                <p className="text-xs text-gray-400">Objetivo: {formatCurrency(limiteSemanal)} por semana</p>
              </div>
            </Button>
          )}

          <Button variant="outline" className="border-blue-600 text-blue-400 hover:bg-blue-900/20 justify-start">
            <Calendar className="w-4 h-4 mr-2" />
            <div className="text-left">
              <p className="font-medium">Programar Ahorro Automático</p>
              <p className="text-xs text-gray-400">Basado en predicciones del modelo</p>
            </div>
          </Button>

          <Button variant="outline" className="border-green-600 text-green-400 hover:bg-green-900/20 justify-start">
            <DollarSign className="w-4 h-4 mr-2" />
            <div className="text-left">
              <p className="font-medium">Optimizar Presupuesto</p>
              <p className="text-xs text-gray-400">Ajustar categorías según predicciones</p>
            </div>
          </Button>
        </div>
      </div>
    </div>
  )
}
