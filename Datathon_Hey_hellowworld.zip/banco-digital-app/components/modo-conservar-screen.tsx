"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Shield, Calendar, AlertTriangle, CheckCircle, Clock, X } from "lucide-react"
import { BankingActions } from "@/lib/bankingActions"
import type { Usuario } from "@/lib/bankingService"

interface ModoConservarScreenProps {
  usuario: Usuario
  onDesactivar: () => void
}

export function ModoConservarScreen({ usuario, onDesactivar }: ModoConservarScreenProps) {
  const [presupuestoDiario, setPresupuestoDiario] = useState(180)
  const [isLoading, setIsLoading] = useState<string | null>(null)
  const [mensaje, setMensaje] = useState<{ tipo: "success" | "error"; texto: string } | null>(null)

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("es-MX", {
      style: "currency",
      currency: "MXN",
    }).format(amount)
  }

  const mostrarMensaje = (tipo: "success" | "error", texto: string) => {
    setMensaje({ tipo, texto })
    setTimeout(() => setMensaje(null), 4000)
  }

  // ✅ REQUERIMIENTO 4.1: ACTIVACIÓN AUTOMÁTICA SI SALDO BAJO Y PAGOS IMPORTANTES
  const saldoBajo = usuario.saldo < 15000
  const hayPagosImportantes = true // Simulado - en realidad se calcularía del historial

  // ✅ REQUERIMIENTO 4.3: MONTO SUGERIDO POR DÍA
  useEffect(() => {
    const calcularPresupuestoDiario = async () => {
      // Cálculo basado en gastos esenciales y saldo disponible
      const gastosEsenciales = 5000 // Simulado: renta + servicios + alimentación básica
      const saldoDisponible = usuario.saldo - gastosEsenciales
      const diasDelMes = 30
      const presupuestoCalculado = Math.max(150, Math.round(saldoDisponible / diasDelMes))
      setPresupuestoDiario(presupuestoCalculado)
    }

    calcularPresupuestoDiario()
  }, [usuario.saldo])

  // ✅ REQUERIMIENTO 4.4: PAGOS RECURRENTES PRÓXIMOS
  const pagosRecurrentes = [
    {
      id: 1,
      nombre: "Renta",
      monto: 8500,
      diasVencimiento: 3,
      tipo: "critico" as const,
      esEsencial: true,
    },
    {
      id: 2,
      nombre: "Tarjeta de Crédito",
      monto: 2300,
      diasVencimiento: 8,
      tipo: "importante" as const,
      esEsencial: true,
    },
    {
      id: 3,
      nombre: "Servicios (Luz/Gas/Internet)",
      monto: 1200,
      diasVencimiento: 15,
      tipo: "normal" as const,
      esEsencial: true,
    },
    {
      id: 4,
      nombre: "Seguro de Auto",
      monto: 800,
      diasVencimiento: 20,
      tipo: "normal" as const,
      esEsencial: false,
    },
  ]

  const handleDesactivar = async () => {
    setIsLoading("desactivar")
    try {
      const resultado = await BankingActions.desactivarModoConservar(usuario)
      if (resultado.success) {
        mostrarMensaje("success", resultado.message)
        setTimeout(() => onDesactivar(), 1000)
      }
    } catch (error) {
      console.error("Error al desactivar:", error)
      mostrarMensaje("error", "Error al desactivar modo conservar")
    } finally {
      setIsLoading(null)
    }
  }

  const handleVerMicrocreditos = async () => {
    setIsLoading("microcredito")
    try {
      const resultado = await BankingActions.verMicrocreditos(usuario)
      mostrarMensaje("success", `${resultado.disponibles.length} microcréditos disponibles`)
    } catch (error) {
      mostrarMensaje("error", "Error al cargar microcréditos")
    } finally {
      setIsLoading(null)
    }
  }

  const totalPagosEsenciales = pagosRecurrentes.filter((p) => p.esEsencial).reduce((sum, p) => sum + p.monto, 0)

  const saldoPostPagos = usuario.saldo - totalPagosEsenciales

  const getColorClasses = (tipo: string) => {
    const colorClasses = {
      critico: "bg-red-900/20 border-red-800/30 text-red-400",
      importante: "bg-orange-900/20 border-orange-800/30 text-orange-400",
      normal: "bg-blue-900/20 border-blue-800/30 text-blue-400",
    }
    return colorClasses[tipo as keyof typeof colorClasses] || colorClasses.normal
  }

  const getUrgencia = (dias: number) => {
    if (dias <= 3) return "URGENTE"
    if (dias <= 7) return "PRÓXIMO"
    return "PROGRAMADO"
  }

  const getTextoVencimiento = (dias: number) => {
    if (dias === 1) return "Vence mañana"
    if (dias === 0) return "Vence hoy"
    if (dias < 0) return `Venció hace ${Math.abs(dias)} días`
    return `Vence en ${dias} días`
  }

  return (
    <div className="p-4 pb-20 space-y-6">
      {/* Mensaje de notificación */}
      {mensaje && (
        <div
          className={`fixed top-24 left-1/2 transform -translate-x-1/2 z-50 p-4 rounded-lg border max-w-sm w-full mx-4 ${
            mensaje.tipo === "success"
              ? "bg-green-900/90 border-green-600 text-green-100"
              : "bg-red-900/90 border-red-600 text-red-100"
          }`}
        >
          <div className="flex items-center justify-between">
            <p className="text-sm">{mensaje.texto}</p>
            <Button variant="ghost" size="sm" onClick={() => setMensaje(null)} className="text-current p-1 h-auto">
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}

      {/* ✅ REQUERIMIENTO 4.2: UI ULTRA MINIMALISTA (SIN BANNERS) */}

      {/* Header Minimalista - SIN banners promocionales */}
      <div className="pt-8">
        <div className="flex items-center space-x-2 mb-2">
          <Shield className="w-6 h-6 text-amber-400" />
          <h1 className="text-2xl font-light text-gray-100">Modo Conservar</h1>
        </div>
        <div className="flex items-center space-x-2">
          <Badge variant="outline" className="bg-amber-900/20 text-amber-400 border-amber-600">
            {saldoBajo && hayPagosImportantes ? "Activado automáticamente" : "Activado manualmente"}
          </Badge>
        </div>
      </div>

      {/* Razón de Activación Automática */}
      {saldoBajo && hayPagosImportantes && (
        <Card className="bg-gradient-to-r from-red-900/30 to-orange-900/30 border-red-800/50">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <AlertTriangle className="w-6 h-6 text-red-400" />
              <div>
                <p className="text-red-400 font-medium">Activación Automática</p>
                <p className="text-gray-300 text-sm">
                  Saldo bajo ({formatCurrency(usuario.saldo)}) + Pagos importantes próximos
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* ✅ REQUERIMIENTO 4.3: MONTO SUGERIDO POR DÍA */}
      <Card className="bg-gradient-to-br from-amber-900/30 to-orange-900/30 border-amber-800/30">
        <CardContent className="p-6 text-center">
          <div className="space-y-2">
            <p className="text-amber-300 text-sm">Presupuesto sugerido diario</p>
            <p className="text-4xl font-light text-white">{formatCurrency(presupuestoDiario)}</p>
            <p className="text-gray-400 text-xs">Calculado para mantener liquidez hasta fin de mes</p>
          </div>

          {/* Indicador de uso diario */}
          <div className="mt-4 bg-amber-900/20 rounded-lg p-3">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-amber-300">Gastado hoy:</span>
              <span className="text-white">{formatCurrency(85)}</span>
            </div>
            <div className="w-full bg-amber-900/30 rounded-full h-2">
              <div className="bg-green-500 h-2 rounded-full" style={{ width: "47%" }}></div>
            </div>
            <p className="text-xs text-gray-400 mt-1">Te quedan {formatCurrency(presupuestoDiario - 85)} para hoy</p>
          </div>
        </CardContent>
      </Card>

      {/* ✅ REQUERIMIENTO 4.4: PAGOS RECURRENTES PRÓXIMOS */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg text-gray-100 flex items-center">
            <Calendar className="w-5 h-5 mr-2 text-blue-400" />
            Pagos Recurrentes Próximos
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {pagosRecurrentes.map((pago) => {
            const urgencia = getUrgencia(pago.diasVencimiento)
            const textoVencimiento = getTextoVencimiento(pago.diasVencimiento)

            return (
              <div
                key={pago.id}
                className={`flex justify-between items-center p-3 rounded-lg border ${getColorClasses(pago.tipo)}`}
              >
                <div className="flex-1">
                  <div className="flex items-center space-x-2">
                    <p className="text-white font-medium">{pago.nombre}</p>
                    {pago.esEsencial && (
                      <Badge variant="outline" className="bg-red-900/20 text-red-400 border-red-600 text-xs">
                        Esencial
                      </Badge>
                    )}
                  </div>
                  <p className="text-gray-400 text-sm">
                    {urgencia} - {textoVencimiento}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-white font-medium">{formatCurrency(pago.monto)}</p>
                  <div className="flex items-center mt-1">
                    {pago.diasVencimiento <= 3 ? (
                      <Clock className="w-3 h-3 text-red-400 mr-1" />
                    ) : (
                      <CheckCircle className="w-3 h-3 text-green-400 mr-1" />
                    )}
                    <span className={`text-xs ${pago.diasVencimiento <= 3 ? "text-red-400" : "text-green-400"}`}>
                      {pago.diasVencimiento <= 3 ? "Urgente" : "A tiempo"}
                    </span>
                  </div>
                </div>
              </div>
            )
          })}

          {/* Resumen de pagos */}
          <div className="mt-4 pt-4 border-t border-gray-700">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-gray-400 text-sm">Total pagos esenciales</p>
                <p className="text-white font-medium">{formatCurrency(totalPagosEsenciales)}</p>
              </div>
              <div className="text-right">
                <p className="text-gray-400 text-sm">Saldo después de pagos</p>
                <p className={`font-medium ${saldoPostPagos > 0 ? "text-green-400" : "text-red-400"}`}>
                  {formatCurrency(saldoPostPagos)}
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Opciones disponibles en Modo Conservar */}
      <div className="space-y-3">
        <h2 className="text-lg font-medium text-gray-100">Opciones disponibles</h2>

        <Card className="bg-amber-900/20 border-amber-800/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-amber-400 font-medium">Microcrédito Express</p>
                <p className="text-gray-400 text-sm">Hasta $5,000 disponibles</p>
                <p className="text-gray-500 text-xs">Aprobación inmediata</p>
              </div>
              <Button
                size="sm"
                onClick={handleVerMicrocreditos}
                disabled={isLoading === "microcredito"}
                className="bg-amber-600 hover:bg-amber-700"
              >
                {isLoading === "microcredito" ? (
                  <div className="flex items-center">
                    <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2"></div>
                    Cargando...
                  </div>
                ) : (
                  "Ver opciones"
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-blue-900/20 border-blue-800/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-400 font-medium">Ahorro de Emergencia</p>
                <p className="text-gray-400 text-sm">Comienza con $100</p>
                <p className="text-gray-500 text-xs">Rendimiento 8.5% anual</p>
              </div>
              <Button size="sm" variant="outline" className="border-blue-600 text-blue-400">
                Activar
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-green-900/20 border-green-800/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-400 font-medium">Consejos de Ahorro</p>
                <p className="text-gray-400 text-sm">Tips personalizados para tu situación</p>
                <p className="text-gray-500 text-xs">Basado en IA</p>
              </div>
              <Button size="sm" variant="outline" className="border-green-600 text-green-400">
                Ver consejos
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Acción para desactivar */}
      <div className="pt-4">
        <Button
          onClick={handleDesactivar}
          disabled={isLoading === "desactivar"}
          variant="outline"
          className="w-full border-amber-600 text-amber-400 hover:bg-amber-900/20"
        >
          {isLoading === "desactivar" ? (
            <div className="flex items-center">
              <div className="animate-spin w-4 h-4 border-2 border-amber-400 border-t-transparent rounded-full mr-2"></div>
              Desactivando...
            </div>
          ) : (
            "Desactivar Modo Conservar"
          )}
        </Button>
      </div>

      {/* Información adicional */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardContent className="p-4">
          <h3 className="text-white font-medium mb-3">¿Qué es el Modo Conservar?</h3>
          <div className="space-y-2 text-sm text-gray-300">
            <p>• Limita el acceso a productos de crédito y préstamos</p>
            <p>• Sugiere un presupuesto diario basado en tu situación</p>
            <p>• Prioriza pagos esenciales y próximos vencimientos</p>
            <p>• Ofrece alternativas como microcréditos de emergencia</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
