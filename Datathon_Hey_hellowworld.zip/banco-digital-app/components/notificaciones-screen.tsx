import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Bell, AlertTriangle, TrendingUp, Gift, CreditCard, Calendar, CheckCircle, X } from "lucide-react"
import { BankingActions } from "@/lib/bankingActions"
import { bankingService, type Usuario, type Notificacion } from "@/lib/bankingService"

interface NotificacionesScreenProps {
  usuario: Usuario
}

export function NotificacionesScreen({ usuario }: NotificacionesScreenProps) {
  const [notificaciones, setNotificaciones] = useState<Notificacion[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [procesando, setProcesando] = useState<string | null>(null)
  const [configuracion, setConfiguracion] = useState({
    alertasSaldo: true,
    recordatoriosPagos: true,
    promociones: false
  })
  const [mensaje, setMensaje] = useState<{ tipo: 'success' | 'error'; texto: string } | null>(null)

  useEffect(() => {
    cargarNotificaciones()
  }, [])

  const cargarNotificaciones = async () => {
    setIsLoading(true)
    try {
      const data = await bankingService.getNotificaciones(usuario.id)
      setNotificaciones(data)
    } catch (error) {
      console.error('Error cargando notificaciones:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const mostrarMensaje = (tipo: 'success' | 'error', texto: string) => {
    setMensaje({ tipo, texto })
    setTimeout(() => setMensaje(null), 3000)
  }

  const handleAccionNotificacion = async (notifId: string, accion: string) => {
    setProcesando(notifId)
    try {
      // Simular acciones específicas
      await new Promise(resolve => setTimeout(resolve, 1000))

      switch (accion) {
        case 'view_activity':
          mostrarMensaje('success', 'Actividad de seguridad revisada')
          break
        case 'report_suspicious':
          mostrarMensaje('success', 'Actividad reportada. Nuestro equipo la revisará.')
          break
        case 'adjust_limit':
          mostrarMensaje('success', 'Límite de gasto ajustado exitosamente')
          break
        case 'solicitar_tarjeta':
          const resultado = await BankingActions.solicitarTarjetaCredito(usuario)
          mostrarMensaje(resultado.success ? 'success' : 'error', resultado.message)
          break
        case 'invertir':
          mostrarMensaje('success', 'Te llevamos a la sección de inversiones')
          break
        default:
          mostrarMensaje('success', 'Acción ejecutada')
      }

      // Marcar como leída
      await bankingService.marcarNotificacionLeida(usuario.id, notifId)
      await cargarNotificaciones()
    } catch (error) {
      mostrarMensaje('error', 'Error al procesar acción')
    } finally {
      setProcesando(null)
    }
  }

  const handleMarcarComoLeida = async (notifId: string) => {
    try {
      await bankingService.marcarNotificacionLeida(usuario.id, notifId)
      await cargarNotificaciones()
    } catch (error) {
      mostrarMensaje('error', 'Error al marcar notificación')
    }
  }

  const handleMarcarTodasLeidas = async () => {
    setProcesando('todas')
    try {
      const resultado = await BankingActions.marcarTodasComoLeidas(usuario)
      if (resultado.success) {
        await cargarNotificaciones()
        mostrarMensaje('success', 'Todas las notificaciones marcadas como leídas')
      }
    } catch (error) {
      mostrarMensaje('error', 'Error al marcar todas como leídas')
    } finally {
      setProcesando(null)
    }
  }

  const handleConfiguracionChange = async (campo: keyof typeof configuracion) => {
    const nuevaConfig = { ...configuracion, [campo]: !configuracion[campo] }
    setConfiguracion(nuevaConfig)

    try {
      const resultado = await BankingActions.configurarNotificaciones(nuevaConfig)
      if (resultado.success) {
        mostrarMensaje('success', resultado.message)
      }
    } catch (error) {
      mostrarMensaje('error', 'Error al actualizar configuración')
      // Revertir cambio en caso de error
      setConfiguracion(configuracion)
    }
  }

  const formatFecha = (fechaStr: string) => {
    const fecha = new Date(fechaStr)
    const ahora = new Date()
    const diffTiempo = ahora.getTime() - fecha.getTime()
    const diffDias = Math.floor(diffTiempo / (1000 * 3600 * 24))
    const diffHoras = Math.floor(diffTiempo / (1000 * 3600))
    const diffMinutos = Math.floor(diffTiempo / (1000 * 60))

    if (diffDias > 0) {
      return `Hace ${diffDias} día${diffDias > 1 ? 's' : ''}`
    } else if (diffHoras > 0) {
      return `Hace ${diffHoras} hora${diffHoras > 1 ? 's' : ''}`
    } else if (diffMinutos > 0) {
      return `Hace ${diffMinutos} minuto${diffMinutos > 1 ? 's' : ''}`
    } else {
      return 'Ahora'
    }
  }

  const getIcono = (tipo: string) => {
    switch (tipo) {
      case 'seguridad':
        return <AlertTriangle className="w-5 h-5 text-amber-400" />
      case 'promocion':
        return <Gift className="w-5 h-5 text-purple-400" />
      case 'limite':
        return <CreditCard className="w-5 h-5 text-blue-400" />
      case 'pago':
        return <Calendar className="w-5 h-5 text-red-400" />
      case 'achievement':
        return <TrendingUp className="w-5 h-5 text-green-400" />
      default:
        return <Bell className="w-5 h-5 text-gray-400" />
    }
  }

  const getColorFondo = (tipo: string, prioridad: string) => {
    if (prioridad === 'critica') return 'bg-red-900/20 border-red-800/30'
    
    switch (tipo) {
      case 'seguridad':
        return 'bg-amber-900/20 border-amber-800/30'
      case 'promocion':
        return 'bg-purple-900/20 border-purple-800/30'
      case 'limite':
        return 'bg-blue-900/20 border-blue-800/30'
      case 'pago':
        return 'bg-red-900/20 border-red-800/30'
      case 'achievement':
        return 'bg-green-900/20 border-green-800/30'
      default:
        return 'bg-gray-800/50 border-gray-700'
    }
  }

  const notificacionesNoLeidas = notificaciones.filter(n => !n.leida).length

  return (
    <div className="p-4 pb-20 space-y-6">
      {/* Mensaje de notificación */}
      {mensaje && (
        <div className={`fixed top-24 left-1/2 transform -translate-x-1/2 z-50 p-4 rounded-lg border max-w-sm w-full mx-4 ${
          mensaje.tipo === 'success' 
            ? 'bg-green-900/90 border-green-600 text-green-100' 
            : 'bg-red-900/90 border-red-600 text-red-100'
        }`}>
          <div className="flex items-center justify-between">
            <p className="text-sm">{mensaje.texto}</p>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setMensaje(null)}
              className="text-current p-1 h-auto"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="pt-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-light text-gray-100">Notificaciones</h1>
            <p className="text-gray-400 text-sm">Mantente al día con tu cuenta</p>
          </div>
          {notificacionesNoLeidas > 0 && (
            <Badge variant="outline" className="bg-red-900/20 text-red-400 border-red-600">
              {notificacionesNoLeidas} nuevas
            </Badge>
          )}
        </div>
      </div>

      {/* Lista de Notificaciones */}
      {isLoading ? (
        <div className="flex justify-center py-8">
          <div className="animate-spin w-8 h-8 border-2 border-blue-400 border-t-transparent rounded-full"></div>
        </div>
      ) : (
        <div className="space-y-3">
          {notificaciones.map((notificacion) => (
            <Card 
              key={notificacion.id} 
              className={`${getColorFondo(notificacion.tipo, notificacion.prioridad)} ${
                !notificacion.leida ? 'ring-2 ring-blue-500/20' : ''
              }`}
            >
              <CardContent className="p-4">
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0 mt-1">
                    {getIcono(notificacion.tipo)}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <h3 className="text-white font-medium text-sm">
                        {notificacion.titulo}
                      </h3>
                      <div className="flex items-center space-x-2">
                        {!notificacion.leida && (
                          <div className="w-2 h-2 bg-blue-400 rounded-full flex-shrink-0"></div>
                        )}
                        {notificacion.leida && (
                          <CheckCircle className="w-4 h-4 text-green-400" />
                        )}
                      </div>
                    </div>
                    
                    <p className="text-gray-300 text-sm mb-2">
                      {notificacion.mensaje}
                    </p>
                    
                    <div className="flex items-center justify-between">
                      <p className="text-gray-500 text-xs">
                        {formatFecha(notificacion.fecha)}
                      </p>
                      
                      <div className="flex space-x-2">
                        {!notificacion.leida && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleMarcarComoLeida(notificacion.id)}
                            className="text-gray-400 hover:text-white p-1 h-auto"
                          >
                            Marcar leída
                          </Button>
                        )}
                      </div>
                    </div>

                    {/* Acciones de la notificación */}
                    {notificacion.acciones && notificacion.acciones.length > 0 && (
                      <div className="flex space-x-2 mt-3">
                        {notificacion.acciones.map((accion, index) => (
                          <Button
                            key={index}
                            size="sm"
                            variant="outline"
                            onClick={() => handleAccionNotificacion(notificacion.id, accion.accion)}
                            disabled={procesando === notificacion.id}
                            className={`text-xs ${
                              accion.tipo === 'primary' ? 'border-blue-600 text-blue-400' :
                              accion.tipo === 'danger' ? 'border-red-600 text-red-400' :
                              'border-gray-600 text-gray-300'
                            }`}
                          >
                            {procesando === notificacion.id ? (
                              <div className="flex items-center">
                                <div className="animate-spin w-3 h-3 border border-current border-t-transparent rounded-full mr-1"></div>
                                Procesando...
                              </div>
                            ) : (
                              accion.texto
                            )}
                          </Button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}

          {notificaciones.length === 0 && (
            <Card className="bg-gray-800/50 border-gray-700">
              <CardContent className="p-8 text-center">
                <Bell className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-white font-medium mb-2">No tienes notificaciones</h3>
                <p className="text-gray-400 text-sm">
                  Te notificaremos sobre actividades importantes en tu cuenta
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* Configuración de Notificaciones */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardContent className="p-4">
          <h3 className="text-white font-medium mb-3">Configuración</h3>
          
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white text-sm">Alertas de saldo bajo</p>
                <p className="text-gray-400 text-xs">Recibe avisos cuando tu saldo sea crítico</p>
              </div>
              <button
                onClick={() => handleConfiguracionChange('alertasSaldo')}
                className={`w-10 h-6 rounded-full relative transition-colors ${
                  configuracion.alertasSaldo ? 'bg-blue-600' : 'bg-gray-600'
                }`}
              >
                <div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-transform ${
                  configuracion.alertasSaldo ? 'translate-x-5' : 'translate-x-1'
                }`} />
              </button>
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white text-sm">Recordatorios de pagos</p>
                <p className="text-gray-400 text-xs">Avisos 3 días antes de vencimientos</p>
              </div>
              <button
                onClick={() => handleConfiguracionChange('recordatoriosPagos')}
                className={`w-10 h-6 rounded-full relative transition-colors ${
                  configuracion.recordatoriosPagos ? 'bg-blue-600' : 'bg-gray-600'
                }`}
              >
                <div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-transform ${
                  configuracion.recordatoriosPagos ? 'translate-x-5' : 'translate-x-1'
                }`} />
              </button>
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white text-sm">Promociones y ofertas</p>
                <p className="text-gray-400 text-xs">Recibe ofertas personalizadas</p>
              </div>
              <button
                onClick={() => handleConfiguracionChange('promociones')}
                className={`w-10 h-6 rounded-full relative transition-colors ${
                  configuracion.promociones ? 'bg-blue-600' : 'bg-gray-600'
                }`}
              >
                <div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-transform ${
                  configuracion.promociones ? 'translate-x-5' : 'translate-x-1'
                }`} />
              </button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Acción para marcar todas como leídas */}
      {notificacionesNoLeidas > 0 && (
        <Button 
          onClick={handleMarcarTodasLeidas}
          disabled={procesando === 'todas'}
          variant="outline" 
          className="w-full border-gray-600 text-gray-300"
        >
          {procesando === 'todas' ? (
            <div className="flex items-center">
              <div className="animate-spin w-4 h-4 border-2 border-gray-300 border-t-transparent rounded-full mr-2"></div>
              Marcando todas...
            </div>
          ) : (
            'Marcar todas como leídas'
          )}
        </Button>
      )}
    </div>
  )
}
