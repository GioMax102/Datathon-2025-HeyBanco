"use client"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { TrendingUp, AlertTriangle, Brain, Calendar, CheckCircle, Target } from "lucide-react"
import { useDatathonPredictions } from "@/hooks/useDatathonPredictions"
import type { Usuario } from "@/lib/bankingService"

interface DatathonBalanceScreenProps {
  usuario: Usuario
  modoConservar: boolean
  onActivarModoConservar: () => void
}

export function DatathonBalanceScreen({ usuario, modoConservar, onActivarModoConservar }: DatathonBalanceScreenProps) {
  const { predictions, analysis, isLoading, error } = useDatathonPredictions(usuario.datathonUserId || usuario.id)

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("es-MX", {
      style: "currency",
      currency: "MXN",
    }).format(amount)
  }

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString("es-MX", {
      day: "2-digit",
      month: "short",
    })
  }

  if (isLoading) {
    return (
      <div className="p-4 pb-20 flex justify-center items-center min-h-[60vh]">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-2 border-blue-400 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-400">Consultando modelo de datathon...</p>
          <p className="text-gray-500 text-xs mt-2">Analizando patrones de gasto con IA</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="p-4 pb-20">
        <div className="text-center py-8">
          <AlertTriangle className="w-16 h-16 text-red-400 mx-auto mb-4" />
          <h3 className="text-white font-medium mb-2">Error en modelo de predicción</h3>
          <p className="text-gray-400 text-sm mb-4">{error}</p>
          <Button onClick={() => window.location.reload()} className="bg-blue-600 hover:bg-blue-700">
            Reintentar
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="p-4 pb-20 space-y-6">
      {/* Header */}
      <div className="pt-8">
        <h1 className="text-2xl font-light text-gray-100">Balance Inteligente</h1>
        <div className="flex items-center space-x-2 mt-1">
          <Brain className="w-4 h-4 text-purple-400" />
          <p className="text-gray-400 text-sm">Predicciones con modelo de datathon</p>
        </div>
      </div>

      {/* 🔑 SMART BALANCE ANALYSIS */}
      <Card className="bg-gradient-to-br from-blue-900/40 to-purple-900/40 border-blue-800/30">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg text-gray-100 flex items-center">
            <TrendingUp className="w-5 h-5 mr-2 text-blue-400" />
            Análisis Inteligente de Balance
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-gray-400 text-xs">Saldo actual</p>
              <p className="text-white font-medium text-lg">{formatCurrency(usuario.saldo)}</p>
            </div>
            <div>
              <p className="text-gray-400 text-xs">Balance proyectado</p>
              <p
                className={`font-medium text-lg ${
                  analysis?.projectedBalance > usuario.saldo
                    ? "text-green-400"
                    : analysis?.isBalanceLow
                      ? "text-red-400"
                      : "text-orange-400"
                }`}
              >
                {formatCurrency(analysis?.projectedBalance || 0)}
              </p>
            </div>
          </div>

          <div className="bg-purple-900/20 rounded-lg p-3">
            <div className="flex items-center mb-2">
              <Brain className="w-4 h-4 text-purple-400 mr-2" />
              <span className="text-purple-400 text-sm font-medium">Predicción del Modelo</span>
            </div>
            <p className="text-purple-400 text-sm">
              {predictions.length} transacciones predichas para los próximos 30 días
            </p>
          </div>
        </CardContent>
      </Card>

      {/* FINANCIAL ALERTS */}
      {(analysis?.savingsAlert || analysis?.spendingAlert) && (
        <div className="space-y-3">
          {analysis.savingsAlert && (
            <Card className="bg-red-900/20 border-red-800/30">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <Target className="w-6 h-6 text-red-400" />
                  <div>
                    <p className="text-red-400 font-medium">Meta de Ahorro en Riesgo</p>
                    <p className="text-gray-300 text-sm">{analysis.savingsAlert}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {analysis.spendingAlert && (
            <Card className="bg-orange-900/20 border-orange-800/30">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <AlertTriangle className="w-6 h-6 text-orange-400" />
                  <div>
                    <p className="text-orange-400 font-medium">Presupuesto Semanal Excedido</p>
                    <p className="text-gray-300 text-sm">{analysis.spendingAlert}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* BALANCE-BASED RECOMMENDATIONS */}
      {analysis?.isBalanceLow && (
        <div className="space-y-3">
          <div className="flex items-center space-x-2">
            <AlertTriangle className="w-5 h-5 text-red-400" />
            <h2 className="text-lg font-medium text-red-400">Balance Bajo - Acciones Recomendadas</h2>
          </div>

          <Card className="bg-amber-900/20 border-amber-800/30">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-amber-400 font-medium">💳 Microcréditos Disponibles</p>
                  <p className="text-gray-400 text-sm">Liquidez inmediata para emergencias</p>
                </div>
                <Button size="sm" className="bg-amber-600 hover:bg-amber-700">
                  Ver Opciones
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-green-900/20 border-green-800/30">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-400 font-medium">💰 Ahorro de Emergencia</p>
                  <p className="text-gray-400 text-sm">Comienza con montos pequeños</p>
                </div>
                <Button size="sm" variant="outline" className="border-green-600 text-green-400">
                  Activar
                </Button>
              </div>
            </CardContent>
          </Card>

          {!modoConservar && analysis.shouldActivateConservationMode && (
            <Card className="bg-purple-900/20 border-purple-800/30">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-purple-400 font-medium">🛡️ Modo Conservar</p>
                    <p className="text-gray-400 text-sm">Activa protecciones automáticas</p>
                  </div>
                  <Button size="sm" onClick={onActivarModoConservar} className="bg-purple-600 hover:bg-purple-700">
                    Activar
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {analysis?.isBalanceHigh && (
        <div className="space-y-3">
          <div className="flex items-center space-x-2">
            <TrendingUp className="w-5 h-5 text-green-400" />
            <h2 className="text-lg font-medium text-green-400">Balance Alto - Oportunidades</h2>
          </div>

          <Card className="bg-emerald-900/20 border-emerald-800/30">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-emerald-400 font-medium">💡 Promociones Exclusivas</p>
                  <p className="text-gray-400 text-sm">Aprovecha descuentos en tiendas afiliadas</p>
                </div>
                <Button size="sm" variant="outline" className="border-emerald-600 text-emerald-400">
                  Ver Ofertas
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-blue-900/20 border-blue-800/30">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-400 font-medium">📈 Inversiones Inteligentes</p>
                  <p className="text-gray-400 text-sm">Diversifica con rendimiento del 12% anual</p>
                </div>
                <Button size="sm" variant="outline" className="border-blue-600 text-blue-400">
                  Invertir
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* PREDICTED TRANSACTIONS */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg text-gray-100 flex items-center">
            <Calendar className="w-5 h-5 mr-2 text-green-400" />
            Transacciones Predichas (Próximos 15 días)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {predictions.slice(0, 5).map((prediccion, index) => (
            <div
              key={index}
              className="flex justify-between items-center p-3 bg-blue-900/10 rounded-lg border border-blue-800/20"
            >
              <div>
                <p className="text-white font-medium">{prediccion.comercio}</p>
                <p className="text-gray-400 text-sm">{formatDate(prediccion.fecha_predicha)} • Predicción IA</p>
              </div>
              <p className="text-blue-400 font-medium">{formatCurrency(prediccion.monto_predicho)}</p>
            </div>
          ))}

          {predictions.length > 5 && (
            <Button variant="outline" className="w-full border-gray-600 text-gray-300">
              Ver todas las predicciones ({predictions.length})
            </Button>
          )}
        </CardContent>
      </Card>

      {/* RECOMMENDATIONS */}
      {analysis?.recommendations && analysis.recommendations.length > 0 && (
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg text-gray-100">Recomendaciones Personalizadas</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {analysis.recommendations.map((recomendacion: string, index: number) => (
              <div key={index} className="flex items-start space-x-3 p-3 bg-purple-900/20 rounded-lg">
                <CheckCircle className="w-5 h-5 text-purple-400 mt-0.5 flex-shrink-0" />
                <p className="text-gray-300 text-sm">{recomendacion}</p>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* DEBUG INFO - Remove in production */}
      {process.env.NODE_ENV === "development" && (
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg text-gray-100">Debug Info (Development)</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-xs">
            <p className="text-gray-400">Usuario Datathon: {usuario.datathonUserId}</p>
            <p className="text-gray-400">Predicciones recibidas: {predictions.length}</p>
            <p className="text-gray-400">Endpoint: {process.env.NEXT_PUBLIC_MODEL_ENDPOINT}</p>
            <p className="text-gray-400">Balance proyectado: {formatCurrency(analysis?.projectedBalance || 0)}</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
