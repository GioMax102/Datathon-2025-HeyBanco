"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { TrendingUp, AlertTriangle, Brain, Calendar, DollarSign, PiggyBank, Zap } from "lucide-react"
import { usePredictions } from "@/hooks/usePredictions"
import type { Usuario } from "@/lib/bankingService"

interface BalanceInteligenteScreenProps {
  usuario: Usuario
  modoConservar: boolean
  onActivarModoConservar: () => void
}

// Datos simulados del historial para el hook
const historialEjemplo = [
  { fecha: "2025-05-01", monto: 850, giro: "Alimentación", descripcion: "Supermercado" },
  { fecha: "2025-05-02", monto: 120, giro: "Transporte", descripcion: "Uber" },
  { fecha: "2025-05-03", monto: 2500, giro: "Servicios", descripcion: "Internet/Luz" },
  { fecha: "2025-05-05", monto: 300, giro: "Entretenimiento", descripcion: "Cine" },
  { fecha: "2025-05-08", monto: 750, giro: "Alimentación", descripcion: "Restaurante" },
]

export function BalanceInteligenteScreen({
  usuario,
  modoConservar,
  onActivarModoConservar,
}: BalanceInteligenteScreenProps) {
  const { predicciones, gastoProyectado, gastosPorCategoria, transaccionesRecurrentes, isLoading, error } =
    usePredictions(historialEjemplo)

  const [showProjection, setShowProjection] = useState(true)

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("es-MX", {
      style: "currency",
      currency: "MXN",
    }).format(amount)
  }

  // 🧠 ANÁLISIS INTELIGENTE BASADO EN TU MODELO
  const saldoActual = usuario.saldo
  const saldoProyectado = saldoActual - gastoProyectado
  const diasRestantes = 30
  const gastoPromedioDiario = gastoProyectado / diasRestantes

  // 🎯 UMBRALES PARA DECISIONES AUTOMÁTICAS
  const umbralCritico = 15000 // Saldo crítico
  const umbralAlto = 50000 // Saldo alto para oportunidades
  const umbralConservacion = 10000 // Activar modo conservar

  // 🚨 DETECCIÓN DE SITUACIONES
  const esSaldoCritico = saldoProyectado < umbralCritico
  const esSaldoAlto = saldoProyectado > umbralAlto
  const debeActivarConservacion = saldoProyectado < umbralConservacion

  // 📊 ANÁLISIS DE TENDENCIAS
  const tendencia = saldoProyectado > saldoActual ? "positiva" : "negativa"
  const diferenciaSaldo = Math.abs(saldoProyectado - saldoActual)
  const porcentajeCambio = ((saldoProyectado - saldoActual) / saldoActual) * 100

  return (
    <div className="p-4 pb-20 space-y-6">
      {/* Header con IA */}
      <div className="pt-8">
        <div className="flex items-center space-x-2 mb-2">
          <Brain className="w-6 h-6 text-purple-400" />
          <h1 className="text-2xl font-light text-gray-100">Balance Inteligente</h1>
        </div>
        <p className="text-gray-400 text-sm">Análisis predictivo basado en tu modelo de IA</p>
      </div>

      {/* 🧠 PROYECCIÓN INTELIGENTE - RESULTADO PRINCIPAL DEL MODELO */}
      <Card className="bg-gradient-to-br from-blue-900/40 to-purple-900/40 border-blue-800/30">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg text-gray-100 flex items-center justify-between">
            <div className="flex items-center">
              <TrendingUp className="w-5 h-5 mr-2 text-blue-400" />
              Proyección IA (30 días)
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowProjection(!showProjection)}
              className="text-blue-400 hover:bg-blue-900/20"
            >
              {showProjection ? "Ocultar" : "Mostrar"}
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {isLoading ? (
            <div className="text-center py-4">
              <div className="animate-spin w-6 h-6 border-2 border-blue-400 border-t-transparent rounded-full mx-auto mb-2"></div>
              <p className="text-gray-400 text-sm">Analizando patrones con IA...</p>
            </div>
          ) : error ? (
            <div className="bg-red-900/20 rounded-lg p-3">
              <p className="text-red-400 text-sm">{error}</p>
            </div>
          ) : showProjection ? (
            <>
              {/* Comparación Saldo Actual vs Proyectado */}
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center">
                  <p className="text-gray-400 text-xs">Saldo Actual</p>
                  <p className="text-white font-medium text-xl">{formatCurrency(saldoActual)}</p>
                </div>
                <div className="text-center">
                  <p className="text-gray-400 text-xs">Proyectado (30 días)</p>
                  <p
                    className={`font-medium text-xl ${
                      tendencia === "positiva" ? "text-green-400" : esSaldoCritico ? "text-red-400" : "text-orange-400"
                    }`}
                  >
                    {formatCurrency(saldoProyectado)}
                  </p>
                </div>
              </div>

              {/* Barra de Progreso Visual */}
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-300">Cambio proyectado</span>
                  <span className={`${tendencia === "positiva" ? "text-green-400" : "text-red-400"}`}>
                    {tendencia === "positiva" ? "+" : ""}
                    {porcentajeCambio.toFixed(1)}%
                  </span>
                </div>
                <Progress
                  value={Math.min(Math.abs(porcentajeCambio), 100)}
                  className={`h-3 ${tendencia === "positiva" ? "bg-green-900/30" : "bg-red-900/30"}`}
                />
              </div>

              {/* Información del Modelo */}
              <div className="bg-purple-900/20 rounded-lg p-3">
                <div className="flex items-center mb-2">
                  <Brain className="w-4 h-4 text-purple-400 mr-2" />
                  <span className="text-purple-400 text-sm font-medium">Predicción del Modelo</span>
                </div>
                <div className="grid grid-cols-2 gap-4 text-xs">
                  <div>
                    <p className="text-gray-400">Gastos predichos:</p>
                    <p className="text-purple-400">{formatCurrency(gastoProyectado)}</p>
                  </div>
                  <div>
                    <p className="text-gray-400">Transacciones detectadas:</p>
                    <p className="text-purple-400">{predicciones.length}</p>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="text-center py-8">
              <p className="text-gray-400">Proyección oculta</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* 🚨 ALERTAS AUTOMÁTICAS BASADAS EN EL MODELO */}
      {esSaldoCritico && (
        <Card className="bg-gradient-to-r from-red-900/30 to-orange-900/30 border-red-800/50">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3 mb-3">
              <AlertTriangle className="w-6 h-6 text-red-400" />
              <div>
                <p className="text-red-400 font-medium">🚨 Alerta: Saldo Crítico Detectado</p>
                <p className="text-gray-300 text-sm">
                  Tu modelo predice un saldo de {formatCurrency(saldoProyectado)} - por debajo del umbral seguro
                </p>
              </div>
            </div>

            {/* Acciones Automáticas Sugeridas */}
            <div className="grid grid-cols-1 gap-2 mt-3">
              <Button
                size="sm"
                className="bg-amber-600 hover:bg-amber-700 justify-start"
                onClick={() => console.log("Microcrédito solicitado")}
              >
                <DollarSign className="w-4 h-4 mr-2" />
                Solicitar Microcrédito (hasta $5,000)
              </Button>

              {!modoConservar && (
                <Button
                  size="sm"
                  variant="outline"
                  className="border-red-600 text-red-400 hover:bg-red-900/20 justify-start"
                  onClick={onActivarModoConservar}
                >
                  <AlertTriangle className="w-4 h-4 mr-2" />
                  Activar Modo Conservar Automáticamente
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* 💰 OPORTUNIDADES PARA SALDO ALTO */}
      {esSaldoAlto && (
        <Card className="bg-gradient-to-r from-emerald-900/20 to-teal-900/20 border-emerald-800/30">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3 mb-3">
              <TrendingUp className="w-6 h-6 text-emerald-400" />
              <div>
                <p className="text-emerald-400 font-medium">💡 Oportunidad: Saldo Alto Detectado</p>
                <p className="text-gray-300 text-sm">
                  Tu modelo predice {formatCurrency(saldoProyectado)} - aprovecha para hacer crecer tu dinero
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 mt-3">
              <Button
                size="sm"
                variant="outline"
                className="border-emerald-600 text-emerald-400 hover:bg-emerald-900/20"
              >
                <PiggyBank className="w-4 h-4 mr-2" />
                Invertir
              </Button>
              <Button size="sm" variant="outline" className="border-blue-600 text-blue-400 hover:bg-blue-900/20">
                <Zap className="w-4 h-4 mr-2" />
                Promociones
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* 📊 GRÁFICA DE GASTOS PREDICHOS POR CATEGORÍA */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg text-gray-100">Gastos Predichos por Categoría</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {Object.entries(gastosPorCategoria).map(([categoria, monto], index) => {
            const porcentaje = gastoProyectado > 0 ? (monto / gastoProyectado) * 100 : 0
            const colores = ["bg-red-400", "bg-blue-400", "bg-green-400", "bg-yellow-400", "bg-purple-400"]
            const color = colores[index % colores.length]

            return (
              <div key={categoria} className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-gray-300 text-sm">{categoria}</span>
                  <div className="text-right">
                    <p className="text-white text-sm">{formatCurrency(monto)}</p>
                    <p className="text-gray-400 text-xs">{porcentaje.toFixed(1)}%</p>
                  </div>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2">
                  <div
                    className={`${color} h-2 rounded-full transition-all duration-500`}
                    style={{ width: `${porcentaje}%` }}
                  ></div>
                </div>
              </div>
            )
          })}

          <Badge variant="outline" className="bg-purple-900/20 text-purple-400 border-purple-600 mt-4">
            <Brain className="w-3 h-3 mr-1" />
            Predicción basada en tu modelo de IA
          </Badge>
        </CardContent>
      </Card>

      {/* 🔄 TRANSACCIONES RECURRENTES DETECTADAS */}
      {transaccionesRecurrentes.length > 0 && (
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg text-gray-100 flex items-center">
              <Calendar className="w-5 h-5 mr-2 text-green-400" />
              Patrones Recurrentes Detectados
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {transaccionesRecurrentes.slice(0, 3).map((transaccion, index) => (
              <div
                key={index}
                className="flex justify-between items-center p-3 bg-green-900/10 rounded-lg border border-green-800/20"
              >
                <div>
                  <p className="text-white font-medium">{transaccion.giro}</p>
                  <p className="text-gray-400 text-sm">Patrón detectado por tu modelo</p>
                </div>
                <p className="text-green-400 font-medium">{formatCurrency(transaccion.monto)}</p>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* 📈 MÉTRICAS ADICIONALES */}
      <div className="grid grid-cols-2 gap-4">
        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-4 text-center">
            <p className="text-gray-400 text-xs">Gasto Promedio Diario</p>
            <p className="text-white font-medium">{formatCurrency(gastoPromedioDiario)}</p>
          </CardContent>
        </Card>

        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-4 text-center">
            <p className="text-gray-400 text-xs">Días de Autonomía</p>
            <p className="text-white font-medium">
              {gastoPromedioDiario > 0 ? Math.floor(saldoActual / gastoPromedioDiario) : "∞"} días
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
