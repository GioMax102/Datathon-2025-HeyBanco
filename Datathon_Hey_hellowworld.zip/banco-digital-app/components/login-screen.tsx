"use client"

import type React from "react"
import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Eye, EyeOff, CreditCard, Shield, Zap, Sparkles } from "lucide-react"

interface LoginScreenProps {
  onLogin: (email: string, password: string) => boolean
}

export function LoginScreen({ onLogin }: LoginScreenProps) {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    // Simular delay de autenticación
    await new Promise((resolve) => setTimeout(resolve, 1000))

    const success = onLogin(email, password)

    if (!success) {
      setError("Usuario no encontrado en el dataset o contraseña incorrecta")
    }

    setIsLoading(false)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900/10 to-purple-900/10 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-gradient-to-r from-blue-500/5 to-purple-500/5 rounded-full blur-3xl"></div>
      </div>

      <div className="w-full max-w-md space-y-8 relative z-10">
        {/* Logo y Header */}
        <div className="text-center space-y-6">
          <div className="relative">
            <div className="w-20 h-20 mx-auto bg-gradient-to-br from-blue-500 to-purple-600 rounded-3xl flex items-center justify-center shadow-2xl">
              <CreditCard className="w-10 h-10 text-white" />
              <div className="absolute -top-1 -right-1 w-6 h-6 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center">
                <Sparkles className="w-3 h-3 text-white" />
              </div>
            </div>
          </div>
          <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              Hey Banco
            </h1>
            <p className="text-gray-400 text-lg mt-2">Tu banco digital inteligente</p>
            <p className="text-gray-500 text-sm">Powered by AI • Datathon 2025</p>
          </div>
        </div>

        {/* Características mejoradas */}
        <div className="grid grid-cols-3 gap-6 text-center">
          <div className="space-y-3 group">
            <div className="w-14 h-14 mx-auto bg-gradient-to-br from-green-500/20 to-emerald-500/20 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform border border-green-500/20">
              <Shield className="w-7 h-7 text-green-400" />
            </div>
            <div>
              <p className="text-sm font-medium text-green-400">Seguro</p>
              <p className="text-xs text-gray-500">Encriptación 256-bit</p>
            </div>
          </div>
          <div className="space-y-3 group">
            <div className="w-14 h-14 mx-auto bg-gradient-to-br from-purple-500/20 to-pink-500/20 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform border border-purple-500/20">
              <Zap className="w-7 h-7 text-purple-400" />
            </div>
            <div>
              <p className="text-sm font-medium text-purple-400">Rápido</p>
              <p className="text-xs text-gray-500">Transacciones instantáneas</p>
            </div>
          </div>
          <div className="space-y-3 group">
            <div className="w-14 h-14 mx-auto bg-gradient-to-br from-blue-500/20 to-cyan-500/20 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform border border-blue-500/20">
              <CreditCard className="w-7 h-7 text-blue-400" />
            </div>
            <div>
              <p className="text-sm font-medium text-blue-400">Inteligente</p>
              <p className="text-xs text-gray-500">Predicciones con IA</p>
            </div>
          </div>
        </div>

        {/* Formulario de Login mejorado */}
        <Card className="glass border-gray-700/50 shadow-2xl card-hover">
          <CardContent className="p-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-gray-300 font-medium">
                  ID de Usuario
                </Label>
                <Input
                  id="email"
                  type="text"
                  placeholder="Ej: a010, a011, a012..."
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="bg-gray-800/50 border-gray-600 text-white placeholder-gray-400 h-12 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-gray-300 font-medium">
                  Contraseña
                </Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Ingresa tu contraseña"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="bg-gray-800/50 border-gray-600 text-white placeholder-gray-400 h-12 rounded-xl pr-12 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-300 transition-colors"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              {error && (
                <div className="bg-red-900/20 border border-red-800/30 rounded-xl p-4 animate-in slide-in-from-top-2">
                  <p className="text-red-400 text-sm flex items-center">
                    <span className="w-2 h-2 bg-red-400 rounded-full mr-2"></span>
                    {error}
                  </p>
                </div>
              )}

              <Button
                type="submit"
                className="w-full h-12 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-medium rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-[1.02]"
                disabled={isLoading}
              >
                {isLoading ? (
                  <div className="flex items-center space-x-3">
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    <span>Verificando usuario...</span>
                  </div>
                ) : (
                  <div className="flex items-center justify-center space-x-2">
                    <span>Iniciar Sesión</span>
                    <Sparkles className="w-4 h-4" />
                  </div>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Credenciales demo mejoradas */}
        <Card className="bg-gradient-to-r from-blue-900/20 to-purple-900/20 border-blue-800/30 shadow-xl">
          <CardContent className="p-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-8 h-8 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-lg flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <p className="text-blue-400 font-semibold">🎯 Datathon - Usuarios del Dataset</p>
            </div>
            <div className="space-y-3 text-sm">
              <div className="bg-gray-800/30 rounded-lg p-3">
                <p className="text-gray-300 font-medium">Usuario:</p>
                <p className="text-blue-400 font-mono">Usa cualquier ID del dataset (ej: a010, a011, etc.)</p>
              </div>
              <div className="bg-gray-800/30 rounded-lg p-3">
                <p className="text-gray-300 font-medium">Contraseña:</p>
                <p className="text-purple-400 font-mono">123456</p>
              </div>
              <div className="flex items-center space-x-2 text-xs">
                <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></div>
                <p className="text-yellow-400">Solo usuarios del dataset pueden acceder</p>
              </div>
              <div className="flex items-center space-x-2 text-xs">
                <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                <p className="text-green-400">Revisa la consola del navegador para ver IDs disponibles</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Footer mejorado */}
        <div className="text-center space-y-2">
          <p className="text-gray-500 text-sm">© 2025 Hey Banco. Todos los derechos reservados.</p>
          <p className="text-gray-600 text-xs">Desarrollado para el Datathon Hey Banco 2025</p>
        </div>
      </div>
    </div>
  )
}
