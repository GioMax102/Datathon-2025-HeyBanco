import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { 
  TrendingUp, 
  TrendingDown, 
  BarChart3,
  PieChart,
  Calendar,
  AlertTriangle,
  CheckCircle,
  Target,
  DollarSign,
  CreditCard,
  Wallet,
  ArrowUpCircle,
  ArrowDownCircle,
  Brain,
  Download,
  Filter
} from "lucide-react"
import { bankingService, type AnalisisFinanciero, type Usuario } from "@/lib/bankingService"

interface AnalyticsScreenProps {
  usuario: Usuario
}

export function AnalyticsScreen({ usuario }: AnalyticsScreenProps) {
  const [analisis, setAnalisis] = useState<AnalisisFinanciero | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [periodoSeleccionado, setPeriodoSeleccionado] = useState('mes')
  const [vistaActiva, setVistaActiva] = useState<'gastos' | 'ingresos' | 'patrimonio'>('gastos')

  useEffect(() => {
    cargarAnalisis()
  }, [periodoSeleccionado])

  const cargarAnalisis = async () => {
    setIsLoading(true)
    try {
      const data = await bankingService.getAnalisisFinanciero(usuario.id)
      setAnalisis(data)
    } catch (error) {
      console.error('Error cargando análisis:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("es-MX", {
      style: "currency",
      currency: "MXN",
    }).format(amount)
  }

  const formatPercentage = (value: number) => {
    return `${value.toFixed(1)}%`
  }

  const getSaludFinancieraColor = (score: number) => {
    if (score >= 80) return 'text-green-400 bg-green-900/20 border-green-800/30'
    if (score >= 60) return 'text-yellow-400 bg-yellow-900/20 border-yellow-800/30'
    if (score >= 40) return 'text-orange-400 bg-orange-900/20 border-orange-800/30'
    return 'text-red-400 bg-red-900/20 border-red-800/30'
  }

  const getSaludFinancieraTexto = (score: number) => {
    if (score >= 80) return 'Excelente'
    if (score >= 60) return 'Buena'
    if (score >= 40) return 'Regular'
    return 'Necesita Atención'
  }

  const getColorCategoria = (index: number) => {
    const colores = [
      'text-red-400 bg-red-900/20',
      'text-blue-400 bg-blue-900/20',
      'text-green-400 bg-green-900/20',
      'text-purple-400 bg-purple-900/20',
      'text-orange-400 bg-orange-900/20',
      'text-cyan-400 bg-cyan-900/20'
    ]
    return colores[index % colores.length]
  }

  if (isLoading) {
    return (
      <div className="p-4 pb-20 flex justify-center items-center min-h-[60vh]">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-2 border-blue-400 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-400">Analizando tus finanzas...</p>
        </div>
      </div>
    )
  }

  if (!analisis) {
    return (
      <div className="p-4 pb-20">
        <div className="text-center py-8">
          <BarChart3 className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-white font-medium mb-2">Error al cargar análisis</h3>
          <p className="text-gray-400 text-sm">No se pudo obtener el análisis financiero</p>
        </div>
      </div>
    )
  }

  return (
    <div className="p-4 pb-20 space-y-6">
      {/* Header */}
      <div className="pt-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-light text-gray-100">Análisis Financiero</h1>
            <div className="flex items-center space-x-2 mt-1">
              <Brain className="w-4 h-4 text-purple-400" />
              <p className="text-gray-400 text-sm">Insights inteligentes de tus finanzas</p>
            </div>
          </div>
          
          <div className="flex space-x-2">
            <Button variant="outline" size="sm" className="border-gray-600 text-gray-300">
              <Filter className="w-4 h-4 mr-2" />
              Filtros
            </Button>
            <Button variant="outline" size="sm" className="border-blue-600 text-blue-400">
              <Download className="w-4 h-4 mr-2" />
              Exportar
            </Button>
          </div>
        </div>
      </div>

      {/* Selector de período */}
      <div className="flex space-x-2">
        {['semana', 'mes', 'trimestre', 'año'].map((periodo) => (
          <Button
            key={periodo}
            variant={periodoSeleccionado === periodo ? "default" : "outline"}
            size="sm"
            onClick={() => setPeriodoSeleccionado(periodo)}
            className={periodoSeleccionado === periodo ? 
              "bg-blue-600 hover:bg-blue-700" : 
              "border-gray-600 text-gray-300"
            }
          >
            {periodo.charAt(0).toUpperCase() + periodo.slice(1)}
          </Button>
        ))}
      </div>

      {/* Tarjetas de resumen */}
      <div className="grid grid-cols-2 gap-4">
        <Card className="bg-green-900/20 border-green-800/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-400 text-sm">Ingresos</p>
                <p className="text-white text-xl font-medium">
                  {formatCurrency(analisis.ingresosMensuales)}
                </p>
              </div>
              <ArrowUpCircle className="w-8 h-8 text-green-400" />
            </div>
            <div className="flex items-center mt-2">
              <TrendingUp className="w-3 h-3 text-green-400 mr-1" />
              <span className="text-green-400 text-xs">+5.2% vs mes anterior</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-red-900/20 border-red-800/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-red-400 text-sm">Gastos</p>
                <p className="text-white text-xl font-medium">
                  {formatCurrency(analisis.gastosMensuales)}
                </p>
              </div>
              <ArrowDownCircle className="w-8 h-8 text-red-400" />
            </div>
            <div className="flex items-center mt-2">
              <TrendingDown className="w-3 h-3 text-red-400 mr-1" />
              <span className="text-red-400 text-xs">+2.1% vs mes anterior</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Salud Financiera */}
      <Card className={`border ${getSaludFinancieraColor(analisis.saludFinanciera)}`}>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg text-gray-100 flex items-center">
            <Target className="w-5 h-5 mr-2 text-blue-400" />
            Salud Financiera
            <Badge className={`ml-2 ${getSaludFinancieraColor(analisis.saludFinanciera)}`}>
              {getSaludFinancieraTexto(analisis.saludFinanciera)}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-center">
            <p className="text-4xl font-light text-white mb-2">
              {analisis.saludFinanciera}/100
            </p>
            <Progress value={analisis.saludFinanciera} className="h-3" />
          </div>

          <div className="grid grid-cols-3 gap-4 text-center text-sm">
            <div>
              <p className="text-gray-400">Ahorro Mensual</p>
              <p className="text-white font-medium">
                {formatCurrency(analisis.ahorroPromedio)}
              </p>
              <p className="text-green-400 text-xs">
                {formatPercentage((analisis.ahorroPromedio / analisis.ingresosMensuales) * 100)}
              </p>
            </div>
            
            <div>
              <p className="text-gray-400">Patrimonio Neto</p>
              <p className="text-white font-medium">
                {formatCurrency(analisis.patrimonio.patrimonioNeto)}
              </p>
              <p className="text-blue-400 text-xs">
                {analisis.patrimonio.patrimonioNeto > 0 ? 'Positivo' : 'Negativo'}
              </p>
            </div>
            
            <div>
              <p className="text-gray-400">Ratio Deuda</p>
              <p className="text-white font-medium">
                {formatPercentage((analisis.patrimonio.pasivos / analisis.ingresosMensuales) * 100)}
              </p>
              <p className={`text-xs ${
                (analisis.patrimonio.pasivos / analisis.ingresosMensuales) < 0.3 ? 'text-green-400' : 'text-yellow-400'
              }`}>
                {(analisis.patrimonio.pasivos / analisis.ingresosMensuales) < 0.3 ? 'Saludable' : 'Atención'}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Navegación de vistas */}
      <div className="flex space-x-1 bg-gray-800/50 rounded-lg p-1">
        {[
          { key: 'gastos', label: 'Gastos', icon: ArrowDownCircle },
          { key: 'ingresos', label: 'Ingresos', icon: ArrowUpCircle },
          { key: 'patrimonio', label: 'Patrimonio', icon: Wallet }
        ].map(({ key, label, icon: Icon }) => (
          <Button
            key={key}
            variant={vistaActiva === key ? "default" : "ghost"}
            size="sm"
            onClick={() => setVistaActiva(key as any)}
            className={`flex-1 ${vistaActiva === key ? 
              "bg-blue-600 hover:bg-blue-700" : 
              "text-gray-300 hover:bg-gray-700/50"
            }`}
          >
            <Icon className="w-4 h-4 mr-2" />
            {label}
          </Button>
        ))}
      </div>

      {/* Vista de Gastos */}
      {vistaActiva === 'gastos' && (
        <div className="space-y-4">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg text-gray-100 flex items-center">
                <PieChart className="w-5 h-5 mr-2 text-orange-400" />
                Distribución de Gastos
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {analisis.categoriasMasGasto.map((categoria, index) => (
                <div key={categoria.categoria} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center space-x-3">
                      <div className={`w-4 h-4 rounded-full ${getColorCategoria(index)}`}></div>
                      <span className="text-white font-medium">{categoria.categoria}</span>
                    </div>
                    <div className="text-right">
                      <p className="text-white font-medium">{formatCurrency(categoria.monto)}</p>
                      <p className="text-gray-400 text-xs">{formatPercentage(categoria.porcentaje)}</p>
                    </div>
                  </div>
                  <Progress value={categoria.porcentaje} className="h-2" />
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Tendencias */}
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg text-gray-100 flex items-center">
                <BarChart3 className="w-5 h-5 mr-2 text-blue-400" />
                Tendencia de Gastos
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  {analisis.tendenciaGastos === 'creciente' ? (
                    <TrendingUp className="w-5 h-5 text-red-400" />
                  ) : analisis.tendenciaGastos === 'decreciente' ? (
                    <TrendingDown className="w-5 h-5 text-green-400" />
                  ) : (
                    <div className="w-5 h-5 bg-yellow-400 rounded-full"></div>
                  )}
                  <span className="text-white font-medium">
                    Tendencia {analisis.tendenciaGastos}
                  </span>
                </div>
                <Badge variant="outline" className={
                  analisis.tendenciaGastos === 'decreciente' ? 'bg-green-900/20 text-green-400 border-green-600' :
                  analisis.tendenciaGastos === 'creciente' ? 'bg-red-900/20 text-red-400 border-red-600' :
                  'bg-yellow-900/20 text-yellow-400 border-yellow-600'
                }>
                  {analisis.tendenciaGastos === 'decreciente' ? 'Mejorando' :
                   analisis.tendenciaGastos === 'creciente' ? 'Atención' : 'Estable'}
                </Badge>
              </div>
              
              {/* Gráfico simulado con barras */}
              <div className="space-y-3">
                {['Ene', 'Feb', 'Mar', 'Abr', 'May'].map((mes, index) => {
                  const valor = 70 + Math.random() * 30
                  return (
                    <div key={mes} className="flex items-center space-x-3">
                      <span className="text-gray-400 text-sm w-8">{mes}</span>
                      <div className="flex-1 bg-gray-700 rounded-full h-2">
                        <div 
                          className="bg-blue-400 h-2 rounded-full" 
                          style={{ width: `${valor}%` }}
                        ></div>
                      </div>
                      <span className="text-white text-sm w-16 text-right">
                        {formatCurrency(analisis.gastosMensuales * (valor / 100))}
                      </span>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Vista de Patrimonio */}
      {vistaActiva === 'patrimonio' && (
        <div className="space-y-4">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg text-gray-100 flex items-center">
                <Wallet className="w-5 h-5 mr-2 text-green-400" />
                Composición Patrimonial
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <p className="text-green-400 text-sm">Activos</p>
                      <p className="text-white font-medium">{formatCurrency(analisis.patrimonio.activos)}</p>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Efectivo y cuentas</span>
                        <span className="text-white">{formatCurrency(usuario.saldo)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Inversiones</span>
                        <span className="text-white">{formatCurrency(85000)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Otros activos</span>
                        <span className="text-white">{formatCurrency(15000)}</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <p className="text-red-400 text-sm">Pasivos</p>
                      <p className="text-white font-medium">{formatCurrency(analisis.patrimonio.pasivos)}</p>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Tarjetas de crédito</span>
                        <span className="text-white">{formatCurrency(12500)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Préstamos</span>
                        <span className="text-white">{formatCurrency(0)}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-r from-green-900/20 to-blue-900/20 border border-green-800/30 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-green-400 font-medium">Patrimonio Neto</p>
                    <p className="text-white text-2xl font-light">
                      {formatCurrency(analisis.patrimonio.patrimonioNeto)}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-green-400 text-sm">Crecimiento anual</p>
                    <div className="flex items-center">
                      <TrendingUp className="w-4 h-4 text-green-400 mr-1" />
                      <span className="text-white font-medium">+15.2%</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Ratio de endeudamiento */}
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-400">Ratio de endeudamiento</span>
                  <span className="text-white">
                    {formatPercentage((analisis.patrimonio.pasivos / analisis.patrimonio.activos) * 100)}
                  </span>
                </div>
                <Progress 
                  value={(analisis.patrimonio.pasivos / analisis.patrimonio.activos) * 100} 
                  className="h-2" 
                />
                <p className="text-gray-500 text-xs">
                  Recomendado: menos del 30%
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Recomendaciones IA */}
      <Card className="bg-gradient-to-br from-purple-900/40 to-blue-900/40 border-purple-800/30">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg text-gray-100 flex items-center">
            <Brain className="w-5 h-5 mr-2 text-purple-400" />
            Recomendaciones Inteligentes
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {analisis.recomendaciones.map((recomendacion, index) => (
            <div key={index} className="flex items-start space-x-3 p-3 bg-purple-900/20 rounded-lg">
              <CheckCircle className="w-5 h-5 text-purple-400 mt-0.5 flex-shrink-0" />
              <p className="text-gray-300 text-sm">{recomendacion}</p>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Alertas */}
      {analisis.alertas.length > 0 && (
        <Card className="bg-amber-900/20 border-amber-800/30">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg text-gray-100 flex items-center">
              <AlertTriangle className="w-5 h-5 mr-2 text-amber-400" />
              Alertas Financieras
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {analisis.alertas.map((alerta, index) => (
              <div key={index} className="flex items-start space-x-3 p-3 bg-amber-900/20 rounded-lg border border-amber-800/30">
                <AlertTriangle className="w-5 h-5 text-amber-400 mt-0.5 flex-shrink-0" />
                <div className="flex-1">
                  <p className="text-amber-400 text-sm font-medium">Atención requerida</p>
                  <p className="text-gray-300 text-sm">{alerta}</p>
                </div>
                <Button size="sm" variant="outline" className="border-amber-600 text-amber-400">
                  Revisar
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Acciones recomendadas */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg text-gray-100">Acciones Recomendadas</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Button variant="outline" className="w-full justify-start border-green-600 text-green-400 hover:bg-green-900/20">
            <Target className="w-4 h-4 mr-3" />
            <div className="text-left">
              <p className="font-medium">Optimizar gastos en entretenimiento</p>
              <p className="text-xs text-gray-400">Potencial ahorro: {formatCurrency(800)}/mes</p>
            </div>
          </Button>

          <Button variant="outline" className="w-full justify-start border-blue-600 text-blue-400 hover:bg-blue-900/20">
            <CreditCard className="w-4 h-4 mr-3" />
            <div className="text-left">
              <p className="font-medium">Pagar deuda de tarjeta de crédito</p>
              <p className="text-xs text-gray-400">Ahorro en intereses: {formatCurrency(312)}/mes</p>
            </div>
          </Button>

          <Button variant="outline" className="w-full justify-start border-purple-600 text-purple-400 hover:bg-purple-900/20">
            <DollarSign className="w-4 h-4 mr-3" />
            <div className="text-left">
              <p className="font-medium">Aumentar aporte a fondo de emergencia</p>
              <p className="text-xs text-gray-400">Meta: 6 meses de gastos ({formatCurrency(75000)})</p>
            </div>
          </Button>
        </CardContent>
      </Card>

      {/* Comparación con promedios */}
      <Card className="bg-gray-800/50 border-gray-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg text-gray-100">Comparación con Promedio Nacional</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center p-4 bg-green-900/20 rounded-lg">
              <p className="text-green-400 text-sm">Tu ahorro mensual</p>
              <p className="text-white text-xl font-medium">
                {formatPercentage((analisis.ahorroPromedio / analisis.ingresosMensuales) * 100)}
              </p>
              <p className="text-gray-400 text-xs">Promedio: 12%</p>
            </div>
            
            <div className="text-center p-4 bg-blue-900/20 rounded-lg">
              <p className="text-blue-400 text-sm">Tu salud financiera</p>
              <p className="text-white text-xl font-medium">{analisis.saludFinanciera}/100</p>
              <p className="text-gray-400 text-xs">Promedio: 65/100</p>
            </div>
          </div>

          <div className="text-center">
            <Badge className="bg-green-900/20 text-green-400 border-green-600">
              ¡Estás por encima del promedio! 🎉
            </Badge>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
