"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Bell,
  Search,
  Menu,
  Shield,
  Eye,
  EyeOff,
  Settings,
  HelpCircle,
  QrCode,
  CreditCard,
  Sparkles,
} from "lucide-react"
import type { Usuario } from "@/lib/bankingService"

interface TopNavigationProps {
  usuario: Usuario
  activeScreen: string
  modoConservar: boolean
  onScreenChange: (screen: string) => void
}

export function TopNavigation({ usuario, activeScreen, modoConservar, onScreenChange }: TopNavigationProps) {
  const [showBalance, setShowBalance] = useState(true)
  const [showMenu, setShowMenu] = useState(false)
  const [notificacionesCount, setNotificacionesCount] = useState(3)

  // Obtener saludo según la hora
  const getSaludo = () => {
    const hora = new Date().getHours()
    if (hora < 12) return "Buenos días"
    if (hora < 18) return "Buenas tardes"
    return "Buenas noches"
  }

  // Formatear saldo
  const formatCurrency = (amount: number) => {
    if (!showBalance) return "••••••"
    return new Intl.NumberFormat("es-MX", {
      style: "currency",
      currency: "MXN",
    }).format(amount)
  }

  // Obtener título de pantalla
  const getTituloPantalla = () => {
    const titulos: Record<string, string> = {
      inicio: "Inicio",
      transacciones: "Movimientos",
      analytics: "Análisis",
      pagos: "Plan Financiero",
      finanzas: "Balance Inteligente",
      metas: "Metas",
      perfil: "Perfil",
      notificaciones: "Notificaciones",
      conservar: "Modo Conservar",
    }
    return titulos[activeScreen] || "Hey Banco"
  }

  // Pantallas que muestran balance en el header
  const pantallasConBalance = ["inicio", "transacciones", "finanzas"]
  const mostrarBalance = pantallasConBalance.includes(activeScreen)

  return (
    <>
      {/* Header principal con glass effect */}
      <header
        className={`fixed top-0 left-1/2 transform -translate-x-1/2 w-full max-w-sm z-40 glass border-b border-gray-700/50`}
      >
        <div className="px-4 py-4">
          {/* Pantalla de inicio - Header personalizado */}
          {activeScreen === "inicio" && (
            <div className="space-y-4">
              {/* Primera fila: Saludo y notificaciones */}
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">{getSaludo()}</p>
                  <div className="flex items-center space-x-2">
                    <p className="text-white text-lg font-semibold">
                      {usuario.id.length > 8 ? `${usuario.id.substring(0, 8)}...` : usuario.id}
                    </p>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  {modoConservar && (
                    <Badge variant="outline" className="bg-amber-900/20 text-amber-400 border-amber-600 animate-pulse">
                      <Shield className="w-3 h-3 mr-1" />
                      Conservar
                    </Badge>
                  )}

                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onScreenChange("notificaciones")}
                    className="relative border-gray-700 text-gray-300 hover:bg-gray-800 transition-all duration-200"
                  >
                    <Bell className="w-4 h-4" />
                    {notificacionesCount > 0 && (
                      <Badge className="absolute -top-2 -right-2 bg-gradient-to-r from-red-500 to-pink-500 text-white text-xs min-w-[18px] h-[18px] rounded-full flex items-center justify-center p-0 animate-bounce">
                        {notificacionesCount}
                      </Badge>
                    )}
                  </Button>
                </div>
              </div>

              {/* Segunda fila: Saldo con mejor diseño */}
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-xs">Saldo total</p>
                  <div className="flex items-center space-x-3">
                    <p className="text-white text-2xl font-light">{formatCurrency(usuario.saldo)}</p>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowBalance(!showBalance)}
                      className="text-gray-400 hover:text-white p-1 h-auto transition-colors"
                    >
                      {showBalance ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </Button>
                  </div>
                </div>

                <div className="flex space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-blue-600 text-blue-400 hover:bg-blue-900/20 transition-all duration-200"
                  >
                    <QrCode className="w-4 h-4 mr-1" />
                    Cobrar
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Headers para otras pantallas */}
          {activeScreen !== "inicio" && (
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <h1 className="text-xl font-semibold text-white">{getTituloPantalla()}</h1>
                {modoConservar && activeScreen === "conservar" && (
                  <Badge variant="outline" className="bg-amber-900/20 text-amber-400 border-amber-600 animate-pulse">
                    Activo
                  </Badge>
                )}
                {usuario.isDatathonUser && activeScreen === "finanzas" && (
                  <Badge variant="outline" className="bg-purple-900/20 text-purple-400 border-purple-600">
                    <Sparkles className="w-3 h-3 mr-1" />
                    IA
                  </Badge>
                )}
              </div>

              <div className="flex items-center space-x-2">
                {/* Balance en pantallas específicas */}
                {mostrarBalance && (
                  <div className="text-right">
                    <p className="text-gray-400 text-xs">Saldo</p>
                    <div className="flex items-center space-x-1">
                      <p className="text-white text-sm font-medium">{formatCurrency(usuario.saldo)}</p>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setShowBalance(!showBalance)}
                        className="text-gray-400 hover:text-white p-1 h-auto transition-colors"
                      >
                        {showBalance ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                      </Button>
                    </div>
                  </div>
                )}

                {/* Acciones por pantalla */}
                {activeScreen === "transacciones" && (
                  <Button variant="outline" size="sm" className="border-gray-700 text-gray-300 hover:bg-gray-800">
                    <Search className="w-4 h-4" />
                  </Button>
                )}

                {activeScreen === "analytics" && (
                  <Button variant="outline" size="sm" className="border-gray-700 text-gray-300 hover:bg-gray-800">
                    <Menu className="w-4 h-4" />
                  </Button>
                )}

                {/* Notificaciones siempre visibles */}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onScreenChange("notificaciones")}
                  className="relative border-gray-700 text-gray-300 hover:bg-gray-800 transition-all duration-200"
                >
                  <Bell className="w-4 h-4" />
                  {notificacionesCount > 0 && (
                    <Badge className="absolute -top-2 -right-2 bg-gradient-to-r from-red-500 to-pink-500 text-white text-xs min-w-[16px] h-[16px] rounded-full flex items-center justify-center p-0">
                      {notificacionesCount > 9 ? "9+" : notificacionesCount}
                    </Badge>
                  )}
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* Barra de nivel del cliente mejorada */}
        {activeScreen === "inicio" && !modoConservar && (
          <div className="px-4 pb-3">
            <div className="flex items-center space-x-3">
              <Badge className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0">
                {usuario.nivelCliente}
              </Badge>
              <div className="flex-1 bg-gray-700/50 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-gradient-to-r from-purple-500 to-blue-500 h-2 rounded-full transition-all duration-1000 ease-out"
                  style={{ width: "78%" }}
                ></div>
              </div>
              <p className="text-gray-400 text-xs font-medium">Elite</p>
            </div>
          </div>
        )}
      </header>

      {/* Espaciador mejorado */}
      <div
        className={`${
          activeScreen === "inicio" ? "h-36" : "h-24"
        } ${!modoConservar && activeScreen === "inicio" ? "h-40" : ""}`}
      ></div>

      {/* Menu desplegable mejorado */}
      {showMenu && (
        <div className="fixed inset-0 bg-black/50 z-50 backdrop-blur-sm" onClick={() => setShowMenu(false)}>
          <div className="absolute top-24 right-4 w-72 glass border border-gray-700/50 rounded-2xl shadow-2xl p-4 animate-in slide-in-from-top-2">
            <div className="space-y-3">
              <Button
                variant="ghost"
                className="w-full justify-start text-gray-300 hover:bg-gray-700/50 rounded-xl transition-all duration-200"
                onClick={() => {
                  setShowMenu(false)
                  onScreenChange("perfil")
                }}
              >
                <Settings className="w-4 h-4 mr-3" />
                Configuración
              </Button>

              <Button
                variant="ghost"
                className="w-full justify-start text-gray-300 hover:bg-gray-700/50 rounded-xl transition-all duration-200"
              >
                <HelpCircle className="w-4 h-4 mr-3" />
                Ayuda y Soporte
              </Button>

              <Button
                variant="ghost"
                className="w-full justify-start text-gray-300 hover:bg-gray-700/50 rounded-xl transition-all duration-200"
              >
                <CreditCard className="w-4 h-4 mr-3" />
                Mis Productos
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
