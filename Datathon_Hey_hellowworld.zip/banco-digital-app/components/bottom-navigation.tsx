"use client"

import { Home, CreditCard, TrendingUp, User, Bell } from "lucide-react"

interface BottomNavigationProps {
  activeScreen: string
  onScreenChange: (screen: string) => void
  modoConservar: boolean
}

export function BottomNavigation({ activeScreen, onScreenChange, modoConservar }: BottomNavigationProps) {
  const navItems = [
    {
      id: "inicio",
      icon: Home,
      label: "Inicio",
      screen: "inicio",
    },
    {
      id: "pagos",
      icon: CreditCard,
      label: "Pagos",
      screen: "pagos",
    },
    {
      id: "finanzas",
      icon: TrendingUp,
      label: "Finanzas",
      screen: "finanzas",
    },
    {
      id: "perfil",
      icon: User,
      label: "Perfil",
      screen: "perfil",
    },
    {
      id: "notificaciones",
      icon: Bell,
      label: "Notificaciones",
      screen: "notificaciones",
    },
  ]

  return (
    <div
      className={`fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-sm glass border-t border-gray-700/50 z-50`}
    >
      <div className="pb-20">
        <div className="flex justify-around py-3">
          {navItems.map((item) => {
            const Icon = item.icon
            const isActive = activeScreen === item.screen

            return (
              <button
                key={item.id}
                onClick={() => onScreenChange(item.screen)}
                className={`flex flex-col items-center py-3 px-4 rounded-2xl transition-all duration-300 transform ${
                  isActive
                    ? modoConservar
                      ? "text-amber-400 bg-amber-900/20 scale-110 shadow-lg"
                      : "text-blue-400 bg-blue-900/20 scale-110 shadow-lg"
                    : "text-gray-400 hover:text-gray-300 hover:bg-gray-700/30 hover:scale-105"
                }`}
              >
                <Icon className="w-5 h-5 mb-1" />
                <span className="text-xs font-medium">{item.label}</span>
                {isActive && (
                  <div
                    className={`w-1 h-1 rounded-full mt-1 animate-pulse ${
                      modoConservar ? "bg-amber-400" : "bg-blue-400"
                    }`}
                  ></div>
                )}
              </button>
            )
          })}
        </div>
      </div>

      {/* Indicador visual del modo conservar mejorado */}
      {modoConservar && (
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-amber-600 via-orange-500 to-red-500 animate-pulse"></div>
      )}
    </div>
  )
}
