"use client"

import { useState, useEffect, Suspense } from "react"
import { LoginScreen } from "@/components/login-screen"
import { DashboardScreen } from "@/components/dashboard-screen"
import { PlanFinancieroScreen } from "@/components/plan-financiero-screen"
import { DatathonBalanceScreen } from "@/components/datathon-balance-screen"
import { ModoConservarScreen } from "@/components/modo-conservar-screen"
import { PerfilScreen } from "@/components/perfil-screen"
import { NotificacionesScreen } from "@/components/notificaciones-screen"
import { TransaccionesScreen } from "@/components/transacciones-screen"
import { MetasScreen } from "@/components/metas-screen"
import { AnalyticsScreen } from "@/components/analytics-screen"
import { BottomNavigation } from "@/components/bottom-navigation"
import { TopNavigation } from "@/components/top-navigation"
import { bankingService, type Usuario } from "@/lib/bankingService"
import { datathonService } from "@/lib/datathonService"
import { BalanceInteligenteScreen } from "@/components/balance-inteligente-screen"

export default function BancoDigitalApp() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [activeScreen, setActiveScreen] = useState("inicio")
  const [usuario, setUsuario] = useState<Usuario | null>(null)
  const [modoConservar, setModoConservar] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  // Check session on load
  useEffect(() => {
    checkSession()
  }, [])

  // Auto-activate conservation mode for datathon users based on predictions
  useEffect(() => {
    if (usuario?.isDatathonUser && usuario.datathonUserId) {
      checkConservationMode()
    }
  }, [usuario])

  const checkSession = async () => {
    try {
      const sesionGuardada = localStorage.getItem("hey_banco_session")
      if (sesionGuardada) {
        const userData = JSON.parse(sesionGuardada)
        setUsuario(userData)
        setIsLoggedIn(true)

        // Check if conservation mode should be activated
        if (userData.isDatathonUser) {
          await checkConservationMode(userData)
        }
      }
    } catch (error) {
      console.error("Error checking session:", error)
      localStorage.removeItem("hey_banco_session")
    } finally {
      setIsLoading(false)
    }
  }

  const checkConservationMode = async (user = usuario) => {
    if (!user?.isDatathonUser || !user.datathonUserId) return

    try {
      const predictions = await datathonService.getPredictions(user.datathonUserId)
      const analysis = datathonService.analyzeFinancialSituation(
        user.saldo,
        predictions,
        5000, // Default savings goal
        2800, // Default weekly budget
      )

      setModoConservar(analysis.shouldActivateConservationMode)
    } catch (error) {
      console.error("Error checking conservation mode:", error)
    }
  }

  const handleLogin = async (email: string, password: string): Promise<boolean> => {
    try {
      const userData = await bankingService.authenticate(email, password)
      if (userData) {
        setUsuario(userData)
        setIsLoggedIn(true)

        // Save session
        localStorage.setItem("hey_banco_session", JSON.stringify(userData))

        // Check conservation mode for datathon users
        if (userData.isDatathonUser) {
          await checkConservationMode(userData)
        }

        return true
      }
      return false
    } catch (error) {
      console.error("Login error:", error)
      return false
    }
  }

  const handleLogout = () => {
    setIsLoggedIn(false)
    setUsuario(null)
    setActiveScreen("inicio")
    setModoConservar(false)
    localStorage.removeItem("hey_banco_session")
  }

  const toggleModoConservar = () => {
    setModoConservar(!modoConservar)

    if (usuario) {
      const updatedUser = { ...usuario }
      localStorage.setItem("hey_banco_session", JSON.stringify(updatedUser))
    }
  }

  const updateSaldo = (nuevoSaldo: number) => {
    if (usuario) {
      const updatedUser = { ...usuario, saldo: nuevoSaldo }
      setUsuario(updatedUser)
      localStorage.setItem("hey_banco_session", JSON.stringify(updatedUser))
    }
  }

  // Loading inicial
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="relative">
            <div className="w-16 h-16 border-4 border-blue-500/20 border-t-blue-500 rounded-full animate-spin mx-auto mb-4"></div>
            <div
              className="absolute inset-0 w-16 h-16 border-4 border-purple-500/20 border-b-purple-500 rounded-full animate-spin mx-auto"
              style={{ animationDirection: "reverse", animationDuration: "1.5s" }}
            ></div>
          </div>
          <h2 className="text-xl font-semibold text-white mb-2">Hey Banco</h2>
          <p className="text-gray-400 animate-pulse">Cargando tu experiencia bancaria...</p>
        </div>
      </div>
    )
  }

  // Login screen
  if (!isLoggedIn || !usuario) {
    return <LoginScreen onLogin={handleLogin} />
  }

  const renderScreen = () => {
    switch (activeScreen) {
      case "inicio":
        return (
          <DashboardScreen
            usuario={usuario}
            modoConservar={modoConservar}
            onToggleModoConservar={toggleModoConservar}
            onUpdateSaldo={updateSaldo}
          />
        )
      case "transacciones":
        return <TransaccionesScreen usuario={usuario} />
      case "analytics":
        return <AnalyticsScreen usuario={usuario} />
      case "pagos":
        return <PlanFinancieroScreen usuario={usuario} />
      case "finanzas":
        // Use datathon balance screen for datathon users
        return usuario.isDatathonUser ? (
          <DatathonBalanceScreen
            usuario={usuario}
            modoConservar={modoConservar}
            onActivarModoConservar={toggleModoConservar}
          />
        ) : (
          <BalanceInteligenteScreen
            usuario={usuario}
            modoConservar={modoConservar}
            onActivarModoConservar={toggleModoConservar}
          />
        )
      case "metas":
        return <MetasScreen usuario={usuario} />
      case "perfil":
        return <PerfilScreen usuario={usuario} onLogout={handleLogout} />
      case "notificaciones":
        return <NotificacionesScreen usuario={usuario} />
      case "conservar":
        return <ModoConservarScreen usuario={usuario} onDesactivar={toggleModoConservar} />
      default:
        return (
          <DashboardScreen
            usuario={usuario}
            modoConservar={modoConservar}
            onToggleModoConservar={toggleModoConservar}
            onUpdateSaldo={updateSaldo}
          />
        )
    }
  }

  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center">
          <div className="text-center">
            <div className="w-12 h-12 border-2 border-blue-400 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-gray-400">Cargando Hey Banco...</p>
          </div>
        </div>
      }
    >
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white">
        {/* Desktop container for larger screens */}
        <div className="desktop-container min-h-screen relative bg-gray-900/50 backdrop-blur-sm">
          <TopNavigation
            usuario={usuario}
            activeScreen={activeScreen}
            modoConservar={modoConservar}
            onScreenChange={setActiveScreen}
          />

          <main className={`transition-all duration-300 pb-20 ${modoConservar ? "bg-gray-900/80" : ""}`}>
            {renderScreen()}
          </main>

          <BottomNavigation
            activeScreen={activeScreen}
            onScreenChange={setActiveScreen}
            modoConservar={modoConservar}
          />
        </div>
      </div>
    </Suspense>
  )
}
