"use client"

// hooks/useDatathonPredictions.ts - Hook to use datathon predictions

import { useState, useEffect } from "react"
import { datathonService, type PrediccionTransaccion } from "@/lib/datathonService"

export function useDatathonPredictions(userId: string) {
  const [predictions, setPredictions] = useState<PrediccionTransaccion[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [analysis, setAnalysis] = useState<any>(null)

  const loadPredictions = async () => {
    if (!userId) return

    setIsLoading(true)
    setError(null)

    try {
      const data = await datathonService.getPredictions(userId)
      setPredictions(data)

      // Analyze financial situation
      const currentBalance = 45420.75 // This should come from user data
      const financialAnalysis = datathonService.analyzeFinancialSituation(
        currentBalance,
        data,
        5000, // Savings goal
        2800, // Weekly budget
      )
      setAnalysis(financialAnalysis)
    } catch (err) {
      console.error("Error loading predictions:", err)
      setError("Error al cargar predicciones del modelo")
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    loadPredictions()
  }, [userId])

  return {
    predictions,
    analysis,
    isLoading,
    error,
    refresh: loadPredictions,
  }
}
