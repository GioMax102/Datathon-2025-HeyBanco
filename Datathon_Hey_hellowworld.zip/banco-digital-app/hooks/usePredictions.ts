"use client"

import { useState, useEffect } from "react"
import helloWorldMachine from "@/lib/helloWorldMachine"

interface Transaccion {
  monto: number
  giro: string
  fecha?: string
  descripcion?: string
}

interface PrediccionPersona {
  id_persona: string
  transacciones_predichas: Transaccion[]
}

interface HistorialTransaccion {
  fecha: string
  monto: number
  giro: string
  descripcion?: string
}

export function usePredictions(historialTransacciones: HistorialTransaccion[]) {
  const [predicciones, setPredicciones] = useState<Transaccion[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const obtenerPredicciones = async () => {
    try {
      setIsLoading(true)
      setError(null)

      // Formatear el historial para el modelo
      const secuenciaTransacciones = historialTransacciones.map((t) => ({
        monto: t.monto,
        giro: t.giro,
        fecha: t.fecha,
      }))

      // Llamar al modelo de predicción
      const resultado = await helloWorldMachine.predecir(secuenciaTransacciones)

      // Extraer las transacciones predichas (resultado es [id_persona, transacciones])
      const transaccionesPredichas = resultado[1] || []
      setPredicciones(transaccionesPredichas)
    } catch (err) {
      console.error("Error al obtener predicciones:", err)
      setError("Error al generar predicciones")
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    if (historialTransacciones.length > 0) {
      obtenerPredicciones()
    }
  }, [historialTransacciones])

  // Calcular métricas útiles de las predicciones
  const gastoProyectado = predicciones.reduce((total, t) => total + t.monto, 0)

  const gastosPorCategoria = predicciones.reduce(
    (acc, t) => {
      acc[t.giro] = (acc[t.giro] || 0) + t.monto
      return acc
    },
    {} as Record<string, number>,
  )

  const transaccionesRecurrentes = predicciones.filter((t) => predicciones.filter((p) => p.giro === t.giro).length > 1)

  return {
    predicciones,
    gastoProyectado,
    gastosPorCategoria,
    transaccionesRecurrentes,
    isLoading,
    error,
    refresh: obtenerPredicciones,
  }
}
