import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# Configurar el estilo de los gráficos
plt.style.use('default')
sns.set_palette("husl")
plt.rcParams['figure.figsize'] = (12, 8)
plt.rcParams['font.size'] = 10

def cargar_y_procesar_datos(archivo_csv):
    """
    Carga el archivo CSV y procesa las fechas agregando nuevas columnas
    """
    # Leer el CSV
    df = pd.read_csv(archivo_csv)
    
    # Convertir la columna fecha al formato datetime
    df['fecha'] = pd.to_datetime(df['fecha'], format='%d/%m/%Y')
    
    # Agregar nuevas columnas
    df['dia'] = df['fecha'].dt.day
    df['mes'] = df['fecha'].dt.month
    df['año'] = df['fecha'].dt.year
    df['dia_semana'] = df['fecha'].dt.weekday + 1  # 1=Lunes, 7=Domingo
    df['es_fin_semana'] = df['dia_semana'].isin([6, 7])  # Sábado y Domingo
    
    # Agregar nombre del día de la semana para mejor visualización
    dias_nombres = {1: 'Lunes', 2: 'Martes', 3: 'Miércoles', 4: 'Jueves', 
                   5: 'Viernes', 6: 'Sábado', 7: 'Domingo'}
    df['nombre_dia'] = df['dia_semana'].map(dias_nombres)
    
    # Agregar nombre del mes
    meses_nombres = {1: 'Enero', 2: 'Febrero', 3: 'Marzo', 4: 'Abril',
                    5: 'Mayo', 6: 'Junio', 7: 'Julio', 8: 'Agosto',
                    9: 'Septiembre', 10: 'Octubre', 11: 'Noviembre', 12: 'Diciembre'}
    df['nombre_mes'] = df['mes'].map(meses_nombres)
    
    return df

def grafico_fin_semana_vs_laborales(df):
    """
    Compara montos gastados en fin de semana vs días laborales
    """
    plt.figure(figsize=(12, 6))
    
    # Subplot 1: Box plot
    plt.subplot(1, 2, 1)
    df_plot = df.copy()
    df_plot['tipo_dia'] = df_plot['es_fin_semana'].map({True: 'Fin de Semana', False: 'Días Laborales'})
    sns.boxplot(data=df_plot, x='tipo_dia', y='monto')
    plt.title('Distribución de Montos: Fin de Semana vs Días Laborales')
    plt.ylabel('Monto')
    
    # Subplot 2: Bar plot con totales
    plt.subplot(1, 2, 2)
    totales = df.groupby('es_fin_semana')['monto'].sum()
    etiquetas = ['Días Laborales', 'Fin de Semana']
    plt.bar(etiquetas, [totales[False], totales[True]], color=['skyblue', 'lightcoral'])
    plt.title('Total Gastado: Fin de Semana vs Días Laborales')
    plt.ylabel('Monto Total')
    
    # Agregar valores en las barras
    for i, v in enumerate([totales[False], totales[True]]):
        plt.text(i, v + max(totales) * 0.01, f'${v:,.0f}', ha='center', va='bottom')
    
    plt.tight_layout()
    plt.show()

def grafico_por_mes(df):
    """
    Gráfico de montos totales por mes
    """
    plt.figure(figsize=(14, 8))
    
    montos_mes = df.groupby(['año', 'mes', 'nombre_mes'])['monto'].sum().reset_index()
    
    años_unicos = sorted(df['año'].unique())
    
    if len(años_unicos) > 1:
        # Si hay múltiples años, crear subplots
        fig, axes = plt.subplots(len(años_unicos), 1, figsize=(14, 6*len(años_unicos)))
        if len(años_unicos) == 1:
            axes = [axes]
        
        for i, año in enumerate(años_unicos):
            data_año = montos_mes[montos_mes['año'] == año].sort_values('mes')
            axes[i].bar(data_año['nombre_mes'], data_año['monto'], color=plt.cm.Set3(np.arange(len(data_año))))
            axes[i].set_title(f'Montos Totales por Mes - {año}')
            axes[i].set_ylabel('Monto Total')
            axes[i].tick_params(axis='x', rotation=45)
            
            # Estadísticas
            media = data_año['monto'].mean()
            mediana = data_año['monto'].median()
            std = data_año['monto'].std()
            
            axes[i].axhline(y=media, color='red', linestyle='--', alpha=0.7, label=f'Media: ${media:,.0f}')
            axes[i].axhline(y=mediana, color='green', linestyle='--', alpha=0.7, label=f'Mediana: ${mediana:,.0f}')
            axes[i].legend()
            
            # Texto con estadísticas
            axes[i].text(0.02, 0.98, f'Desv. Std: ${std:,.0f}', transform=axes[i].transAxes, 
                        verticalalignment='top', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
    else:
        # Un solo año
        data_año = montos_mes.sort_values('mes')
        plt.bar(data_año['nombre_mes'], data_año['monto'], color=plt.cm.Set3(np.arange(len(data_año))))
        plt.title(f'Montos Totales por Mes - {años_unicos[0]}')
        plt.ylabel('Monto Total')
        plt.xticks(rotation=45)
        
        # Estadísticas
        media = data_año['monto'].mean()
        mediana = data_año['monto'].median()
        std = data_año['monto'].std()
        
        plt.axhline(y=media, color='red', linestyle='--', alpha=0.7, label=f'Media: ${media:,.0f}')
        plt.axhline(y=mediana, color='green', linestyle='--', alpha=0.7, label=f'Mediana: ${mediana:,.0f}')
        plt.legend()
        
        plt.text(0.02, 0.98, f'Desv. Std: ${std:,.0f}', transform=plt.gca().transAxes, 
                verticalalignment='top', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
    
    plt.tight_layout()
    plt.show()

def grafico_por_dia_semana(df):
    """
    Gráfico de montos por día de la semana
    """
    plt.figure(figsize=(12, 8))
    
    montos_dia = df.groupby(['dia_semana', 'nombre_dia'])['monto'].sum().reset_index()
    montos_dia = montos_dia.sort_values('dia_semana')
    
    colores = ['lightblue' if x <= 5 else 'lightcoral' for x in montos_dia['dia_semana']]
    
    plt.bar(montos_dia['nombre_dia'], montos_dia['monto'], color=colores)
    plt.title('Montos Totales por Día de la Semana')
    plt.ylabel('Monto Total')
    plt.xlabel('Día de la Semana')
    plt.xticks(rotation=45)
    
    # Estadísticas
    media = montos_dia['monto'].mean()
    mediana = montos_dia['monto'].median()
    std = montos_dia['monto'].std()
    
    plt.axhline(y=media, color='red', linestyle='--', alpha=0.7, label=f'Media: ${media:,.0f}')
    plt.axhline(y=mediana, color='green', linestyle='--', alpha=0.7, label=f'Mediana: ${mediana:,.0f}')
    plt.legend()
    
    plt.text(0.02, 0.98, f'Desv. Std: ${std:,.0f}', transform=plt.gca().transAxes, 
            verticalalignment='top', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
    
    plt.tight_layout()
    plt.show()

def grafico_por_dias_del_mes(df):
    """
    Gráfico de montos por días del mes, separado por año
    """
    años_unicos = sorted(df['año'].unique())
    
    fig, axes = plt.subplots(len(años_unicos), 1, figsize=(15, 6*len(años_unicos)))
    if len(años_unicos) == 1:
        axes = [axes]
    
    for i, año in enumerate(años_unicos):
        data_año = df[df['año'] == año]
        montos_dia = data_año.groupby('dia')['monto'].sum().reset_index()
        
        axes[i].bar(montos_dia['dia'], montos_dia['monto'], color='lightgreen', alpha=0.7)
        axes[i].set_title(f'Montos Totales por Día del Mes - {año}')
        axes[i].set_ylabel('Monto Total')
        axes[i].set_xlabel('Día del Mes')
        axes[i].set_xticks(range(1, 32, 2))
        
        # Estadísticas
        media = montos_dia['monto'].mean()
        mediana = montos_dia['monto'].median()
        std = montos_dia['monto'].std()
        
        axes[i].axhline(y=media, color='red', linestyle='--', alpha=0.7, label=f'Media: ${media:,.0f}')
        axes[i].axhline(y=mediana, color='green', linestyle='--', alpha=0.7, label=f'Mediana: ${mediana:,.0f}')
        axes[i].legend()
        
        axes[i].text(0.02, 0.98, f'Desv. Std: ${std:,.0f}', transform=axes[i].transAxes, 
                    verticalalignment='top', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
    
    plt.tight_layout()
    plt.show()

def grafico_por_semanas(df):
    """
    Gráfico de montos por semanas del año
    """
    # Agregar número de semana
    df['semana'] = df['fecha'].dt.isocalendar().week
    
    años_unicos = sorted(df['año'].unique())
    
    fig, axes = plt.subplots(len(años_unicos), 1, figsize=(15, 6*len(años_unicos)))
    if len(años_unicos) == 1:
        axes = [axes]
    
    for i, año in enumerate(años_unicos):
        data_año = df[df['año'] == año]
        montos_semana = data_año.groupby('semana')['monto'].sum().reset_index()
        
        axes[i].plot(montos_semana['semana'], montos_semana['monto'], marker='o', linewidth=2, markersize=4)
        axes[i].set_title(f'Montos Totales por Semana del Año - {año}')
        axes[i].set_ylabel('Monto Total')
        axes[i].set_xlabel('Semana del Año')
        axes[i].grid(True, alpha=0.3)
        
        # Estadísticas
        media = montos_semana['monto'].mean()
        mediana = montos_semana['monto'].median()
        std = montos_semana['monto'].std()
        
        axes[i].axhline(y=media, color='red', linestyle='--', alpha=0.7, label=f'Media: ${media:,.0f}')
        axes[i].axhline(y=mediana, color='green', linestyle='--', alpha=0.7, label=f'Mediana: ${mediana:,.0f}')
        axes[i].legend()
        
        axes[i].text(0.02, 0.98, f'Desv. Std: ${std:,.0f}', transform=axes[i].transAxes, 
                    verticalalignment='top', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
    
    plt.tight_layout()
    plt.show()

def resumen_estadisticas(df):
    """
    Muestra un resumen de estadísticas generales
    """
    print("="*60)
    print("RESUMEN ESTADÍSTICO DE TRANSACCIONES BANCARIAS")
    print("="*60)
    
    print(f"Período analizado: {df['fecha'].min().strftime('%d/%m/%Y')} - {df['fecha'].max().strftime('%d/%m/%Y')}")
    print(f"Total de transacciones: {len(df):,}")
    print(f"Número de clientes únicos: {df['ID'].nunique():,}")
    print(f"Monto total transaccionado: ${df['monto'].sum():,.2f}")
    print(f"Monto promedio por transacción: ${df['monto'].mean():.2f}")
    print(f"Monto mediano: ${df['monto'].median():.2f}")
    print(f"Desviación estándar: ${df['monto'].std():.2f}")
    
    print("\n" + "-"*40)
    print("ANÁLISIS POR TIPO DE DÍA:")
    print("-"*40)
    
    fin_semana = df[df['es_fin_semana'] == True]['monto'].sum()
    laborales = df[df['es_fin_semana'] == False]['monto'].sum()
    
    print(f"Total en días laborales: ${laborales:,.2f} ({laborales/(fin_semana+laborales)*100:.1f}%)")
    print(f"Total en fin de semana: ${fin_semana:,.2f} ({fin_semana/(fin_semana+laborales)*100:.1f}%)")
    
    print("\n" + "-"*40)
    print("TOP 5 DÍAS CON MAYOR ACTIVIDAD:")
    print("-"*40)
    
    actividad_dia = df.groupby('fecha')['monto'].agg(['sum', 'count']).sort_values('sum', ascending=False).head()
    for fecha, (monto, transacciones) in actividad_dia.iterrows():
        print(f"{fecha.strftime('%d/%m/%Y')}: ${monto:,.2f} ({transacciones} transacciones)")

def main():
    """
    Función principal que ejecuta todo el análisis
    """
    # Cambiar 'archivo.csv' por el nombre de tu archivo
    archivo_csv = 'base_transacciones_final_fechas_convertidas.csv'  # CAMBIAR POR TU ARCHIVO
    
    try:
        # Cargar y procesar datos
        print("Cargando y procesando datos...")
        df = cargar_y_procesar_datos(archivo_csv)
        
        # Mostrar resumen estadístico
        resumen_estadisticas(df)
        
        # Generar gráficos
        print("\nGenerando gráficos...")
        
        print("1. Comparación fin de semana vs días laborales...")
        grafico_fin_semana_vs_laborales(df)
        
        print("2. Análisis por mes...")
        grafico_por_mes(df)
        
        print("3. Análisis por día de la semana...")
        grafico_por_dia_semana(df)
        
        print("4. Análisis por días del mes...")
        grafico_por_dias_del_mes(df)
        
        print("5. Análisis por semanas...")
        grafico_por_semanas(df)
        
        print("\n¡Análisis completado!")
        
        # Mostrar las primeras filas del dataframe procesado
        print("\nPrimeras filas del dataset procesado:")
        print(df.head())
        
    except FileNotFoundError:
        print(f"Error: No se pudo encontrar el archivo '{archivo_csv}'")
        print("Asegúrate de que el archivo existe en el directorio actual")
    except Exception as e:
        print(f"Error al procesar el archivo: {str(e)}")

if __name__ == "__main__":
    main()