import pandas as pd
import matplotlib.pyplot as plt

def detectar_duplicados(archivo_csv):
    """
    Detecta filas duplicadas en un CSV y muestra qué IDs están repetidos
    """
    try:
        # Leer el CSV
        df = pd.read_csv(archivo_csv)
        print(f"Archivo cargado: {archivo_csv}")
        print(f"Dimensiones: {df.shape[0]} filas x {df.shape[1]} columnas\n")
        
        nombre_id = df.columns[0]  # Primera columna como ID
        
        # === ANÁLISIS DE DUPLICADOS COMPLETOS ===
        print("=== ANÁLISIS DE FILAS COMPLETAMENTE DUPLICADAS ===")
        print("-" * 60)
        
        # Encontrar filas completamente duplicadas
        duplicados_completos = df.duplicated(keep=False)
        filas_duplicadas = df[duplicados_completos]
        
        if len(filas_duplicadas) > 0:
            print(f"Se encontraron {len(filas_duplicadas)} filas duplicadas")
            
            # Agrupar por contenido duplicado
            grupos_duplicados = df[duplicados_completos].groupby(df.columns.tolist()).size()
            
            print(f"Número de grupos de duplicados: {len(grupos_duplicados)}")
            
            print("\nIDs con filas completamente duplicadas:")
            ids_duplicados = filas_duplicadas[nombre_id].tolist()
            for i, id_val in enumerate(ids_duplicados):
                print(f"  - ID: {id_val}")
            
            # Mostrar ejemplos de duplicados
            print(f"\n--- EJEMPLOS DE FILAS DUPLICADAS ---")
            for grupo_idx, (_, grupo) in enumerate(df[duplicados_completos].groupby(df.columns.tolist())):
                if grupo_idx < 3:  # Mostrar solo los primeros 3 grupos
                    ids_grupo = grupo[nombre_id].tolist()
                    print(f"Grupo {grupo_idx + 1}: IDs {ids_grupo} (aparece {len(grupo)} veces)")
        else:
            print("✅ No se encontraron filas completamente duplicadas")
        
        # === ANÁLISIS DE IDs REPETIDOS ===
        print(f"\n=== ANÁLISIS DE IDs REPETIDOS ===")
        print("-" * 60)
        
        conteo_ids = df[nombre_id].value_counts()
        ids_repetidos = conteo_ids[conteo_ids > 1]
        
        if len(ids_repetidos) > 0:
            print(f"Se encontraron {len(ids_repetidos)} IDs repetidos:")
            print(f"Total de filas con IDs repetidos: {ids_repetidos.sum()}")
            
            print(f"\nTop 10 IDs más repetidos:")
            for id_val, cantidad in ids_repetidos.head(10).items():
                print(f"  ID: {id_val} | Aparece {cantidad} veces")
            
            # Mostrar detalles de algunos IDs repetidos
            print(f"\n--- DETALLES DE IDs REPETIDOS ---")
            for i, (id_val, cantidad) in enumerate(ids_repetidos.head(3).items()):
                print(f"\nID: {id_val} (aparece {cantidad} veces):")
                filas_id = df[df[nombre_id] == id_val]
                
                # Verificar si las filas son idénticas o diferentes
                if len(filas_id.drop_duplicates()) == 1:
                    print("  → Todas las filas son IDÉNTICAS")
                else:
                    print("  → Las filas tienen DIFERENCIAS")
                    print("  Columnas que varían:")
                    for col in df.columns[1:]:  # Excluir la columna ID
                        valores_unicos = filas_id[col].nunique()
                        if valores_unicos > 1:
                            print(f"    - {col}: {valores_unicos} valores diferentes")
        else:
            print("✅ No se encontraron IDs repetidos")
        
        # === ANÁLISIS PARCIAL (excluir la columna ID) ===
        print(f"\n=== ANÁLISIS DE CONTENIDO DUPLICADO (sin considerar ID) ===")
        print("-" * 60)
        
        df_sin_id = df.drop(columns=[nombre_id])
        duplicados_sin_id = df_sin_id.duplicated(keep=False)
        
        if duplicados_sin_id.any():
            filas_contenido_duplicado = df[duplicados_sin_id]
            print(f"Se encontraron {len(filas_contenido_duplicado)} filas con contenido duplicado")
            
            print("IDs con contenido duplicado (mismo contenido, diferente ID):")
            for id_val in filas_contenido_duplicado[nombre_id].head(10):
                print(f"  - ID: {id_val}")
        else:
            print("✅ No se encontró contenido duplicado")
        
        # Crear gráficas
        crear_graficas_duplicados(ids_repetidos, duplicados_completos.sum(), len(df))
        
        return {
            'ids_repetidos': ids_repetidos,
            'filas_duplicadas_completas': len(filas_duplicadas),
            'total_filas': len(df)
        }
        
    except FileNotFoundError:
        print(f"Error: No se encontró el archivo '{archivo_csv}'")
        print("Asegúrate de que el archivo esté en el directorio correcto.")
    except Exception as e:
        print(f"Error al procesar el archivo: {e}")

def crear_graficas_duplicados(ids_repetidos, filas_duplicadas, total_filas):
    """
    Crea gráficas para visualizar los duplicados
    """
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
    
    # Gráfica 1: Resumen general
    categorias = ['Filas únicas', 'Filas duplicadas']
    valores = [total_filas - filas_duplicadas, filas_duplicadas]
    colores = ['lightgreen', 'salmon']
    
    wedges, texts, autotexts = ax1.pie(valores, labels=categorias, autopct='%1.1f%%', 
                                       colors=colores, startangle=90)
    ax1.set_title('Distribución de Filas Duplicadas', fontweight='bold')
    
    # Gráfica 2: Top IDs repetidos
    if len(ids_repetidos) > 0:
        top_ids = ids_repetidos.head(10)
        bars = ax2.bar(range(len(top_ids)), top_ids.values, 
                      color='orange', alpha=0.7, edgecolor='darkorange')
        
        ax2.set_title('Top 10 IDs Más Repetidos', fontweight='bold')
        ax2.set_xlabel('IDs')
        ax2.set_ylabel('Número de Repeticiones')
        ax2.set_xticks(range(len(top_ids)))
        ax2.set_xticklabels([str(id_val)[:10] + '...' if len(str(id_val)) > 10 
                            else str(id_val) for id_val in top_ids.index], 
                           rotation=45, ha='right')
        
        # Agregar valores en las barras
        for bar in bars:
            height = bar.get_height()
            ax2.text(bar.get_x() + bar.get_width()/2., height + 0.1,
                    f'{int(height)}', ha='center', va='bottom')
        
        ax2.grid(axis='y', alpha=0.3)
    else:
        ax2.text(0.5, 0.5, 'No hay IDs repetidos', 
                horizontalalignment='center', verticalalignment='center',
                transform=ax2.transAxes, fontsize=14)
        ax2.set_title('IDs Repetidos', fontweight='bold')
    
    plt.tight_layout()
    plt.show()

# Ejemplo de uso
if __name__ == "__main__":
    # Cambiar por el nombre de tu archivo CSV
    archivo = "base_clientes_final.csv"
    
    print("=== DETECTOR DE DUPLICADOS EN CSV ===\n")
    
    # Ejecutar análisis
    resultado = detectar_duplicados(archivo)
    
    print(f"\n=== ANÁLISIS COMPLETADO ===")
    print("Las gráficas se han generado y mostrado.")