import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from collections import Counter

def analizar_actividades_empresariales(archivo_csv):
    """
    Analiza las actividades empresariales de un archivo CSV
    
    Args:
        archivo_csv (str): Ruta del archivo CSV
    """
    try:
        # Leer el archivo CSV
        df = pd.read_csv(archivo_csv)
        
        # Verificar que existe la columna
        if 'actividad_empresarial' not in df.columns:
            print("Error: La columna 'actividad_empresarial' no existe en el archivo.")
            print("Columnas disponibles:", list(df.columns))
            return
        
        # Limpiar datos (remover valores nulos y espacios en blanco)
        actividades = df['actividad_empresarial'].dropna().str.strip()
        
        # Contar frecuencias
        frecuencias = actividades.value_counts()
        
        # Mostrar resultados
        print("=== ANÁLISIS DE ACTIVIDADES EMPRESARIALES ===\n")
        print(f"Total de registros: {len(df)}")
        print(f"Registros con actividad empresarial válida: {len(actividades)}")
        print(f"Número de actividades únicas: {len(frecuencias)}")
        print(f"Registros sin actividad (nulos/vacíos): {len(df) - len(actividades)}\n")
        
        print("=== FRECUENCIA DE ACTIVIDADES ===")
        for i, (actividad, freq) in enumerate(frecuencias.items(), 1):
            porcentaje = (freq / len(actividades)) * 100
            print(f"{i:2d}. {actividad:<40} | {freq:4d} ({porcentaje:5.1f}%)")
        
        # Estadísticas adicionales
        print(f"\n=== ESTADÍSTICAS ===")
        print(f"Actividad más común: {frecuencias.index[0]} ({frecuencias.iloc[0]} veces)")
        print(f"Actividades que aparecen solo una vez: {sum(frecuencias == 1)}")
        print(f"Frecuencia promedio: {frecuencias.mean():.2f}")
        print(f"Frecuencia mediana: {frecuencias.median():.2f}")
        
        # Crear visualización
        crear_graficos(frecuencias, actividades)
        
        return frecuencias
        
    except FileNotFoundError:
        print(f"Error: No se pudo encontrar el archivo '{archivo_csv}'")
    except Exception as e:
        print(f"Error al procesar el archivo: {e}")

def crear_graficos(frecuencias, actividades):
    """
    Crea gráficos para visualizar los datos
    """
    plt.style.use('seaborn-v0_8')
    fig, axes = plt.subplots(2, 2, figsize=(15, 12))
    fig.suptitle('Análisis de Actividades Empresariales', fontsize=16, fontweight='bold')
    
    # Gráfico 1: Top 10 actividades más comunes
    top_10 = frecuencias.head(10)
    axes[0,0].barh(range(len(top_10)), top_10.values)
    axes[0,0].set_yticks(range(len(top_10)))
    axes[0,0].set_yticklabels(top_10.index, fontsize=8)
    axes[0,0].set_xlabel('Frecuencia')
    axes[0,0].set_title('Top 10 Actividades Más Comunes')
    axes[0,0].invert_yaxis()
    
    # Gráfico 2: Distribución de frecuencias
    axes[0,1].hist(frecuencias.values, bins=20, alpha=0.7, color='skyblue', edgecolor='black')
    axes[0,1].set_xlabel('Frecuencia')
    axes[0,1].set_ylabel('Número de Actividades')
    axes[0,1].set_title('Distribución de Frecuencias')
    
    # Gráfico 3: Pie chart de top 5 + otros
    top_5 = frecuencias.head(5)
    otros = frecuencias.iloc[5:].sum()
    
    labels = list(top_5.index) + ['Otros']
    sizes = list(top_5.values) + [otros]
    
    axes[1,0].pie(sizes, labels=labels, autopct='%1.1f%%', startangle=90)
    axes[1,0].set_title('Distribución Porcentual (Top 5 + Otros)')
    
    # Gráfico 4: Actividades por rango de frecuencia
    rangos = ['1 vez', '2-5 veces', '6-10 veces', '11-50 veces', '50+ veces']
    conteos = [
        sum(frecuencias == 1),
        sum((frecuencias >= 2) & (frecuencias <= 5)),
        sum((frecuencias >= 6) & (frecuencias <= 10)),
        sum((frecuencias >= 11) & (frecuencias <= 50)),
        sum(frecuencias > 50)
    ]
    
    axes[1,1].bar(rangos, conteos, color=['#ff9999', '#66b3ff', '#99ff99', '#ffcc99', '#ff99cc'])
    axes[1,1].set_ylabel('Número de Actividades')
    axes[1,1].set_title('Actividades por Rango de Frecuencia')
    axes[1,1].tick_params(axis='x', rotation=45)
    
    plt.tight_layout()
    plt.show()

def exportar_resultados(frecuencias, archivo_salida='actividades_analisis.csv'):
    """
    Exporta los resultados a un archivo CSV
    """
    resultado_df = pd.DataFrame({
        'actividad_empresarial': frecuencias.index,
        'frecuencia': frecuencias.values,
        'porcentaje': (frecuencias.values / frecuencias.sum()) * 100
    })
    
    resultado_df.to_csv(archivo_salida, index=False, encoding='utf-8')
    print(f"\nResultados exportados a: {archivo_salida}")

# Ejemplo de uso
if __name__ == "__main__":
    # Cambiar por la ruta de tu archivo CSV
    archivo = "base_clientes_final.csv"  # Reemplaza con la ruta de tu archivo
    
    print("Iniciando análisis de actividades empresariales...")
    frecuencias = analizar_actividades_empresariales(archivo)
    
    if frecuencias is not None:
        # Exportar resultados (opcional)
        exportar_resultados(frecuencias)
        
        # Mostrar algunas consultas adicionales
        print("\n=== CONSULTAS ADICIONALES ===")
        
        # Buscar actividades específicas
        buscar_actividad = input("\n¿Quieres buscar una actividad específica? (Enter para saltar): ").strip()
        if buscar_actividad:
            resultados = frecuencias[frecuencias.index.str.contains(buscar_actividad, case=False, na=False)]
            if not resultados.empty:
                print(f"\nActividades que contienen '{buscar_actividad}':")
                for actividad, freq in resultados.items():
                    print(f"- {actividad}: {freq} veces")
            else:
                print(f"No se encontraron actividades que contengan '{buscar_actividad}'")