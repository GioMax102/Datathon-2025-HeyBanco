import pandas as pd
from datetime import datetime
import os

def convertir_fechas_csv(archivo_entrada, archivo_salida=None, columna_fecha='fecha'):
    """
    Convierte el formato de fechas de dd/mm/aaaa a aaaa-mm-dd en un archivo CSV
    
    Parámetros:
    - archivo_entrada: ruta del archivo CSV original
    - archivo_salida: ruta del archivo CSV de salida (opcional)
    - columna_fecha: nombre de la columna que contiene las fechas
    """
    
    try:
        # Leer el archivo CSV original
        print(f"Leyendo archivo: {archivo_entrada}")
        df = pd.read_csv(archivo_entrada)
        
        # Verificar que la columna de fecha existe
        if columna_fecha not in df.columns:
            print(f"Error: La columna '{columna_fecha}' no existe en el archivo.")
            print(f"Columnas disponibles: {list(df.columns)}")
            return False
        
        # Mostrar información inicial
        print(f"Archivo cargado exitosamente.")
        print(f"Total de filas: {len(df)}")
        print(f"Columnas: {list(df.columns)}")
        print(f"\nPrimeras 5 fechas originales:")
        print(df[columna_fecha].head())
        
        # Crear una copia de seguridad del DataFrame original
        df_original = df.copy()
        
        # Convertir las fechas del formato dd/mm/aaaa al formato datetime
        print(f"\nConvirtiendo fechas de la columna '{columna_fecha}'...")
        
        # Manejar posibles errores en la conversión
        fechas_convertidas = []
        errores = []
        
        for i, fecha_str in enumerate(df[columna_fecha]):
            try:
                # Convertir de string dd/mm/aaaa a datetime
                fecha_dt = pd.to_datetime(fecha_str, format='%d/%m/%Y')
                # Convertir a formato aaaa-mm-dd
                fecha_nueva = fecha_dt.strftime('%Y-%m-%d')
                fechas_convertidas.append(fecha_nueva)
            except Exception as e:
                errores.append((i, fecha_str, str(e)))
                fechas_convertidas.append(fecha_str)  # Mantener original si hay error
        
        # Actualizar el DataFrame con las nuevas fechas
        df[columna_fecha] = fechas_convertidas
        
        # Mostrar resultados de la conversión
        print(f"Conversión completada.")
        print(f"Fechas convertidas exitosamente: {len(df) - len(errores)}")
        
        if errores:
            print(f"Errores encontrados: {len(errores)}")
            print("Primeros 5 errores:")
            for i, (fila, fecha_orig, error) in enumerate(errores[:5]):
                print(f"  Fila {fila}: '{fecha_orig}' - {error}")
        
        print(f"\nPrimeras 5 fechas convertidas:")
        print(df[columna_fecha].head())
        
        # Determinar el nombre del archivo de salida
        if archivo_salida is None:
            # Crear nombre automático
            nombre_base = os.path.splitext(archivo_entrada)[0]
            extension = os.path.splitext(archivo_entrada)[1]
            archivo_salida = f"{nombre_base}_fechas_convertidas{extension}"
        
        # Guardar el archivo modificado
        print(f"\nGuardando archivo convertido como: {archivo_salida}")
        df.to_csv(archivo_salida, index=False)
        
        # Verificación final
        print(f"Archivo guardado exitosamente.")
        print(f"El archivo original '{archivo_entrada}' se mantiene sin cambios.")
        
        # Mostrar comparación antes/después
        print(f"\n{'='*60}")
        print("COMPARACIÓN ANTES/DESPUÉS")
        print(f"{'='*60}")
        print("ANTES (primeras 10 filas):")
        print(df_original[[columna_fecha]].head(10))
        print("\nDESPUÉS (primeras 10 filas):")
        print(df[[columna_fecha]].head(10))
        
        return True
        
    except FileNotFoundError:
        print(f"Error: No se pudo encontrar el archivo '{archivo_entrada}'")
        print("Asegúrate de que el archivo existe y la ruta es correcta.")
        return False
    
    except Exception as e:
        print(f"Error inesperado: {str(e)}")
        return False

def verificar_conversion(archivo_original, archivo_convertido, columna_fecha='fecha'):
    """
    Verifica que la conversión se haya realizado correctamente
    """
    try:
        print(f"\n{'='*60}")
        print("VERIFICACIÓN DE LA CONVERSIÓN")
        print(f"{'='*60}")
        
        # Leer ambos archivos
        df_original = pd.read_csv(archivo_original)
        df_convertido = pd.read_csv(archivo_convertido)
        
        print(f"Archivo original: {len(df_original)} filas")
        print(f"Archivo convertido: {len(df_convertido)} filas")
        
        # Verificar que tienen el mismo número de filas
        if len(df_original) != len(df_convertido):
            print("⚠️  ADVERTENCIA: Los archivos tienen diferente número de filas")
        
        # Verificar algunas conversiones
        print(f"\nVerificación de conversiones aleatorias:")
        import random
        indices = random.sample(range(min(len(df_original), 10)), min(5, len(df_original)))
        
        for i in indices:
            fecha_orig = df_original.iloc[i][columna_fecha]
            fecha_conv = df_convertido.iloc[i][columna_fecha]
            
            try:
                # Verificar que la conversión es correcta
                fecha_dt = pd.to_datetime(fecha_orig, format='%d/%m/%Y')
                fecha_esperada = fecha_dt.strftime('%Y-%m-%d')
                
                if fecha_conv == fecha_esperada:
                    status = "✅"
                else:
                    status = "❌"
                
                print(f"  Fila {i}: {fecha_orig} → {fecha_conv} {status}")
                
            except:
                print(f"  Fila {i}: {fecha_orig} → {fecha_conv} ⚠️  (no se pudo verificar)")
        
        # Verificar formato del archivo convertido
        print(f"\nVerificación de formato en archivo convertido:")
        fechas_correctas = 0
        fechas_incorrectas = 0
        
        for fecha in df_convertido[columna_fecha].head(100):  # Verificar primeras 100
            try:
                # Intentar parsear como YYYY-MM-DD
                datetime.strptime(fecha, '%Y-%m-%d')
                fechas_correctas += 1
            except:
                fechas_incorrectas += 1
        
        print(f"  Fechas en formato correcto (YYYY-MM-DD): {fechas_correctas}")
        print(f"  Fechas en formato incorrecto: {fechas_incorrectas}")
        
        if fechas_incorrectas == 0:
            print("✅ Todas las fechas verificadas están en el formato correcto")
        else:
            print("⚠️  Algunas fechas no están en el formato esperado")
            
    except Exception as e:
        print(f"Error durante la verificación: {str(e)}")

def main():
    """
    Función principal
    """
    print("="*60)
    print("CONVERTIDOR DE FORMATO DE FECHAS EN CSV")
    print("Convierte fechas de dd/mm/aaaa a aaaa-mm-dd")
    print("="*60)
    
    # Configuración
    archivo_entrada = 'base_transacciones_final.csv'  # CAMBIAR POR TU ARCHIVO
    archivo_salida = None  # Se generará automáticamente
    columna_fecha = 'fecha'  # CAMBIAR SI TU COLUMNA TIENE OTRO NOMBRE
    
    print(f"Archivo de entrada: {archivo_entrada}")
    print(f"Columna de fecha: {columna_fecha}")
    
    # Realizar la conversión
    exito = convertir_fechas_csv(archivo_entrada, archivo_salida, columna_fecha)
    
    if exito:
        # Generar nombre del archivo de salida para verificación
        nombre_base = os.path.splitext(archivo_entrada)[0]
        extension = os.path.splitext(archivo_entrada)[1]
        archivo_salida_generado = f"{nombre_base}_fechas_convertidas{extension}"
        
        # Verificar la conversión
        verificar_conversion(archivo_entrada, archivo_salida_generado, columna_fecha)
        
        print(f"\n{'='*60}")
        print("PROCESO COMPLETADO EXITOSAMENTE")
        print(f"{'='*60}")
        print(f"✅ Archivo original: {archivo_entrada}")
        print(f"✅ Archivo convertido: {archivo_salida_generado}")
        print("✅ Las fechas han sido convertidas de dd/mm/aaaa a aaaa-mm-dd")
        
    else:
        print(f"\n{'='*60}")
        print("PROCESO FALLÓ")
        print(f"{'='*60}")
        print("❌ No se pudo completar la conversión")
        print("Revisa los errores mostrados arriba")

# Función adicional para uso personalizado
def convertir_archivo_personalizado():
    """
    Función interactiva para especificar archivos personalizados
    """
    print("\n" + "="*60)
    print("CONVERSIÓN PERSONALIZADA")
    print("="*60)
    
    archivo_entrada = input("Ingresa el nombre del archivo CSV de entrada: ").strip()
    if not archivo_entrada:
        archivo_entrada = 'transacciones.csv'
    
    columna_fecha = input("Ingresa el nombre de la columna de fecha (default: 'fecha'): ").strip()
    if not columna_fecha:
        columna_fecha = 'fecha'
    
    archivo_salida = input("Ingresa el nombre del archivo de salida (presiona Enter para auto-generar): ").strip()
    if not archivo_salida:
        archivo_salida = None
    
    print(f"\nConfiguración:")
    print(f"  Archivo entrada: {archivo_entrada}")
    print(f"  Columna fecha: {columna_fecha}")
    print(f"  Archivo salida: {archivo_salida if archivo_salida else 'Auto-generado'}")
    
    confirmacion = input("\n¿Proceder con la conversión? (s/n): ").strip().lower()
    
    if confirmacion in ['s', 'si', 'sí', 'y', 'yes']:
        convertir_fechas_csv(archivo_entrada, archivo_salida, columna_fecha)
    else:
        print("Conversión cancelada.")

if __name__ == "__main__":
    # Ejecutar conversión automática
    main()
    
    # Opción para conversión personalizada
    print(f"\n{'-'*60}")
    personalizada = input("¿Quieres hacer otra conversión con parámetros personalizados? (s/n): ").strip().lower()
    if personalizada in ['s', 'si', 'sí', 'y', 'yes']:
        convertir_archivo_personalizado()