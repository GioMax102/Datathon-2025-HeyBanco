import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from datetime import datetime

def analizar_clientes_transacciones(archivo_clientes, archivo_transacciones, archivo_salida=None):
    """
    Compara CSVs de clientes y transacciones, encuentra coincidencias y crea archivo combinado
    """
    try:
        # Leer los archivos CSV
        print("Cargando archivos...")
        df_clientes = pd.read_csv(archivo_clientes)
        df_transacciones = pd.read_csv(archivo_transacciones)
        
        print(f"✅ Clientes cargados: {len(df_clientes)} registros")
        print(f"✅ Transacciones cargadas: {len(df_transacciones)} registros\n")
        
        # Obtener nombres de columnas ID (primera columna de cada archivo)
        id_clientes = df_clientes.columns[0]
        id_transacciones = df_transacciones.columns[0]
        
        print(f"Columna ID clientes: '{id_clientes}'")
        print(f"Columna ID transacciones: '{id_transacciones}'\n")
        
        # Obtener sets de IDs únicos
        ids_clientes_unicos = set(df_clientes[id_clientes].dropna().unique())
        ids_transacciones_unicos = set(df_transacciones[id_transacciones].dropna().unique())
        
        print("=== ANÁLISIS DE COINCIDENCIAS ===")
        print("-" * 50)
        
        # Encontrar intersecciones y diferencias
        clientes_con_transacciones = ids_clientes_unicos.intersection(ids_transacciones_unicos)
        clientes_sin_transacciones = ids_clientes_unicos - ids_transacciones_unicos
        transacciones_sin_cliente = ids_transacciones_unicos - ids_clientes_unicos
        
        print(f"📊 Total clientes únicos: {len(ids_clientes_unicos)}")
        print(f"📊 Total IDs únicos en transacciones: {len(ids_transacciones_unicos)}")
        print(f"✅ Clientes CON transacciones: {len(clientes_con_transacciones)}")
        print(f"❌ Clientes SIN transacciones: {len(clientes_sin_transacciones)}")
        print(f"⚠️  Transacciones sin cliente registrado: {len(transacciones_sin_cliente)}")
        
        # Mostrar algunos ejemplos
        if len(clientes_con_transacciones) > 0:
            print(f"\\n--- Ejemplos de clientes CON transacciones ---")
            ejemplos_con = list(clientes_con_transacciones)[:5]
            for cliente_id in ejemplos_con:
                num_transacciones = len(df_transacciones[df_transacciones[id_transacciones] == cliente_id])
                print(f"  ID: {cliente_id} | {num_transacciones} transacciones")
        
        if len(clientes_sin_transacciones) > 0:
            print(f"\\n--- Ejemplos de clientes SIN transacciones ---")
            ejemplos_sin = list(clientes_sin_transacciones)[:5]
            for cliente_id in ejemplos_sin:
                print(f"  ID: {cliente_id}")
        
        if len(transacciones_sin_cliente) > 0:
            print(f"\\n--- Ejemplos de transacciones SIN cliente registrado ---")
            ejemplos_trans = list(transacciones_sin_cliente)[:5]
            for trans_id in ejemplos_trans:
                num_transacciones = len(df_transacciones[df_transacciones[id_transacciones] == trans_id])
                print(f"  ID: {trans_id} | {num_transacciones} transacciones")
        
        # === CREAR ARCHIVO COMBINADO ===
        print(f"\\n=== CREANDO ARCHIVO COMBINADO ===")
        print("-" * 50)
        
        # Filtrar clientes que tienen transacciones
        clientes_activos = df_clientes[df_clientes[id_clientes].isin(clientes_con_transacciones)].copy()
        
        # Agregar estadísticas de transacciones a cada cliente
        estadisticas_trans = []
        
        for idx, cliente in clientes_activos.iterrows():
            cliente_id = cliente[id_clientes]
            transacciones_cliente = df_transacciones[df_transacciones[id_transacciones] == cliente_id]
            
            # Calcular estadísticas
            num_transacciones = len(transacciones_cliente)
            
            # Si hay columnas numéricas en transacciones, calcular estadísticas
            columnas_numericas = transacciones_cliente.select_dtypes(include=[np.number]).columns
            
            stats = {
                'num_transacciones': num_transacciones,
                'primera_transaccion': transacciones_cliente.index.min() if len(transacciones_cliente) > 0 else None,
                'ultima_transaccion': transacciones_cliente.index.max() if len(transacciones_cliente) > 0 else None
            }
            
            # Agregar estadísticas de columnas numéricas si existen
            if len(columnas_numericas) > 1:  # Más que solo el ID
                col_numerica = [col for col in columnas_numericas if col != id_transacciones][0]
                stats['total_monto'] = transacciones_cliente[col_numerica].sum()
                stats['promedio_monto'] = transacciones_cliente[col_numerica].mean()
                stats['monto_maximo'] = transacciones_cliente[col_numerica].max()
                stats['monto_minimo'] = transacciones_cliente[col_numerica].min()
            
            estadisticas_trans.append(stats)
        
        # Convertir estadísticas a DataFrame y combinar
        df_stats = pd.DataFrame(estadisticas_trans)
        df_combinado = pd.concat([clientes_activos.reset_index(drop=True), df_stats], axis=1)
        
        # Generar nombre de archivo si no se proporciona
        if archivo_salida is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            archivo_salida = f"clientes_con_transacciones_{timestamp}.csv"
        
        # Guardar archivo combinado
        df_combinado.to_csv(archivo_salida, index=False)
        
        print(f"✅ Archivo combinado creado: '{archivo_salida}'")
        print(f"📁 Registros en archivo combinado: {len(df_combinado)}")
        print(f"📋 Columnas totales: {len(df_combinado.columns)}")
        
        # Mostrar preview del archivo combinado
        print(f"\\n--- PREVIEW DEL ARCHIVO COMBINADO ---")
        print(df_combinado.head(3).to_string())
        
        # Crear visualizaciones
        crear_visualizaciones(len(ids_clientes_unicos), len(clientes_con_transacciones), 
                            len(clientes_sin_transacciones), len(transacciones_sin_cliente),
                            df_combinado if 'num_transacciones' in df_combinado.columns else None)
        
        return {
            'clientes_totales': len(ids_clientes_unicos),
            'clientes_con_transacciones': len(clientes_con_transacciones),
            'clientes_sin_transacciones': len(clientes_sin_transacciones),
            'transacciones_sin_cliente': len(transacciones_sin_cliente),
            'archivo_combinado': archivo_salida,
            'df_combinado': df_combinado
        }
        
    except FileNotFoundError as e:
        print(f"❌ Error: No se encontró el archivo: {e}")
        print("Verifica que ambos archivos CSV estén en el directorio correcto.")
    except Exception as e:
        print(f"❌ Error al procesar los archivos: {e}")

def crear_visualizaciones(total_clientes, con_trans, sin_trans, trans_sin_cliente, df_combinado):
    """
    Crea visualizaciones del análisis
    """
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    
    # Gráfica 1: Distribución de clientes
    labels_clientes = ['Con Transacciones', 'Sin Transacciones']
    sizes_clientes = [con_trans, sin_trans]
    colors_clientes = ['lightgreen', 'lightcoral']
    
    axes[0,0].pie(sizes_clientes, labels=labels_clientes, autopct='%1.1f%%', 
                  colors=colors_clientes, startangle=90)
    axes[0,0].set_title('Distribución de Clientes', fontweight='bold')
    
    # Gráfica 2: Resumen general
    categorias = ['Clientes\\nRegistrados', 'Clientes con\\nTransacciones', 
                 'Clientes sin\\nTransacciones', 'Transacciones\\nsin Cliente']
    valores = [total_clientes, con_trans, sin_trans, trans_sin_cliente]
    colores = ['skyblue', 'lightgreen', 'lightcoral', 'orange']
    
    bars = axes[0,1].bar(categorias, valores, color=colores, alpha=0.7)
    axes[0,1].set_title('Resumen General', fontweight='bold')
    axes[0,1].set_ylabel('Cantidad')
    
    # Agregar valores en las barras
    for bar in bars:
        height = bar.get_height()
        axes[0,1].text(bar.get_x() + bar.get_width()/2., height + max(valores)*0.01,
                      f'{int(height)}', ha='center', va='bottom')
    
    # Gráfica 3: Distribución de número de transacciones por cliente (si disponible)
    if df_combinado is not None and 'num_transacciones' in df_combinado.columns:
        axes[1,0].hist(df_combinado['num_transacciones'], bins=20, 
                      color='lightsalmon', alpha=0.7, edgecolor='darkred')
        axes[1,0].set_title('Distribución de Transacciones por Cliente', fontweight='bold')
        axes[1,0].set_xlabel('Número de Transacciones')
        axes[1,0].set_ylabel('Número de Clientes')
        axes[1,0].grid(axis='y', alpha=0.3)
    else:
        axes[1,0].text(0.5, 0.5, 'Datos de transacciones\\nno disponibles', 
                      ha='center', va='center', transform=axes[1,0].transAxes)
        axes[1,0].set_title('Distribución de Transacciones', fontweight='bold')
    
    # Gráfica 4: Top clientes por número de transacciones
    if df_combinado is not None and 'num_transacciones' in df_combinado.columns:
        top_clientes = df_combinado.nlargest(10, 'num_transacciones')
        id_col = df_combinado.columns[0]
        
        bars = axes[1,1].bar(range(len(top_clientes)), top_clientes['num_transacciones'], 
                            color='gold', alpha=0.7, edgecolor='orange')
        axes[1,1].set_title('Top 10 Clientes por Transacciones', fontweight='bold')
        axes[1,1].set_xlabel('Clientes')
        axes[1,1].set_ylabel('Número de Transacciones')
        
        # Etiquetas de clientes (truncadas)
        labels = [str(id_val)[:8] + '...' if len(str(id_val)) > 8 else str(id_val) 
                 for id_val in top_clientes[id_col]]
        axes[1,1].set_xticks(range(len(top_clientes)))
        axes[1,1].set_xticklabels(labels, rotation=45, ha='right')
        
        # Valores en barras
        for i, bar in enumerate(bars):
            height = bar.get_height()
            axes[1,1].text(bar.get_x() + bar.get_width()/2., height + 0.1,
                          f'{int(height)}', ha='center', va='bottom')
    else:
        axes[1,1].text(0.5, 0.5, 'Top clientes\\nno disponible', 
                      ha='center', va='center', transform=axes[1,1].transAxes)
        axes[1,1].set_title('Top Clientes', fontweight='bold')
    
    plt.tight_layout()
    plt.show()

# Ejemplo de uso
if __name__ == "__main__":
    # Configurar nombres de archivos
    archivo_clientes = "base_clientes_final.csv"
    archivo_transacciones = "base_transacciones_final.csv"
    archivo_salida = "clientes_con_transacciones.csv"  # Opcional, se genera automáticamente si no se especifica
    
    print("=== COMPARADOR DE CLIENTES Y TRANSACCIONES ===\\n")
    
    # Ejecutar análisis
    resultado = analizar_clientes_transacciones(archivo_clientes, archivo_transacciones, archivo_salida)
    
    if resultado:
        print(f"\\n=== RESUMEN FINAL ===")
        print(f"Total clientes analizados: {resultado['clientes_totales']}")
        print(f"Clientes con transacciones: {resultado['clientes_con_transacciones']}")
        print(f"Archivo combinado guardado como: {resultado['archivo_combinado']}")
        print("\\n✅ Análisis completado exitosamente!")