import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

def analizar_datos_nulos(archivo_csv):
    """
    Analiza los datos nulos en un archivo CSV y genera reporte + gráfica
    """
    try:
        # Leer el CSV
        df = pd.read_csv(archivo_csv)
        print(f"Archivo cargado: {archivo_csv}")
        print(f"Dimensiones: {df.shape[0]} filas x {df.shape[1]} columnas\n")
        
        # Contar datos nulos por columna
        nulos_por_columna = df.isnull().sum()
        porcentaje_nulos = (nulos_por_columna / len(df)) * 100
        
        print("=== REPORTE DE DATOS NULOS ===")
        print("-" * 50)
        
        for columna in df.columns:
            cantidad_nulos = nulos_por_columna[columna]
            porcentaje = porcentaje_nulos[columna]
            print(f"{columna:25} | {cantidad_nulos:6} nulos ({porcentaje:5.1f}%)")
        
        print("-" * 50)
        print(f"Total de registros: {len(df)}")
        
        # Mostrar IDs con más datos faltantes
        print("\n=== IDs CON MÁS DATOS FALTANTES ===")
        nombre_primera_columna = df.columns[0]
        nulos_por_fila = df.isnull().sum(axis=1)
        
        # Top 10 registros con más datos faltantes
        top_faltantes = nulos_por_fila.nlargest(10)
        
        if top_faltantes.iloc[0] > 0:  # Solo mostrar si hay datos faltantes
            for idx in top_faltantes.index:
                id_valor = df.iloc[idx, 0]  # Primera columna (ID)
                cantidad_faltante = top_faltantes[idx]
                print(f"ID: {id_valor} | {cantidad_faltante} datos faltantes")
        else:
            print("¡No hay datos faltantes en el dataset!")
        
        # Crear gráfica
        crear_grafica_nulos(nulos_por_columna, df.columns)
        
        return nulos_por_columna
    
    except FileNotFoundError:
        print(f"Error: No se encontró el archivo '{archivo_csv}'")
        print("Asegúrate de que el archivo esté en el directorio correcto.")
    except Exception as e:
        print(f"Error al procesar el archivo: {e}")

def crear_grafica_nulos(nulos_por_columna, columnas):
    """
    Crea una gráfica de barras mostrando datos nulos por columna
    """
    plt.figure(figsize=(12, 6))
    
    # Filtrar solo columnas con datos nulos para mejor visualización
    columnas_con_nulos = nulos_por_columna[nulos_por_columna > 0]
    
    if len(columnas_con_nulos) == 0:
        plt.text(0.5, 0.5, '¡No hay datos nulos!', 
                horizontalalignment='center', verticalalignment='center',
                transform=plt.gca().transAxes, fontsize=16)
        plt.title('Análisis de Datos Nulos')
    else:
        # Crear gráfica de barras
        bars = plt.bar(range(len(columnas_con_nulos)), 
                      columnas_con_nulos.values, 
                      color='salmon', alpha=0.7, edgecolor='darkred')
        
        # Personalizar la gráfica
        plt.title('Cantidad de Datos Nulos por Columna', fontsize=14, fontweight='bold')
        plt.xlabel('Columnas', fontsize=12)
        plt.ylabel('Cantidad de Datos Nulos', fontsize=12)
        
        # Rotar nombres de columnas para mejor legibilidad
        plt.xticks(range(len(columnas_con_nulos)), 
                  columnas_con_nulos.index, 
                  rotation=45, ha='right')
        
        # Agregar valores en las barras
        for i, bar in enumerate(bars):
            height = bar.get_height()
            plt.text(bar.get_x() + bar.get_width()/2., height + 0.1,
                    f'{int(height)}', ha='center', va='bottom')
    
    plt.tight_layout()
    plt.grid(axis='y', alpha=0.3)
    plt.show()

# Ejemplo de uso
if __name__ == "__main__":
    # Cambiar por el nombre de tu archivo CSV
    archivo = "base_clientes_final.csv"
    
    print("=== ANALIZADOR DE DATOS NULOS EN CSV ===\n")
    
    # Ejecutar análisis
    resultado = analizar_datos_nulos(archivo)
    
    print(f"\n=== ANÁLISIS COMPLETADO ===")
    print("La gráfica se ha generado y mostrado.")